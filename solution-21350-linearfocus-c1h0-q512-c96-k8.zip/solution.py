# 21350 time-safe target: q480/c88/k6 plus Linear ADMM2/coord6/dynamic4, 2026-09-10.
# Reuse scale-search buffers; preserve first-min ties; omit terminal K probability updates;
# share one local Q decode and defer GQA expansion until after key sampling.
"""Simple interface merge: 20895 Linear plus 20916 grid5/Q2K-key512 Attention.

The paths remain independent. This file performs no file, process, runtime-loader, or network access.
"""
from __future__ import annotations
import math
from typing import Any, Callable, Iterable
import torch
'Constraint-compliant NVFP4 -> HiF4 utilities and calibration transforms.\n\nThe submission-facing functions in ``solution.py`` call this module without\nperforming file I/O. Linear transform selection uses only Weight and\ncalibration Activation tensor statistics and reconstruction errors.\n'
NVFP4_BLOCK_SIZE = 16
HIF4_BLOCK_SIZE = 64
HIF4_MIN_SCALE = 2.0 ** (-48)
HIF4_MAX_SCALE = 49152.0
DEFAULT_SEARCH_MULTIPLIERS = (0.5, 0.625, 0.75, 0.875, 1.0, 1.25)
FAST_SEARCH_MULTIPLIERS = (0.625, 0.875, 1.0, 1.25)
LINEAR_FIXED_ALPHA = 0.6
ATTENTION_FIXED_STRENGTH = 1.0
OUTLIER_ROTATION_WIDTH = 8
OUTLIER_ROTATION_TOP_COUNT = 2
OUTLIER_ROTATION_THRESHOLD = 2.5
OUTLIER_ROTATION_MAX_STEPS = 4
DUQUANT_GREEDY_MAX_STEPS = 8
HIF4_GIVENS_MAX_STEPS = 8
OUTLIER_MEAN_PROXY_GAIN_MIN = 0.005
OUTLIER_WORST_PROXY_GAIN_MIN = -0.005
V_MEAN_PENALTY = 2.0
V_MEAN_CHANNEL_CHUNK = 512
V_LOCAL_WINDOW = 12
V_LOCAL_MEAN_PENALTY = 2.0
V_LOCAL_MODE_PENALTY = 0.375
V_LOCAL_MODE_COUNT = 2
V_LONG_SEQUENCE_MIN_ROWS = 64
V_LONG_WINDOW = 24
V_LONG_MODE_COUNT = 4

def dequantize_nvfp4(quant_float: torch.Tensor, scale_float: torch.Tensor, blk_size: int=NVFP4_BLOCK_SIZE) -> torch.Tensor:
    """Use the public reference NVFP4 dequantization convention."""
    channels = int(quant_float.shape[-1])
    if channels % blk_size != 0:
        raise ValueError(f'last dim {channels} is not divisible by {blk_size}')
    blocks = quant_float.unflatten(-1, (-1, blk_size))
    result = (blocks * scale_float.unsqueeze(-1)).flatten(-2, -1)
    return result.to(torch.bfloat16)

def round_e6m2(value: torch.Tensor) -> torch.Tensor:
    """Round positive values to the exact public E6M2 scale grid."""
    x = value.to(torch.float32).clamp(HIF4_MIN_SCALE, HIF4_MAX_SCALE)
    exponent = torch.floor(torch.log2(x.clamp_min(2.0 ** (-126))))
    rounded = torch.round(x * torch.pow(2.0, 2.0 - exponent))
    rounded = rounded * torch.pow(2.0, exponent - 2.0)
    return rounded.clamp(HIF4_MIN_SCALE, HIF4_MAX_SCALE)

def quantize_hif4(tensor: torch.Tensor, *, search_multipliers: Iterable[float]=DEFAULT_SEARCH_MULTIPLIERS, chunk_blocks: int=2048, element_weight: torch.Tensor | None=None) -> dict[str, torch.Tensor]:
    """Bit-equivalent batched hierarchical block-64 MMSE HiF4 encoder."""
    shape = tuple((int(v) for v in tensor.shape))
    if not shape or shape[-1] % HIF4_BLOCK_SIZE != 0:
        raise ValueError('HiF4 requires a non-empty shape and last dim divisible by 64')
    x = tensor.detach().to(dtype=torch.float32, device='cpu').contiguous()
    blocks_per_row = shape[-1] // HIF4_BLOCK_SIZE
    blocks = x.reshape(-1, HIF4_BLOCK_SIZE)
    block_count = int(blocks.shape[0])
    block_weight = None
    if element_weight is not None:
        if tuple((int(v) for v in element_weight.shape)) != shape:
            raise ValueError('element_weight must match the quantized tensor shape')
        block_weight = element_weight.detach().to(dtype=torch.float32, device='cpu').contiguous().reshape(-1, 8, 2, 4)
    multipliers = torch.tensor(tuple(search_multipliers), dtype=torch.float32)
    if multipliers.numel() == 0 or not bool((multipliers > 0).all()):
        raise ValueError('search_multipliers must contain positive values')
    out_sf = torch.empty((block_count,), dtype=torch.bfloat16)
    out_lv2 = torch.empty((block_count, 8), dtype=torch.bfloat16)
    out_lv3 = torch.empty((block_count, 8, 2), dtype=torch.bfloat16)
    out_sign = torch.empty((block_count, 8, 2, 4), dtype=torch.bfloat16)
    out_mant = torch.empty((block_count, 8, 2, 4), dtype=torch.bfloat16)
    hierarchy_products = torch.tensor(((1.0, 2.0), (2.0, 4.0)), dtype=torch.float32).reshape(1, 1, 2, 2, 1, 1, 1)
    for start in range(0, block_count, int(chunk_blocks)):
        end = min(start + int(chunk_blocks), block_count)
        xb = blocks[start:end]
        absx = xb.abs().reshape(-1, 8, 2, 4)
        max_abs = absx.amax(dim=(1, 2, 3))
        base = (max_abs / 7.0).clamp_min(HIF4_MIN_SCALE)
        candidates = round_e6m2(base[:, None] * multipliers[None, :])
        local_scale = candidates[:, :, None, None, None, None, None] * hierarchy_products
        expanded_abs = absx[:, None, None, None, :, :, :]
        mant = torch.round(expanded_abs / local_scale * 4.0).clamp_(0.0, 7.0) / 4.0
        element_error = (expanded_abs - mant * local_scale).square()
        if block_weight is not None:
            element_error = element_error * block_weight[start:end, None, None, None, :, :, :]
        errors_by_lv3 = element_error.sum(dim=-1)
        best_sub_error, best_lv3_index = errors_by_lv3.min(dim=3)
        errors_by_lv2 = best_sub_error.sum(dim=-1)
        best_group_error, best_lv2_index = errors_by_lv2.min(dim=2)
        best_candidate = best_group_error.sum(dim=-1).argmin(dim=-1)
        chosen_sf = torch.gather(candidates, 1, best_candidate[:, None]).squeeze(1)
        chosen_lv2 = torch.gather(best_lv2_index, 1, best_candidate[:, None, None].expand(-1, 1, 8)).squeeze(1).to(torch.float32) + 1.0
        lv3_by_candidate = torch.gather(best_lv3_index, 2, best_lv2_index[:, :, None, :, None].expand(-1, -1, 1, -1, 2)).squeeze(2)
        chosen_lv3 = torch.gather(lv3_by_candidate, 1, best_candidate[:, None, None, None].expand(-1, 1, 8, 2)).squeeze(1).to(torch.float32) + 1.0
        effective_scale = chosen_sf[:, None, None, None] * chosen_lv2[:, :, None, None] * chosen_lv3[:, :, :, None]
        chosen_mant = torch.round(absx / effective_scale * 4.0).clamp_(0.0, 7.0) / 4.0
        out_sf[start:end] = chosen_sf
        out_lv2[start:end] = chosen_lv2
        out_lv3[start:end] = chosen_lv3
        out_sign[start:end] = torch.sign(xb).reshape(-1, 8, 2, 4)
        out_mant[start:end] = chosen_mant
    prefix = shape[:-1] + (blocks_per_row,)
    return {'scale_factor': out_sf.reshape(prefix + (1, 1, 1)).to(torch.bfloat16), 'scale_lv2': out_lv2.reshape(prefix + (8, 1, 1)).to(torch.bfloat16), 'scale_lv3': out_lv3.reshape(prefix + (8, 2, 1)).to(torch.bfloat16), 'sign': out_sign.reshape(prefix + (8, 2, 4)).to(torch.bfloat16), 'mant': out_mant.reshape(prefix + (8, 2, 4)).to(torch.bfloat16)}

def quantize_hif4_greedy(tensor: torch.Tensor) -> dict[str, torch.Tensor]:
    shape = tuple((int(v) for v in tensor.shape))
    if not shape or shape[-1] % 64:
        raise ValueError('HiF4 requires last dimension divisible by 64')
    x = tensor.detach().to(dtype=torch.float32, device='cpu').contiguous()
    blocks = x.reshape(-1, 8, 2, 4)
    magnitude = blocks.abs()
    scale_factor = round_e6m2(magnitude.amax(dim=(1, 2, 3)) / 7.0 * 1.0)
    group8_max = magnitude.amax(dim=(2, 3))
    scale_lv2 = torch.where(group8_max > scale_factor[:, None] * 3.5, torch.tensor(2.0), torch.tensor(1.0))
    group4_max = magnitude.amax(dim=3)
    scale_lv3 = torch.where(group4_max > scale_factor[:, None, None] * scale_lv2[:, :, None] * 1.75, torch.tensor(2.0), torch.tensor(1.0))
    effective = scale_factor[:, None, None, None] * scale_lv2[:, :, None, None] * scale_lv3[:, :, :, None]
    mant = torch.round(magnitude / effective.clamp_min(1e-30) * 4.0).clamp_(0.0, 7.0) / 4.0
    prefix = shape[:-1] + (shape[-1] // 64,)
    return {'scale_factor': scale_factor.reshape(prefix + (1, 1, 1)).to(torch.bfloat16), 'scale_lv2': scale_lv2.reshape(prefix + (8, 1, 1)).to(torch.bfloat16), 'scale_lv3': scale_lv3.reshape(prefix + (8, 2, 1)).to(torch.bfloat16), 'sign': torch.sign(blocks).reshape(prefix + (8, 2, 4)).to(torch.bfloat16), 'mant': mant.reshape(prefix + (8, 2, 4)).to(torch.bfloat16)}

def dequantize_hif4(params: dict[str, torch.Tensor]) -> torch.Tensor:
    """Decode public HiF4 parameters to a float32 logical tensor."""
    result = params['scale_factor'].to(torch.float32) * params['scale_lv2'].to(torch.float32) * params['scale_lv3'].to(torch.float32) * params['sign'].to(torch.float32) * params['mant'].to(torch.float32)
    logical_last_dim = int(result.shape[-4]) * int(result.shape[-3]) * int(result.shape[-2]) * int(result.shape[-1])
    return result.reshape(result.shape[:-4] + (logical_last_dim,))

def quantize_hif4_v_mean_balanced(tensor: torch.Tensor, *, mean_penalty: float=V_MEAN_PENALTY, channel_chunk: int=V_MEAN_CHANNEL_CHUNK) -> dict[str, torch.Tensor]:
    """Coordinate adjacent V rounding to suppress per-channel mean error.

    The HiF4 hierarchy and base scales stay fixed at their ordinary
    reconstruction-MSE choices. Within that fixed grid, this function chooses
    a low-cost prefix of adjacent rounding alternatives for every V channel.
    The objective is local SSE plus mean_penalty times the squared channel
    error mean, matching the constant error component that survives a
    row-stochastic softmax matrix.
    """
    if tensor.ndim != 2:
        raise ValueError('V mean-balanced rounding requires a 2-D tensor')
    if int(channel_chunk) <= 0:
        raise ValueError('channel_chunk must be positive')
    params = quantize_hif4(tensor)
    rows = int(tensor.shape[0])
    channels = int(tensor.shape[1])
    if rows <= 1 or float(mean_penalty) <= 0.0:
        return params
    target = tensor.detach().to(dtype=torch.float32, device='cpu').contiguous()
    code_shape = tuple((int(value) for value in params['mant'].shape))
    step = (params['scale_factor'].to(torch.float32) * params['scale_lv2'].to(torch.float32) * params['scale_lv3'].to(torch.float32) * 0.25).expand_as(params['mant']).reshape_as(target)
    standard_codes = (params['sign'].to(torch.float32) * params['mant'].to(torch.float32) * 4.0).reshape_as(target).round().clamp_(-7.0, 7.0).to(torch.int8)
    optimized_codes = standard_codes.clone()
    for start in range(0, channels, int(channel_chunk)):
        end = min(start + int(channel_chunk), channels)
        local_target = target[:, start:end]
        local_step = step[:, start:end].clamp_min(1e-30)
        standard = standard_codes[:, start:end].to(torch.float32)
        scaled = local_target / local_step
        lower = torch.floor(scaled).clamp_(-7.0, 7.0)
        upper = torch.ceil(scaled).clamp_(-7.0, 7.0)
        alternate = torch.where(standard == lower, upper, lower)
        standard_error = local_target - standard * local_step
        alternate_error = local_target - alternate * local_step
        error_delta = alternate_error - standard_error
        sse_delta = (alternate_error.square() - standard_error.square()).clamp_min_(0.0)
        error_sum = standard_error.sum(dim=0)
        valid = (error_delta * error_sum[None, :] < 0.0) & (error_delta.abs() > 1e-30)
        efficiency = torch.where(valid, sse_delta / error_delta.abs().clamp_min(1e-30), torch.full_like(error_delta, float('inf')))
        order = torch.argsort(efficiency, dim=0, stable=True)
        sorted_valid = torch.gather(valid, 0, order)
        sorted_error_delta = torch.gather(error_delta, 0, order)
        sorted_sse_delta = torch.gather(sse_delta, 0, order)
        sorted_error_delta = torch.where(sorted_valid, sorted_error_delta, torch.zeros_like(sorted_error_delta))
        sorted_sse_delta = torch.where(sorted_valid, sorted_sse_delta, torch.full_like(sorted_sse_delta, float('inf')))
        cumulative_error_delta = sorted_error_delta.cumsum(dim=0)
        cumulative_sse_delta = sorted_sse_delta.cumsum(dim=0)
        objective_delta = cumulative_sse_delta + float(mean_penalty) / float(rows) * ((error_sum[None, :] + cumulative_error_delta).square() - error_sum[None, :].square())
        objective_delta = torch.cat((torch.zeros((1, end - start), dtype=torch.float32), objective_delta), dim=0)
        best_count = objective_delta.argmin(dim=0)
        selected_sorted = torch.arange(rows, dtype=torch.long)[:, None] < best_count[None, :]
        selected = torch.zeros_like(selected_sorted)
        selected.scatter_(0, order, selected_sorted)
        optimized_codes[:, start:end] = torch.where(selected, alternate, standard).to(torch.int8)
    result = dict(params)
    result['sign'] = torch.sign(optimized_codes).reshape(code_shape).to(torch.bfloat16)
    result['mant'] = (optimized_codes.abs().to(torch.float32) * 0.25).reshape(code_shape).to(torch.bfloat16)
    return result

def quantize_hif4_v_local_modes(tensor: torch.Tensor, *, window: int=V_LOCAL_WINDOW, mean_penalty: float=V_LOCAL_MEAN_PENALTY, mode_penalty: float=V_LOCAL_MODE_PENALTY, mode_count: int=V_LOCAL_MODE_COUNT, search_multipliers: Iterable[float]=DEFAULT_SEARCH_MULTIPLIERS, max_steps: int | None=None, position_weight_strength: float=0.0) -> dict[str, torch.Tensor]:
    """Shape V rounding noise away from local low-frequency Attention modes.

    Softmax outputs are convex weighted sums of V rows.  Ordinary elementwise
    rounding can leave a coherent low-frequency error that survives those
    sums.  This routine keeps the ordinary HiF4 hierarchy and considers only
    each value's adjacent legal mantissa.  In short token windows it greedily
    reduces a proxy containing reconstruction SSE, the constant mode, and a
    few lowest DCT modes.  The proxy is independent of the current Q/K sample,
    so the dynamic V callback remains stateless and safe under parallel calls.
    """
    if tensor.ndim != 2:
        raise ValueError('V local-mode rounding requires a 2-D tensor')
    if int(window) <= 0:
        raise ValueError('V local-mode window must be positive')
    if int(mode_count) < 0 or int(mode_count) >= int(window):
        raise ValueError('V local-mode count must be in [0, window)')
    params = (
        quantize_hif4_direct(tensor)
        if int(tensor.shape[0]) <= 1024
        else quantize_hif4(tensor, search_multipliers=search_multipliers)
    )
    target = tensor.detach().to(dtype=torch.float32, device='cpu').contiguous()
    rows, channels = map(int, target.shape)
    if rows <= 1:
        return params
    code_shape = tuple((int(value) for value in params['mant'].shape))
    step = (params['scale_factor'].to(torch.float32) * params['scale_lv2'].to(torch.float32) * params['scale_lv3'].to(torch.float32) * 0.25).expand_as(params['mant']).reshape_as(target).clamp_min(1e-30)
    nearest = torch.round(target / step).clamp_(-7.0, 7.0)
    scaled = target / step
    lower = torch.floor(scaled).clamp_(-7.0, 7.0)
    upper = torch.ceil(scaled).clamp_(-7.0, 7.0)
    alternate = torch.where(nearest == lower, upper, lower)
    nearest_error = target - nearest * step
    alternate_error = target - alternate * step
    error_delta = alternate_error - nearest_error
    sse_delta = (alternate_error.square() - nearest_error.square()).clamp_min_(0.0)
    if float(position_weight_strength) != 0.0:
        row_fraction = (torch.arange(rows, dtype=torch.float32) + 0.5) / float(rows)
        row_weight = 1.0 + float(position_weight_strength) * (0.5 - row_fraction)
        sse_delta.mul_(row_weight[:, None])
    local_window = int(window)
    group_count = (rows + local_window - 1) // local_window
    padded_rows = group_count * local_window
    padding = padded_rows - rows
    if padding:
        nearest_error = torch.cat((nearest_error, torch.zeros((padding, channels), dtype=torch.float32)), dim=0)
        error_delta = torch.cat((error_delta, torch.zeros((padding, channels), dtype=torch.float32)), dim=0)
        sse_delta = torch.cat((sse_delta, torch.full((padding, channels), float('inf'), dtype=torch.float32)), dim=0)
        nearest = torch.cat((nearest, torch.zeros((padding, channels), dtype=torch.float32)), dim=0)
        alternate = torch.cat((alternate, torch.zeros((padding, channels), dtype=torch.float32)), dim=0)
    error = nearest_error.reshape(group_count, local_window, channels).clone()
    error_delta = error_delta.reshape(group_count, local_window, channels)
    sse_delta = sse_delta.reshape(group_count, local_window, channels)
    codes = nearest.reshape(group_count, local_window, channels).clone()
    alternate = alternate.reshape(group_count, local_window, channels)
    used = ~torch.isfinite(sse_delta)
    position = torch.arange(local_window, dtype=torch.float32) + 0.5
    modes = [torch.cos(math.pi * position * float(order) / float(local_window)) * math.sqrt(2.0) for order in range(1, int(mode_count) + 1)]
    mode_matrix = torch.stack(modes, dim=0) if modes else torch.empty((0, local_window), dtype=torch.float32)
    error_sum = error.sum(dim=1)
    global_dc_penalty = 2.0 if rows >= 512 else 0.0
    global_error_sum = error_sum.sum(dim=0)
    projections = torch.einsum('mw,gwc->gmc', mode_matrix, error) if mode_matrix.numel() else torch.empty((group_count, 0, channels), dtype=torch.float32)
    weighted_delta = mode_matrix[None, :, :, None] * error_delta[:, None, :, :] if mode_matrix.numel() else torch.empty((group_count, 0, local_window, channels), dtype=torch.float32)
    weighted_delta_square = weighted_delta.square().sum(dim=1)
    greedy_steps = local_window if max_steps is None else min(local_window, max(int(max_steps), 0))
    for _ in range(greedy_steps):
        cost = sse_delta + float(mean_penalty) / float(local_window) * (2.0 * error_sum[:, None, :] * error_delta + error_delta.square())
        if global_dc_penalty != 0.0:
            cost = cost + global_dc_penalty / float(rows) * (2.0 * global_error_sum[None, None, :] * error_delta + error_delta.square())
        if mode_matrix.numel():
            cost = cost + float(mode_penalty) / float(local_window) * ((2.0 * projections[:, :, None, :] * weighted_delta).sum(dim=1) + weighted_delta_square)
        cost = torch.where(used, torch.full_like(cost, float('inf')), cost)
        best_cost, best_row = cost.min(dim=1)
        accepted = best_cost < 0.0
        gather_index = best_row[:, None, :]
        chosen_delta = torch.gather(error_delta, 1, gather_index).squeeze(1)
        chosen_code = torch.gather(alternate, 1, gather_index).squeeze(1)
        current_code = torch.gather(codes, 1, gather_index).squeeze(1)
        accepted_delta = torch.where(accepted, chosen_delta, 0.0)
        error_sum += accepted_delta
        if global_dc_penalty != 0.0:
            global_error_sum += accepted_delta.sum(dim=0)
        if mode_matrix.numel():
            mode_index = best_row[:, None, None, :].expand(-1, int(mode_matrix.shape[0]), 1, -1)
            chosen_weighted_delta = torch.gather(weighted_delta, 2, mode_index).squeeze(2)
            projections += torch.where(accepted[:, None, :], chosen_weighted_delta, 0.0)
        codes.scatter_(1, gather_index, torch.where(accepted, chosen_code, current_code)[:, None, :])
        used.scatter_(1, gather_index, torch.ones_like(gather_index, dtype=torch.bool))
        if not bool(accepted.any()):
            break
    optimized_codes = codes.reshape(padded_rows, channels)[:rows]
    result = dict(params)
    result['sign'] = torch.sign(optimized_codes).reshape(code_shape).to(torch.bfloat16)
    result['mant'] = (optimized_codes.abs() * 0.25).reshape(code_shape).to(torch.bfloat16)
    return result

def make_signs(shape: tuple[int, ...], seed: int) -> torch.Tensor:
    """Create a deterministic CPU int8 Rademacher tensor."""
    generator = torch.Generator(device='cpu')
    generator.manual_seed(int(seed))
    values = torch.randint(0, 2, shape, generator=generator, dtype=torch.int8)
    return values.mul_(2).sub_(1)

def hadamard_transform(tensor: torch.Tensor, block_size: int, signs: torch.Tensor | None=None) -> torch.Tensor:
    """Apply x @ (diag(signs) H / sqrt(block_size)) along the last dim."""
    if block_size <= 0 or block_size & block_size - 1:
        raise ValueError('block_size must be a positive power of two')
    if tensor.shape[-1] % block_size != 0:
        raise ValueError('last dimension must be divisible by the rotation block size')
    result = tensor.to(torch.float32)
    if signs is not None:
        result = result * signs.to(dtype=torch.float32, device=result.device)
    blocks = result.reshape(result.shape[:-1] + (-1, block_size))
    width = 1
    while width < block_size:
        paired = blocks.reshape(blocks.shape[:-1] + (-1, 2, width))
        left = paired[..., 0, :]
        right = paired[..., 1, :]
        blocks = torch.cat((left + right, left - right), dim=-1).reshape(blocks.shape)
        width *= 2
    return (blocks / math.sqrt(float(block_size))).reshape(result.shape)

def build_outlier_rotation(importance: torch.Tensor, *, block_size: int=HIF4_BLOCK_SIZE, width: int=OUTLIER_ROTATION_WIDTH, top_count: int=OUTLIER_ROTATION_TOP_COUNT, threshold: float=OUTLIER_ROTATION_THRESHOLD, seed: int) -> dict[str, torch.Tensor | int | float]:
    """Build one sparse, block-aligned, outlier-aware orthogonal rotation.

    Within every HiF4 block, the largest ``top_count`` coordinates and the
    quietest remaining coordinates are mixed by one signed Hadamard of size
    ``width``. Other coordinates are unchanged. This is a low-cost analogue of
    DuQuant++'s group-aligned outlier-aware rotation rather than a full dense
    64x64 transform.
    """
    if block_size != HIF4_BLOCK_SIZE:
        raise ValueError('outlier rotation must align with the HiF4 block size')
    if width <= 0 or width & width - 1 or width > block_size:
        raise ValueError('rotation width must be a power of two within one block')
    if top_count <= 0 or top_count >= width:
        raise ValueError('top_count must be between zero and rotation width')
    if int(importance.shape[-1]) % block_size != 0:
        raise ValueError('importance last dimension must be divisible by block size')
    blocks = importance.detach().to(torch.float32).reshape(importance.shape[:-1] + (-1, block_size))
    rms = blocks.square().mean(dim=-1, keepdim=True).sqrt().clamp_min(1e-08)
    relative = blocks.abs() / rms
    top_indices = torch.topk(relative, top_count, dim=-1, largest=True).indices
    quiet_score = relative.clone()
    quiet_score.scatter_(-1, top_indices, float('inf'))
    quiet_indices = torch.topk(quiet_score, width - top_count, dim=-1, largest=False).indices
    indices = torch.cat((top_indices, quiet_indices), dim=-1).to(torch.long)
    active = relative.amax(dim=-1) >= float(threshold)
    signs = make_signs(tuple((int(v) for v in indices.shape)), seed=seed)
    return {'rotation_kind': 'sparse_hadamard', 'rotation_block_size': int(block_size), 'rotation_width': int(width), 'rotation_indices': indices.cpu(), 'rotation_signs': signs.cpu(), 'rotation_active': active.cpu(), 'rotation_threshold': float(threshold)}

def sparse_outlier_transform(tensor: torch.Tensor, rotation: dict[str, Any]) -> torch.Tensor:
    """Apply the sparse signed-Hadamard rotation stored in ``rotation``."""
    block_size = int(rotation['rotation_block_size'])
    width = int(rotation['rotation_width'])
    result = tensor.to(torch.float32)
    blocks = result.reshape(result.shape[:-1] + (-1, block_size))
    indices = rotation['rotation_indices'].to(device=blocks.device, dtype=torch.long)
    signs = rotation['rotation_signs'].to(device=blocks.device, dtype=torch.float32)
    active = rotation['rotation_active'].to(device=blocks.device, dtype=torch.bool)
    leading_dims = blocks.dim() - indices.dim()
    if leading_dims < 0:
        raise ValueError('rotation indices have more dimensions than the input blocks')
    prefix = (1,) * leading_dims
    expanded_shape = blocks.shape[:-1] + (width,)
    expanded_indices = indices.reshape(prefix + indices.shape).expand(expanded_shape)
    expanded_signs = signs.reshape(prefix + signs.shape).expand(expanded_shape)
    expanded_active = active.reshape(prefix + active.shape).expand(blocks.shape[:-1])
    selected = torch.gather(blocks, dim=-1, index=expanded_indices)
    rotated = hadamard_transform(selected, width, expanded_signs)
    rotated = torch.where(expanded_active[..., None], rotated, selected)
    output = blocks.clone()
    output.scatter_(dim=-1, index=expanded_indices, src=rotated)
    return output.reshape(result.shape)

def _outlier_peak_score(primary_blocks: torch.Tensor, other_blocks: torch.Tensor | None) -> tuple[torch.Tensor, float]:
    primary_peak = primary_blocks.abs().amax(dim=0)
    score = primary_peak / primary_peak.amax().clamp_min(1e-08)
    primary_rms = primary_blocks.square().mean().sqrt().clamp_min(1e-08)
    objective = float((primary_peak.amax() / primary_rms).item())
    if other_blocks is not None:
        other_peak = other_blocks.abs().amax(dim=0)
        other_normalized = other_peak / other_peak.amax().clamp_min(1e-08)
        score = torch.maximum(score, other_normalized)
        other_rms = other_blocks.square().mean().sqrt().clamp_min(1e-08)
        objective = max(objective, float((other_peak.amax() / other_rms).item()))
    return (score, objective)

def _householder_for_coordinate(coordinate: int, block_size: int, seed: int) -> torch.Tensor:
    target = make_signs((block_size,), seed=seed).to(torch.float32)
    target = target / math.sqrt(float(block_size))
    basis = torch.zeros(block_size, dtype=torch.float32)
    basis[int(coordinate)] = 1.0
    vector = basis - target
    return vector / vector.norm().clamp_min(1e-08)

def _apply_householder_blocks(blocks: torch.Tensor, vector: torch.Tensor) -> torch.Tensor:
    projection = torch.matmul(blocks, vector)
    return blocks - 2.0 * projection[:, None] * vector[None, :]

def build_greedy_outlier_rotation(primary: torch.Tensor, other: torch.Tensor | None=None, *, block_size: int=HIF4_BLOCK_SIZE, max_steps: int=OUTLIER_ROTATION_MAX_STEPS, seed: int) -> dict[str, torch.Tensor | int | float]:
    """Approximate DuQuant++ with at most four shared rank-one rotations.

    The original method greedily applies a dense outlier-aware orthogonal
    matrix and shares it across every microscaling block. Here each step is a
    Householder reflection that maps the worst block-relative coordinate to a
    signed uniform direction. It keeps the same greedy/shared/block-aligned
    structure while costing O(max_steps * N) instead of a dense 64x64 matmul.
    """
    if int(primary.shape[-1]) % block_size != 0:
        raise ValueError('primary last dimension must be divisible by block size')
    if other is not None and int(other.shape[-1]) % block_size != 0:
        raise ValueError('other last dimension must be divisible by block size')
    primary_blocks = primary.detach().to(torch.float32).reshape(-1, block_size)
    other_blocks = other.detach().to(torch.float32).reshape(-1, block_size) if other is not None else None
    vectors: list[torch.Tensor] = []
    _, initial_objective = _outlier_peak_score(primary_blocks, other_blocks)
    objectives = [initial_objective]
    for step in range(int(max_steps)):
        score, _ = _outlier_peak_score(primary_blocks, other_blocks)
        coordinate = int(score.argmax().item())
        vector = _householder_for_coordinate(coordinate, block_size, seed + 97 * step)
        vectors.append(vector)
        primary_blocks = _apply_householder_blocks(primary_blocks, vector)
        if other_blocks is not None:
            other_blocks = _apply_householder_blocks(other_blocks, vector)
        _, objective = _outlier_peak_score(primary_blocks, other_blocks)
        objectives.append(objective)
    selected_steps = int(torch.tensor(objectives).argmin().item())
    selected_vectors = torch.stack(vectors[:selected_steps], dim=0) if selected_steps else torch.empty((0, block_size), dtype=torch.float32)
    return {'rotation_kind': 'greedy_householder', 'rotation_block_size': int(block_size), 'rotation_vectors': selected_vectors.cpu(), 'rotation_steps': int(selected_steps), 'rotation_max_steps': int(max_steps), 'rotation_peak_before': float(objectives[0]), 'rotation_peak_after': float(objectives[selected_steps])}

def greedy_outlier_transform(tensor: torch.Tensor, rotation: dict[str, Any]) -> torch.Tensor:
    """Apply the shared sequence of Householder reflections."""
    block_size = int(rotation['rotation_block_size'])
    result = tensor.to(torch.float32)
    original_shape = result.shape
    blocks = result.reshape(-1, block_size)
    vectors = rotation['rotation_vectors'].to(device=blocks.device, dtype=torch.float32)
    for vector in vectors:
        blocks = _apply_householder_blocks(blocks, vector)
    return blocks.reshape(original_shape)

def _exchange_rotation_coordinate(matrix: torch.Tensor, left: int, right: int) -> torch.Tensor:
    indices = torch.arange(matrix.shape[0])
    left_value = indices[left].clone()
    indices[left] = indices[right]
    indices[right] = left_value
    return matrix.index_select(0, indices).index_select(1, indices)

def _duquant_base_rotation(block_size: int, seed: int) -> torch.Tensor:
    """Reproduce the official DuQuant rotation construction without file I/O."""
    rotation = torch.eye(block_size, dtype=torch.float32)
    for index in range(block_size - 1):
        givens = torch.eye(block_size, dtype=torch.float32)
        cosine = 1.0 / math.sqrt(float(index + 2))
        sine = math.sqrt(float(index + 1)) / math.sqrt(float(index + 2))
        givens[index, index] = cosine
        givens[index + 1, index + 1] = cosine
        givens[index, index + 1] = -sine
        givens[index + 1, index] = sine
        rotation = torch.matmul(givens, rotation)
    rotation = _exchange_rotation_coordinate(rotation, 0, block_size - 1)
    generator = torch.Generator(device='cpu')
    generator.manual_seed(int(seed))
    random_matrix = torch.randn((block_size - 1, block_size - 1), generator=generator, dtype=torch.float32)
    q, _ = torch.linalg.qr(random_matrix)
    complement = torch.zeros((block_size, block_size), dtype=torch.float32)
    complement[0, 0] = 1.0
    complement[1:, 1:] = q
    return torch.matmul(rotation, complement)

def build_duquant_rotation(primary: torch.Tensor, other: torch.Tensor | None=None, *, block_size: int=HIF4_BLOCK_SIZE, max_steps: int=DUQUANT_GREEDY_MAX_STEPS, forced_steps: int | None=None, seed: int) -> dict[str, torch.Tensor | int | float]:
    """Build the shared block-diagonal rotation used by DuQuant++.

    The worst block-relative feature coordinate is found greedily, the official
    dense DuQuant basis is exchanged to target that coordinate, and the same
    matrix is applied to every block. The best prefix is selected by peak/RMS.
    """
    if int(primary.shape[-1]) % block_size != 0:
        raise ValueError('primary last dimension must be divisible by block size')
    if other is not None and int(other.shape[-1]) % block_size != 0:
        raise ValueError('other last dimension must be divisible by block size')
    primary_blocks = primary.detach().to(torch.float32).reshape(-1, block_size)
    other_blocks = other.detach().to(torch.float32).reshape(-1, block_size) if other is not None else None
    base = _duquant_base_rotation(block_size, seed)
    composed = torch.eye(block_size, dtype=torch.float32)
    matrices = [composed]
    _, initial_objective = _outlier_peak_score(primary_blocks, other_blocks)
    objectives = [initial_objective]
    for _ in range(int(max_steps)):
        score, _ = _outlier_peak_score(primary_blocks, other_blocks)
        coordinate = int(score.argmax().item())
        step_rotation = _exchange_rotation_coordinate(base, 0, coordinate)
        primary_blocks = torch.matmul(primary_blocks, step_rotation)
        if other_blocks is not None:
            other_blocks = torch.matmul(other_blocks, step_rotation)
        composed = torch.matmul(composed, step_rotation)
        matrices.append(composed)
        _, objective = _outlier_peak_score(primary_blocks, other_blocks)
        objectives.append(objective)
    peak_selected_steps = int(torch.tensor(objectives).argmin().item())
    selected_steps = peak_selected_steps if forced_steps is None else min(max(int(forced_steps), 0), int(max_steps))
    return {'rotation_kind': 'duquant_dense', 'rotation_block_size': int(block_size), 'rotation_matrix': matrices[selected_steps].cpu(), 'rotation_steps': int(selected_steps), 'rotation_peak_selected_steps': int(peak_selected_steps), 'rotation_max_steps': int(max_steps), 'rotation_peak_before': float(objectives[0]), 'rotation_peak_after': float(objectives[selected_steps])}

def duquant_transform(tensor: torch.Tensor, rotation: dict[str, Any]) -> torch.Tensor:
    """Apply one pre-composed shared DuQuant++ matrix per HiF4 block."""
    block_size = int(rotation['rotation_block_size'])
    result = tensor.to(torch.float32)
    blocks = result.reshape(-1, block_size)
    matrix = rotation['rotation_matrix'].to(device=blocks.device, dtype=torch.float32)
    return torch.matmul(blocks, matrix).reshape(result.shape)

def _apply_givens_blocks(blocks: torch.Tensor, left_index: int, right_index: int, sign: float) -> torch.Tensor:
    result = blocks.clone()
    left = blocks[:, int(left_index)]
    right = blocks[:, int(right_index)]
    inverse_sqrt_two = 1.0 / math.sqrt(2.0)
    result[:, int(left_index)] = (left + float(sign) * right) * inverse_sqrt_two
    result[:, int(right_index)] = (-float(sign) * left + right) * inverse_sqrt_two
    return result

def build_hif4_givens_rotation(primary: torch.Tensor, other: torch.Tensor | None=None, *, block_size: int=HIF4_BLOCK_SIZE, subgroup_size: int=4, max_steps: int=HIF4_GIVENS_MAX_STEPS, forced_steps: int | None=None) -> dict[str, torch.Tensor | int | float | str]:
    """Build a HiF4-hierarchy-aware greedy outlier rotation.

    Each step mixes the worst shared block coordinate with the quietest peer
    inside the same four-value level-3 scale group. Both 45-degree signs are
    tested against peak/RMS, and all HiF4 blocks share the chosen Givens list.
    """
    if subgroup_size not in (4, 8, block_size) or block_size % subgroup_size != 0:
        raise ValueError('subgroup size must align with the HiF4 hierarchy')
    if int(primary.shape[-1]) % block_size != 0:
        raise ValueError('primary last dimension must be divisible by block size')
    if other is not None and int(other.shape[-1]) % block_size != 0:
        raise ValueError('other last dimension must be divisible by block size')
    primary_blocks = primary.detach().to(torch.float32).reshape(-1, block_size)
    other_blocks = other.detach().to(torch.float32).reshape(-1, block_size) if other is not None else None
    pairs: list[tuple[int, int]] = []
    signs: list[float] = []
    _, initial_objective = _outlier_peak_score(primary_blocks, other_blocks)
    objectives = [initial_objective]
    for _ in range(int(max_steps)):
        score, _ = _outlier_peak_score(primary_blocks, other_blocks)
        left_index = int(score.argmax().item())
        subgroup_start = left_index // subgroup_size * subgroup_size
        subgroup_indices = torch.arange(subgroup_start, subgroup_start + subgroup_size)
        partner_score = score.index_select(0, subgroup_indices).clone()
        partner_score[left_index - subgroup_start] = float('inf')
        right_index = int(subgroup_indices[int(partner_score.argmin().item())].item())
        trials: list[tuple[float, float, torch.Tensor, torch.Tensor | None]] = []
        for sign in (-1.0, 1.0):
            trial_primary = _apply_givens_blocks(primary_blocks, left_index, right_index, sign)
            trial_other = _apply_givens_blocks(other_blocks, left_index, right_index, sign) if other_blocks is not None else None
            _, objective = _outlier_peak_score(trial_primary, trial_other)
            trials.append((objective, sign, trial_primary, trial_other))
        objective, selected_sign, primary_blocks, other_blocks = min(trials, key=lambda item: item[0])
        pairs.append((left_index, right_index))
        signs.append(float(selected_sign))
        objectives.append(float(objective))
    peak_selected_steps = int(torch.tensor(objectives).argmin().item())
    selected_steps = peak_selected_steps if forced_steps is None else min(max(int(forced_steps), 0), int(max_steps))
    return {'rotation_kind': f'hif4_subgroup{subgroup_size}_givens', 'rotation_subgroup_size': int(subgroup_size), 'rotation_block_size': int(block_size), 'rotation_pairs': torch.tensor(pairs[:selected_steps], dtype=torch.long), 'rotation_pair_signs': torch.tensor(signs[:selected_steps], dtype=torch.float32), 'rotation_steps': int(selected_steps), 'rotation_peak_selected_steps': int(peak_selected_steps), 'rotation_max_steps': int(max_steps), 'rotation_peak_before': float(objectives[0]), 'rotation_peak_after': float(objectives[selected_steps])}

def hif4_givens_transform(tensor: torch.Tensor, rotation: dict[str, Any]) -> torch.Tensor:
    """Apply the shared HiF4-local Givens sequence."""
    block_size = int(rotation['rotation_block_size'])
    result = tensor.to(torch.float32)
    original_shape = result.shape
    blocks = result.reshape(-1, block_size)
    pairs = rotation['rotation_pairs'].to(torch.long)
    signs = rotation['rotation_pair_signs'].to(torch.float32)
    for pair, sign in zip(pairs, signs):
        blocks = _apply_givens_blocks(blocks, int(pair[0].item()), int(pair[1].item()), float(sign.item()))
    return blocks.reshape(original_shape)

def _hq_sample_rows(tensor: torch.Tensor, limit: int) -> torch.Tensor:
    rows = int(tensor.shape[0])
    if rows <= limit:
        return tensor
    index = torch.linspace(0, rows - 1, steps=limit, dtype=torch.float64).round().to(torch.long)
    return tensor.index_select(0, index)

def _safe_geometric_normalize(scale: torch.Tensor) -> torch.Tensor:
    log_scale = torch.log2(scale.clamp_min(2.0 ** (-16)))
    return torch.pow(2.0, log_scale - log_scale.mean(dim=-1, keepdim=True))

def _linear_scale(activation_amax: torch.Tensor, weight_amax: torch.Tensor, alpha: float) -> torch.Tensor:
    eps = 1e-08
    scale = (activation_amax + eps).pow(float(alpha)) / (weight_amax + eps).pow(1.0 - float(alpha))
    scale = _safe_geometric_normalize(scale)
    return torch.pow(2.0, torch.log2(scale).clamp(-4.0, 4.0))

def transform_linear_activation(activation: torch.Tensor, state: dict[str, Any] | None) -> torch.Tensor:
    if not state or state.get('mode') == 'direct':
        return activation.to(torch.float32)
    result = activation.to(torch.float32) / state['smooth_scale'].to(torch.float32)
    block_size = int(state.get('rotation_block_size', 0))
    if block_size:
        if 'rotation_pairs' in state:
            result = hif4_givens_transform(result, state)
        elif 'rotation_matrix' in state:
            result = duquant_transform(result, state)
        elif 'rotation_vectors' in state:
            result = greedy_outlier_transform(result, state)
        elif 'rotation_indices' in state:
            result = sparse_outlier_transform(result, state)
        else:
            result = hadamard_transform(result, block_size, state['rotation_signs'])
    return result

def transform_linear_weight(weight: torch.Tensor, state: dict[str, Any]) -> torch.Tensor:
    result = weight.to(torch.float32) * state['smooth_scale'].to(torch.float32)
    block_size = int(state.get('rotation_block_size', 0))
    if block_size:
        if 'rotation_pairs' in state:
            result = hif4_givens_transform(result, state)
        elif 'rotation_matrix' in state:
            result = duquant_transform(result, state)
        elif 'rotation_vectors' in state:
            result = greedy_outlier_transform(result, state)
        elif 'rotation_indices' in state:
            result = sparse_outlier_transform(result, state)
        else:
            result = hadamard_transform(result, block_size, state['rotation_signs'])
    return result

def _normalized_weighted_error(original: torch.Tensor, reconstructed: torch.Tensor, channel_weight: torch.Tensor) -> torch.Tensor:
    weight = channel_weight.to(torch.float64).clamp_min(1e-30)
    original64 = original.to(torch.float64)
    error64 = reconstructed.to(torch.float64) - original64
    numerator = (error64.square() * weight).sum()
    denominator = (original64.square() * weight).sum().clamp_min(1e-30)
    return numerator / denominator

def _hq_mean(values: Iterable[float]) -> float:
    materialized = tuple((float(value) for value in values))
    if not materialized:
        raise ValueError('at least one value is required')
    return sum(materialized) / len(materialized)

def _select_gated_state(evaluations: list[tuple[dict[str, Any], tuple[float, ...]]], *, mean_gain_min: float=0.01, worst_gain_min: float=-0.005) -> dict[str, Any]:
    """Choose a stable calibration candidate, with direct as the safe fallback.

    Each tuple contains a serializable state and one proxy loss per calibration
    fold. Lower is better. The selected non-direct candidate must improve the
    average proxy by ``mean_gain_min`` and may not violate ``worst_gain_min`` on
    its worst fold. This gate promises only calibration-proxy safety; it does
    not claim hidden output-MSE dominance.
    """
    direct_matches = [item for item in evaluations if item[0].get('mode') == 'direct']
    if len(direct_matches) != 1:
        raise ValueError('evaluations must contain exactly one direct candidate')
    direct_state, direct_scores = direct_matches[0]
    if not direct_scores:
        raise ValueError('candidate evaluations must contain calibration folds')
    direct_mean = _hq_mean(direct_scores)
    selected_state = direct_state
    selected_scores = direct_scores
    selected_mean_gain = 0.0
    selected_worst_gain = 0.0
    selected_robust_gain = 0.0
    gate_passed = False
    for state, fold_scores in evaluations:
        if state.get('mode') == 'direct':
            continue
        if len(fold_scores) != len(direct_scores):
            raise ValueError('all candidates must use the same calibration folds')
        gains = tuple(((float(direct) - float(candidate)) / max(abs(float(direct)), 1e-30) for direct, candidate in zip(direct_scores, fold_scores)))
        mean_gain = _hq_mean(gains)
        worst_gain = min(gains)
        robust_gain = mean_gain + 0.25 * worst_gain
        eligible = mean_gain >= float(mean_gain_min) and worst_gain >= float(worst_gain_min)
        if eligible and (not gate_passed or robust_gain > selected_robust_gain):
            selected_state = state
            selected_scores = fold_scores
            selected_mean_gain = mean_gain
            selected_worst_gain = worst_gain
            selected_robust_gain = robust_gain
            gate_passed = True
    result = {key: value for key, value in selected_state.items()}
    result.update({'selection_policy': 'calibration-fold-gated', 'selection_score': float(_hq_mean(selected_scores)), 'direct_score': float(direct_mean), 'mean_proxy_gain': float(selected_mean_gain), 'worst_proxy_gain': float(selected_worst_gain), 'gate_passed': bool(gate_passed), 'fold_count': int(len(direct_scores)), 'candidate_count': int(len(evaluations))})
    return result

def _select_single_outlier_state(reference: tuple[dict[str, Any], tuple[float, ...]], candidate: tuple[dict[str, Any], tuple[float, ...]], *, mean_gain_min: float=OUTLIER_MEAN_PROXY_GAIN_MIN, worst_gain_min: float=OUTLIER_WORST_PROXY_GAIN_MIN) -> dict[str, Any]:
    """Gate one block-aligned rotation candidate against the fixed D state."""
    reference_state, reference_scores = reference
    candidate_state, candidate_scores = candidate
    if not reference_scores or len(reference_scores) != len(candidate_scores):
        raise ValueError('reference and candidate require matching calibration folds')
    gains = tuple(((float(base) - float(trial)) / max(abs(float(base)), 1e-30) for base, trial in zip(reference_scores, candidate_scores)))
    mean_gain = _hq_mean(gains)
    worst_gain = min(gains)
    passed = mean_gain >= float(mean_gain_min) and worst_gain >= float(worst_gain_min)
    selected_state = candidate_state if passed else reference_state
    selected_scores = candidate_scores if passed else reference_scores
    result = {key: value for key, value in selected_state.items()}
    if 'rotation_active' in candidate_state:
        active_fraction = float(candidate_state['rotation_active'].to(torch.float32).mean().item())
    else:
        active_fraction = float(int(candidate_state.get('rotation_steps', 0)) > 0)
    result.update({'selection_policy': 'fixed-d-single-outlier-rotation', 'selection_score': float(_hq_mean(selected_scores)), 'reference_score': float(_hq_mean(reference_scores)), 'rotation_candidate_score': float(_hq_mean(candidate_scores)), 'mean_proxy_gain': float(mean_gain), 'worst_proxy_gain': float(worst_gain), 'gate_passed': bool(passed), 'fold_count': int(len(reference_scores)), 'candidate_count': 2, 'tested_rotation_active_fraction': active_fraction, 'tested_rotation_steps': int(candidate_state.get('rotation_steps', 0))})
    return result

def _select_outlier_state(reference: tuple[dict[str, Any], tuple[float, ...]], candidates: list[tuple[dict[str, Any], tuple[float, ...]]], *, mean_gain_min: float=OUTLIER_MEAN_PROXY_GAIN_MIN, worst_gain_min: float=OUTLIER_WORST_PROXY_GAIN_MIN) -> dict[str, Any]:
    """Select the most robust HiF4-proxy prefix, or keep fixed D."""
    reference_state, reference_scores = reference
    if not reference_scores:
        raise ValueError('reference requires calibration folds')
    selected_state = reference_state
    selected_scores = reference_scores
    selected_mean_gain = 0.0
    selected_worst_gain = 0.0
    selected_robust_gain = float('-inf')
    passed = False
    diagnostics: list[tuple[float, float, float, dict[str, Any], tuple[float, ...]]] = []
    for state, scores in candidates:
        if len(scores) != len(reference_scores):
            raise ValueError('all candidates require matching calibration folds')
        gains = tuple(((float(base) - float(trial)) / max(abs(float(base)), 1e-30) for base, trial in zip(reference_scores, scores)))
        mean_gain = _hq_mean(gains)
        worst_gain = min(gains)
        robust_gain = mean_gain + 0.25 * worst_gain
        diagnostics.append((robust_gain, mean_gain, worst_gain, state, scores))
        eligible = mean_gain >= float(mean_gain_min) and worst_gain >= float(worst_gain_min)
        if eligible and (not passed or robust_gain > selected_robust_gain):
            selected_state = state
            selected_scores = scores
            selected_mean_gain = mean_gain
            selected_worst_gain = worst_gain
            selected_robust_gain = robust_gain
            passed = True
    best_tested = max(diagnostics, key=lambda item: item[0])
    best_tested_state = best_tested[3]
    result = {key: value for key, value in selected_state.items()}
    result.update({'selection_policy': 'fixed-d-block-outlier-prefix-proxy', 'selection_score': float(_hq_mean(selected_scores)), 'reference_score': float(_hq_mean(reference_scores)), 'rotation_candidate_score': float(_hq_mean(best_tested[4])), 'mean_proxy_gain': float(selected_mean_gain if passed else best_tested[1]), 'worst_proxy_gain': float(selected_worst_gain if passed else best_tested[2]), 'gate_passed': bool(passed), 'fold_count': int(len(reference_scores)), 'candidate_count': int(1 + len(candidates)), 'tested_rotation_active_fraction': 1.0, 'tested_rotation_steps': int(best_tested_state.get('rotation_steps', 0)), 'tested_rotation_kind': str(best_tested_state.get('rotation_kind', 'unknown')), 'tested_rotation_subgroup_size': int(best_tested_state.get('rotation_subgroup_size', 0))})
    return result

def _fine_neighbors(value: float, step: float, lower: float, upper: float) -> tuple[float, ...]:
    neighbors: list[float] = []
    for candidate in (float(value) - float(step), float(value) + float(step)):
        clipped = min(max(candidate, float(lower)), float(upper))
        rounded = round(clipped, 6)
        if rounded != round(float(value), 6) and rounded not in neighbors:
            neighbors.append(rounded)
    return tuple(neighbors)

def select_linear_transform(weight: torch.Tensor, calib_activation_list: list) -> dict[str, Any]:
    """Gate one low-cost block-64 outlier rotation on top of fixed reciprocal D."""
    weight32 = weight.to(torch.float32)
    channels = int(weight32.shape[-1])
    weight_amax = weight32.abs().amax(dim=0)
    activation_samples: list[torch.Tensor] = []
    activation_amax = torch.zeros(channels, dtype=torch.float32)
    for quant, scale in calib_activation_list:
        activation = dequantize_nvfp4(quant, scale).to(torch.float32)
        activation_amax = torch.maximum(activation_amax, activation.abs().amax(dim=0))
        activation_samples.append(_hq_sample_rows(activation, 32))
    sample_x = torch.cat(activation_samples, dim=0)
    fold_slices: list[tuple[int, int]] = []
    fold_start = 0
    for sample in activation_samples:
        fold_end = fold_start + int(sample.shape[0])
        fold_slices.append((fold_start, fold_end))
        fold_start = fold_end
    sample_w = _hq_sample_rows(weight32, 128)
    smooth_scale = _linear_scale(activation_amax, weight_amax, LINEAR_FIXED_ALPHA)
    reference_state: dict[str, Any] = {'version': 'linear-block-outlier', 'mode': 'smooth', 'alpha': float(LINEAR_FIXED_ALPHA), 'smooth_scale': smooth_scale.to(torch.float32).cpu(), 'rotation_block_size': 0}
    peak_rotation = build_duquant_rotation(sample_x / smooth_scale, sample_w * smooth_scale, seed=17)
    rotation_steps = sorted({1, 2, 4, DUQUANT_GREEDY_MAX_STEPS, int(peak_rotation['rotation_steps'])})
    candidate_states: list[dict[str, Any]] = []
    for steps in rotation_steps:
        if steps <= 0:
            continue
        rotation = build_duquant_rotation(sample_x / smooth_scale, sample_w * smooth_scale, forced_steps=steps, seed=17)
        candidate_states.append({**reference_state, **rotation, 'mode': 'smooth_outlier_rotation'})
    givens_peak = build_hif4_givens_rotation(sample_x / smooth_scale, sample_w * smooth_scale)
    givens_steps = sorted({1, 2, 4, HIF4_GIVENS_MAX_STEPS, int(givens_peak['rotation_steps'])})
    for steps in givens_steps:
        if steps <= 0:
            continue
        rotation = build_hif4_givens_rotation(sample_x / smooth_scale, sample_w * smooth_scale, forced_steps=steps)
        candidate_states.append({**reference_state, **rotation, 'mode': 'smooth_outlier_rotation'})

    def evaluate(state: dict[str, Any]) -> tuple[dict[str, Any], tuple[float, ...]]:
        transformed_x = transform_linear_activation(sample_x, state)
        transformed_w = transform_linear_weight(sample_w, state)
        reconstructed_x = dequantize_hif4(quantize_hif4(transformed_x, search_multipliers=FAST_SEARCH_MULTIPLIERS))
        reconstructed_w = dequantize_hif4(quantize_hif4(transformed_w, search_multipliers=FAST_SEARCH_MULTIPLIERS))
        w_energy = transformed_w.square().mean(dim=0)
        fold_scores: list[float] = []
        for start, end in fold_slices:
            fold_x = transformed_x[start:end]
            fold_rx = reconstructed_x[start:end]
            x_energy = fold_x.square().mean(dim=0)
            score = (_normalized_weighted_error(transformed_w, reconstructed_w, x_energy) + _normalized_weighted_error(fold_x, fold_rx, w_energy)).item()
            fold_scores.append(float(score))
        return (state, tuple(fold_scores))
    return _select_outlier_state(evaluate(reference_state), [evaluate(state) for state in candidate_states])

def _attention_scale(q_amax: torch.Tensor, k_amax: torch.Tensor, strength: float) -> torch.Tensor:
    eps = 1e-08
    base = torch.sqrt((q_amax + eps) / (k_amax + eps))
    scale = _safe_geometric_normalize(base).pow(float(strength))
    return torch.pow(2.0, torch.log2(scale).clamp(-3.0, 3.0))

def _expand_q_group_tensor(grouped: torch.Tensor, q_num_heads: int, kv_num_heads: int) -> torch.Tensor:
    group_size = int(q_num_heads) // int(kv_num_heads)
    return grouped.repeat_interleave(group_size, dim=0)

def transform_attention_q(q: torch.Tensor, q_num_heads: int, head_dim: int, state: dict[str, Any] | None) -> torch.Tensor:
    if not state or state.get('mode') == 'direct':
        return q.to(torch.float32)
    kv_num_heads = int(state['kv_num_heads'])
    heads = q.to(torch.float32).reshape(-1, int(q_num_heads), int(head_dim))
    scale = _expand_q_group_tensor(state['smooth_scale'].to(torch.float32), q_num_heads, kv_num_heads)
    result = heads / scale[None, :, :]
    block_size = int(state.get('rotation_block_size', 0))
    if block_size:
        if 'rotation_pairs' in state:
            result = hif4_givens_transform(result, state)
        elif 'rotation_matrix' in state:
            result = duquant_transform(result, state)
        elif 'rotation_vectors' in state:
            result = greedy_outlier_transform(result, state)
        elif 'rotation_indices' in state:
            q_rotation = {key: value for key, value in state.items() if key.startswith('rotation_')}
            for key in ('rotation_indices', 'rotation_signs', 'rotation_active'):
                q_rotation[key] = _expand_q_group_tensor(state[key], q_num_heads, kv_num_heads)
            result = sparse_outlier_transform(result, q_rotation)
        else:
            signs = _expand_q_group_tensor(state['rotation_signs'], q_num_heads, kv_num_heads)
            result = hadamard_transform(result, block_size, signs[None, :, :])
    return result.reshape(q.shape)

def transform_attention_k(k: torch.Tensor, kv_num_heads: int, head_dim: int, state: dict[str, Any] | None) -> torch.Tensor:
    if not state or state.get('mode') == 'direct':
        return k.to(torch.float32)
    heads = k.to(torch.float32).reshape(-1, int(kv_num_heads), int(head_dim))
    result = heads * state['smooth_scale'].to(torch.float32)[None, :, :]
    block_size = int(state.get('rotation_block_size', 0))
    if block_size:
        if 'rotation_pairs' in state:
            result = hif4_givens_transform(result, state)
        elif 'rotation_matrix' in state:
            result = duquant_transform(result, state)
        elif 'rotation_vectors' in state:
            result = greedy_outlier_transform(result, state)
        elif 'rotation_indices' in state:
            result = sparse_outlier_transform(result, state)
        else:
            result = hadamard_transform(result, block_size, state['rotation_signs'].to(torch.float32)[None, :, :])
    return result.reshape(k.shape)

def select_attention_transform(calib_qkv_list: list, q_num_heads: int, kv_num_heads: int, head_dim: int) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    """Gate one shared block-64 Q/K outlier rotation on top of fixed reciprocal D."""
    group_size = int(q_num_heads) // int(kv_num_heads)
    q_samples: list[torch.Tensor] = []
    k_samples: list[torch.Tensor] = []
    q_amax = torch.zeros((kv_num_heads, head_dim), dtype=torch.float32)
    k_amax = torch.zeros((kv_num_heads, head_dim), dtype=torch.float32)
    for sample in calib_qkv_list:
        q = dequantize_nvfp4(*sample['q']).to(torch.float32)
        k = dequantize_nvfp4(*sample['k']).to(torch.float32)
        q_heads = q.reshape(-1, q_num_heads, head_dim).reshape(-1, kv_num_heads, group_size, head_dim)
        k_heads = k.reshape(-1, kv_num_heads, head_dim)
        q_amax = torch.maximum(q_amax, q_heads.abs().amax(dim=(0, 2)))
        k_amax = torch.maximum(k_amax, k_heads.abs().amax(dim=0))
        q_samples.append(_hq_sample_rows(q, 32))
        k_samples.append(_hq_sample_rows(k, 32))
    sample_q = torch.cat(q_samples, dim=0)
    sample_k = torch.cat(k_samples, dim=0)
    fold_slices: list[tuple[int, int]] = []
    fold_start = 0
    for q_sample, k_sample in zip(q_samples, k_samples):
        if int(q_sample.shape[0]) != int(k_sample.shape[0]):
            raise ValueError('paired calibration Q/K samples must have the same row count')
        fold_end = fold_start + int(q_sample.shape[0])
        fold_slices.append((fold_start, fold_end))
        fold_start = fold_end
    smooth_scale = _attention_scale(q_amax, k_amax, ATTENTION_FIXED_STRENGTH)
    reference_state: dict[str, Any] = {'version': 'attention-qk-block-outlier', 'mode': 'reciprocal_smooth', 'strength': float(ATTENTION_FIXED_STRENGTH), 'kv_num_heads': int(kv_num_heads), 'smooth_scale': smooth_scale.cpu(), 'rotation_block_size': 0}
    q_reference = transform_attention_q(sample_q, q_num_heads, head_dim, reference_state)
    k_reference = transform_attention_k(sample_k, kv_num_heads, head_dim, reference_state)
    peak_rotation = build_duquant_rotation(q_reference.reshape(-1, head_dim), k_reference.reshape(-1, head_dim), seed=29)
    rotation_steps = sorted({1, 2, 4, DUQUANT_GREEDY_MAX_STEPS, int(peak_rotation['rotation_steps'])})
    candidate_states: list[dict[str, Any]] = []
    for steps in rotation_steps:
        if steps <= 0:
            continue
        rotation = build_duquant_rotation(q_reference.reshape(-1, head_dim), k_reference.reshape(-1, head_dim), forced_steps=steps, seed=29)
        candidate_states.append({**reference_state, **rotation, 'mode': 'reciprocal_smooth_outlier_rotation'})
    givens_peak = build_hif4_givens_rotation(q_reference.reshape(-1, head_dim), k_reference.reshape(-1, head_dim))
    givens_steps = sorted({1, 2, 4, HIF4_GIVENS_MAX_STEPS, int(givens_peak['rotation_steps'])})
    for steps in givens_steps:
        if steps <= 0:
            continue
        rotation = build_hif4_givens_rotation(q_reference.reshape(-1, head_dim), k_reference.reshape(-1, head_dim), forced_steps=steps)
        candidate_states.append({**reference_state, **rotation, 'mode': 'reciprocal_smooth_outlier_rotation'})

    def evaluate(state: dict[str, Any]) -> tuple[dict[str, Any], tuple[float, ...]]:
        transformed_q = transform_attention_q(sample_q, q_num_heads, head_dim, state)
        transformed_k = transform_attention_k(sample_k, kv_num_heads, head_dim, state)
        reconstructed_q = dequantize_hif4(quantize_hif4(transformed_q, search_multipliers=FAST_SEARCH_MULTIPLIERS))
        reconstructed_k = dequantize_hif4(quantize_hif4(transformed_k, search_multipliers=FAST_SEARCH_MULTIPLIERS))
        qh = transformed_q.reshape(-1, q_num_heads, head_dim)
        kh = transformed_k.reshape(-1, kv_num_heads, head_dim)
        qrh = reconstructed_q.reshape_as(qh)
        krh = reconstructed_k.reshape_as(kh)
        fold_scores: list[float] = []
        for start, end in fold_slices:
            fold_q = qh[start:end]
            fold_k = kh[start:end]
            fold_qr = qrh[start:end]
            fold_kr = krh[start:end]
            q_group_energy = fold_q.reshape(-1, kv_num_heads, group_size, head_dim).square().mean(dim=(0, 2))
            k_energy = fold_k.square().mean(dim=0)
            expanded_k_energy = _expand_q_group_tensor(k_energy, q_num_heads, kv_num_heads)
            q_score = _normalized_weighted_error(fold_q, fold_qr, expanded_k_energy[None, :, :])
            k_score = _normalized_weighted_error(fold_k, fold_kr, q_group_energy[None, :, :])
            fold_scores.append(float((q_score + k_score).item()))
        return (state, tuple(fold_scores))
    best_state = _select_outlier_state(evaluate(reference_state), [evaluate(state) for state in candidate_states])
    q_state = {key: value for key, value in best_state.items()}
    k_state = {key: value for key, value in best_state.items()}
    v_state: dict[str, Any] = {'version': 'attention-value-direct', 'mode': 'direct'}
    return (q_state, k_state, v_state)
'HiF4 hierarchy-aware permutation and calibration-aware GPTQ rounding.\n\nThe rounding core is adapted from the user-supplied external baseline\n``nvfp4_to_hif4_cal (15).py`` (SHA256\n108EADF94A548ABF51FB2B33CAF49C9002E309A39C0AA02866FDFFC3C7EB44ED).\nIt optimizes Weight rounding from Activation covariance only; it never forms\nLinear reference outputs and never uses held-out test tensors for selection.\n'
GPTQ_RANK = 32
GPTQ_SCHWARZ_GROUP = 2
GPTQ_SCHWARZ_SWEEPS = 1
GPTQ_WEIGHT_GRID_STRENGTH = 0.4
ACTIVATION_GPTQ_RANK = 64
ACTIVATION_GPTQ_MAX_CHANNELS = 64
PERMUTATION_MEAN_GAIN_MIN = 0.005
PERMUTATION_WORST_GAIN_MIN = -0.005
LINEAR_HADAMARD_BLOCK_SIZE = 32
LINEAR_HADAMARD_SIGN_SEED = 0
_E6M2_VALUES = torch.tensor(sorted({float(2.0 ** ((byte >> 2 & 63) - 48) * (1.0 + (byte & 3) / 4.0)) for byte in range(255)}), dtype=torch.float32)
_E6M2_OFFSETS = torch.tensor((-1, 0, 1, 2, 3), dtype=torch.long)
_HIERARCHY_MULTIPLIERS = torch.tensor((1.0, 2.0, 4.0), dtype=torch.float32)

def _encode_blocks(target: torch.Tensor, chunk_blocks: int=1024, channel_weight: torch.Tensor | None=None) -> tuple[torch.Tensor, ...]:
    """Encode blocks, optionally weighting scale-grid error by Hessian diagonal."""
    block_count = int(target.shape[0])
    if channel_weight is not None and tuple(channel_weight.shape) != tuple(target.shape):
        raise ValueError('channel_weight must match the flattened block shape')
    sign = torch.sign(target.to(torch.float32))
    sf_out = torch.empty(block_count, dtype=torch.float32)
    mant_out = torch.empty((block_count, 64), dtype=torch.long)
    lv2_exp_out = torch.empty((block_count, 8), dtype=torch.long)
    lv3_exp_out = torch.empty((block_count, 16), dtype=torch.long)
    for start in range(0, block_count, int(chunk_blocks)):
        end = min(start + int(chunk_blocks), block_count)
        count = end - start
        block = target[start:end].to(torch.float32)
        magnitude = block.abs().reshape(count, 16, 4)
        local_weight = channel_weight[start:end].to(torch.float32).reshape(count, 16, 4) if channel_weight is not None else None
        group8_max = magnitude.amax(dim=2).reshape(count, 8, 2).amax(dim=2)
        center = torch.searchsorted(_E6M2_VALUES, group8_max.amax(dim=1) / 7.0)
        center = center.clamp(0, int(_E6M2_VALUES.numel()) - 1)
        candidate_indices = (center[:, None] + _E6M2_OFFSETS[None, :]).clamp(0, int(_E6M2_VALUES.numel()) - 1)
        candidates = _E6M2_VALUES.index_select(0, candidate_indices.reshape(-1)).reshape(count, 5)
        inverse_quarter = 4.0 / (candidates[:, :, None] * _HIERARCHY_MULTIPLIERS[None, None, :])
        error_scale = 1.0 / (inverse_quarter.square() * 16.0)
        errors = torch.empty((count, 5, 8, 2, 3), dtype=torch.float32)
        mantissas: list[torch.Tensor] = []
        for multiplier_index in range(3):
            q4 = magnitude[:, None, :, :] * inverse_quarter[:, :, multiplier_index, None, None]
            mantissa = torch.floor(q4 + 0.5 - 1e-09).to(torch.long).clamp_(0, 7)
            local_error = (q4 - mantissa.to(torch.float32)).square() * error_scale[:, :, multiplier_index, None, None]
            if local_weight is not None:
                local_error = local_error * local_weight[:, None, :, :]
            errors[:, :, :, :, multiplier_index] = local_error.sum(dim=3).reshape(count, 5, 8, 2)
            mantissas.append(mantissa)
        lv3_for_lv2_zero = errors[:, :, :, :, 1] < errors[:, :, :, :, 0]
        lv3_for_lv2_one = errors[:, :, :, :, 2] < errors[:, :, :, :, 1]
        lv2_zero_error = torch.where(lv3_for_lv2_zero, errors[:, :, :, :, 1], errors[:, :, :, :, 0]).sum(dim=3)
        lv2_one_error = torch.where(lv3_for_lv2_one, errors[:, :, :, :, 2], errors[:, :, :, :, 1]).sum(dim=3)
        use_lv2_one = lv2_one_error < lv2_zero_error
        lv2_exp = use_lv2_one.to(torch.long)
        lv3_exp = torch.where(use_lv2_one[:, :, :, None], lv3_for_lv2_one.to(torch.long), lv3_for_lv2_zero.to(torch.long))
        multiplier_index = lv2_exp.repeat_interleave(8, dim=2) + lv3_exp.reshape(count, 5, 16).repeat_interleave(4, dim=2)
        mantissa_tables = [value.reshape(count, 5, 64) for value in mantissas]
        mantissa = torch.where(multiplier_index == 0, mantissa_tables[0], torch.where(multiplier_index == 1, mantissa_tables[1], mantissa_tables[2]))
        encoded_without_base = mantissa.to(torch.float32) * (0.25 * torch.pow(2.0, multiplier_index.to(torch.float32)))
        absolute_block = block.abs()
        flat_weight = local_weight.reshape(count, 64) if local_weight is not None else None
        weighted_encoded = encoded_without_base * flat_weight[:, None, :] if flat_weight is not None else encoded_without_base
        least_squares_scale = (absolute_block[:, None, :] * weighted_encoded).sum(dim=2) / (encoded_without_base * weighted_encoded).sum(dim=2).clamp_min(1e-30)
        upper_index = torch.searchsorted(_E6M2_VALUES, least_squares_scale.reshape(-1)).clamp(0, int(_E6M2_VALUES.numel()) - 1).reshape(count, 5)
        lower_index = (upper_index - 1).clamp_min(0)
        upper = _E6M2_VALUES.index_select(0, upper_index.reshape(-1)).reshape(count, 5)
        lower = _E6M2_VALUES.index_select(0, lower_index.reshape(-1)).reshape(count, 5)
        best_scale = torch.where((upper - least_squares_scale).abs() < (lower - least_squares_scale).abs(), upper, lower)
        reconstruction = sign[start:end, None, :] * encoded_without_base * best_scale[:, :, None]
        candidate_error = (block[:, None, :] - reconstruction).square()
        if flat_weight is not None:
            candidate_error = candidate_error * flat_weight[:, None, :]
        candidate_sse = candidate_error.sum(dim=2)
        winner = candidate_sse.argmin(dim=1)
        batch_index = torch.arange(count)
        sf_out[start:end] = best_scale[batch_index, winner]
        mant_out[start:end] = mantissa[batch_index, winner]
        lv2_exp_out[start:end] = lv2_exp[batch_index, winner]
        lv3_exp_out[start:end] = lv3_exp[batch_index, winner].reshape(count, 16)
    return (sf_out, lv2_exp_out, lv3_exp_out, mant_out, sign)

def _pack(sf: torch.Tensor, lv2_exp: torch.Tensor, lv3_exp: torch.Tensor, mantissa: torch.Tensor, sign: torch.Tensor, shape: tuple[int, ...]) -> dict[str, torch.Tensor]:
    blocks_per_row = int(shape[-1]) // 64
    prefix = shape[:-1] + (blocks_per_row,)
    return {'scale_factor': sf.reshape(prefix + (1, 1, 1)).to(torch.bfloat16), 'scale_lv2': torch.pow(2.0, lv2_exp.to(torch.float32)).reshape(prefix + (8, 1, 1)).to(torch.bfloat16), 'scale_lv3': torch.pow(2.0, lv3_exp.to(torch.float32)).reshape(prefix + (8, 2, 1)).to(torch.bfloat16), 'sign': sign.reshape(prefix + (8, 2, 4)).to(torch.bfloat16), 'mant': (mantissa.to(torch.float32) * 0.25).reshape(prefix + (8, 2, 4)).to(torch.bfloat16)}

def quantize_hif4_direct(tensor: torch.Tensor) -> dict[str, torch.Tensor]:
    shape = tuple((int(value) for value in tensor.shape))
    if not shape or shape[-1] % 64:
        raise ValueError('HiF4 requires a non-empty last dimension divisible by 64')
    target = tensor.detach().to(dtype=torch.float32, device='cpu').contiguous().reshape(-1, 64)
    return _pack(*_encode_blocks(target), shape)

def streaming_svd(stream_fn: Callable[[], Iterable[torch.Tensor]], channels: int, rank: int=GPTQ_RANK) -> dict[str, torch.Tensor]:
    """Three-pass deterministic Krylov approximation of Activation covariance."""
    k = min(int(rank), int(channels))
    generator = torch.Generator(device='cpu')
    generator.manual_seed(0)
    basis = torch.randn((channels, k), generator=generator, dtype=torch.float32)
    channel_energy = torch.zeros(channels, dtype=torch.float32)
    for iteration in range(2):
        covariance_times_basis = torch.zeros((channels, k), dtype=torch.float32)
        for batch in stream_fn():
            x = batch.to(torch.float32).reshape(-1, channels)
            if iteration == 0:
                channel_energy += x.square().sum(dim=0)
            covariance_times_basis += x.T @ (x @ basis)
        basis, _ = torch.linalg.qr(covariance_times_basis, mode='reduced')
    projected_covariance = torch.zeros((k, k), dtype=torch.float32)
    for batch in stream_fn():
        x = batch.to(torch.float32).reshape(-1, channels)
        projected = x @ basis
        projected_covariance += projected.T @ projected
    eigenvalues, eigenvectors = torch.linalg.eigh(projected_covariance)
    order = eigenvalues.argsort(descending=True)
    singular_values = eigenvalues.index_select(0, order).clamp_min(0.0).sqrt()
    right_vectors = (basis @ eigenvectors.index_select(1, order)).T
    weighted_vectors = right_vectors * singular_values[:, None]
    return {'vw': weighted_vectors.contiguous(), 'an_full': channel_energy.contiguous()}

def quantized_weight_hessian_svd(quantized_weight: torch.Tensor, rank: int=ACTIVATION_GPTQ_RANK, chunk_rows: int=256) -> dict[str, torch.Tensor]:
    """Low-rank ``Q(W).T @ Q(W)`` factor from the final legal HiF4 Weight.

    The randomized Krylov factor uses only the reconstructed ``Q(W)``.  An
    exact diagonal residual keeps the approximation positive and preserves
    per-channel output importance without retaining the original Weight.
    """
    weight = quantized_weight.detach().to(dtype=torch.float32, device='cpu')
    if weight.ndim != 2:
        raise ValueError('quantized Weight Hessian SVD requires a 2-D tensor')
    channels = int(weight.shape[1])

    def stream():
        for start in range(0, int(weight.shape[0]), int(chunk_rows)):
            yield weight[start:start + int(chunk_rows)]
    hessian = streaming_svd(stream, channels, rank)
    factor = hessian['vw']
    exact_diagonal = hessian['an_full']
    factor_diagonal = factor.square().sum(dim=0)
    diagonal_floor = exact_diagonal.mean().clamp_min(1e-30) * 1e-06
    residual_diagonal = (exact_diagonal - factor_diagonal).clamp_min(diagonal_floor)
    exact_columns = exact_diagonal.argsort(descending=True)[:min(ACTIVATION_GPTQ_MAX_CHANNELS, channels)].contiguous()
    selected_weight = weight.index_select(1, exact_columns)
    exact_block_hessian = selected_weight.T @ selected_weight
    exact_block_hessian = (0.5 * (exact_block_hessian + exact_block_hessian.T)).contiguous()
    return {'vw': factor.contiguous(), 'an_full': residual_diagonal.contiguous(), 'importance': exact_diagonal.contiguous(), 'exact_block_columns': exact_columns, 'exact_block_hessian': exact_block_hessian}

def _schwarz_loop(projected_error: torch.Tensor, current_error: torch.Tensor, group_columns: torch.Tensor, gathered_vectors: torch.Tensor, gram_low_rank: torch.Tensor, gram_hessian: torch.Tensor, standard_error: torch.Tensor, error_difference: torch.Tensor, alternate_error: torch.Tensor, patterns: torch.Tensor, bits: torch.Tensor, sweeps: int, pattern_count: int, group_size: int) -> torch.Tensor:
    group_count = int(group_columns.shape[0])
    row_count = int(current_error.shape[0])
    for _ in range(sweeps):
        for group_index in range(group_count):
            columns = group_columns[group_index]
            old_error = current_error[:, columns]
            error_without_group = torch.mm(projected_error, gathered_vectors[group_index]) - torch.mm(old_error, gram_low_rank[group_index])
            trial_error = standard_error[group_index].unsqueeze(0) + patterns * error_difference[group_index].unsqueeze(0)
            quadratic = torch.mm(trial_error.reshape(pattern_count * row_count, group_size), gram_hessian[group_index]).reshape(pattern_count, row_count, group_size)
            cost = (trial_error * (2.0 * error_without_group.unsqueeze(0) + quadratic)).sum(dim=2)
            best_pattern = cost.argmin(dim=0)
            choose_alternate = best_pattern[:, None] >> bits[None, :] & 1 == 1
            new_error = torch.where(choose_alternate, alternate_error[group_index], standard_error[group_index])
            delta = new_error - old_error
            current_error[:, columns] = new_error
            projected_error = projected_error + torch.mm(delta, gathered_vectors[group_index].T)
    return projected_error

def _schwarz_loop_exact_block(projected_error: torch.Tensor, current_error: torch.Tensor, group_columns: torch.Tensor, gathered_vectors: torch.Tensor, gram_low_rank: torch.Tensor, gram_hessian: torch.Tensor, exact_block_hessian: torch.Tensor, exact_block_correction: torch.Tensor, standard_error: torch.Tensor, error_difference: torch.Tensor, alternate_error: torch.Tensor, patterns: torch.Tensor, bits: torch.Tensor, sweeps: int, pattern_count: int, group_size: int) -> torch.Tensor:
    """Schwarz rounding with an exact residual on the selected channels."""
    group_count = int(group_columns.shape[0])
    row_count = int(current_error.shape[0])
    flat_columns = group_columns.reshape(-1)
    correction_projected = torch.mm(current_error[:, flat_columns], exact_block_correction)
    for _ in range(sweeps):
        for group_index in range(group_count):
            columns = group_columns[group_index]
            block_start = group_index * group_size
            block_end = block_start + group_size
            correction_self = exact_block_correction[block_start:block_end, block_start:block_end]
            old_error = current_error[:, columns]
            error_without_group = torch.mm(projected_error, gathered_vectors[group_index]) - torch.mm(old_error, gram_low_rank[group_index]) + correction_projected[:, block_start:block_end] - torch.mm(old_error, correction_self)
            trial_error = standard_error[group_index].unsqueeze(0) + patterns * error_difference[group_index].unsqueeze(0)
            corrected_group_hessian = exact_block_hessian[block_start:block_end, block_start:block_end]
            quadratic = torch.mm(trial_error.reshape(pattern_count * row_count, group_size), corrected_group_hessian).reshape(pattern_count, row_count, group_size)
            cost = (trial_error * (2.0 * error_without_group.unsqueeze(0) + quadratic)).sum(dim=2)
            best_pattern = cost.argmin(dim=0)
            choose_alternate = best_pattern[:, None] >> bits[None, :] & 1 == 1
            new_error = torch.where(choose_alternate, alternate_error[group_index], standard_error[group_index])
            delta = new_error - old_error
            current_error[:, columns] = new_error
            projected_error = projected_error + torch.mm(delta, gathered_vectors[group_index].T)
            correction_projected = correction_projected + torch.mm(delta, exact_block_correction[block_start:block_end])
    return projected_error

def _schwarz_round(target: torch.Tensor, svd: dict[str, torch.Tensor], channels: int, group_size: int=GPTQ_SCHWARZ_GROUP, sweeps: int=GPTQ_SCHWARZ_SWEEPS, max_channels: int=0, hessian_aware_grid: bool=False) -> tuple[torch.Tensor, ...]:
    weighted_vectors = svd['vw'].to(torch.float32)
    diagonal_energy = svd['an_full'].to(torch.float32)
    channel_energy = svd.get('importance', svd['an_full']).to(torch.float32)
    blocks_per_row = channels // 64
    row_count = int(target.shape[0]) // blocks_per_row
    rank = int(weighted_vectors.shape[0])
    grid_weight = None
    if bool(hessian_aware_grid):
        per_block_weight = channel_energy.reshape(blocks_per_row, 64)
        floor = per_block_weight.mean(dim=1, keepdim=True).clamp_min(1e-30) * 1e-06
        per_block_weight = per_block_weight.clamp_min(floor)
        per_block_weight = per_block_weight / per_block_weight.mean(dim=1, keepdim=True).clamp_min(1e-30)
        per_block_weight = torch.pow(per_block_weight.clamp_min(1e-30), float(GPTQ_WEIGHT_GRID_STRENGTH))
        grid_weight = per_block_weight.repeat(row_count, 1).contiguous()
    sf, lv2_exp, lv3_exp, standard_mantissa, sign = _encode_blocks(target, channel_weight=grid_weight)
    hierarchy_multiplier = torch.pow(2.0, lv2_exp.repeat_interleave(8, dim=1).to(torch.float32) + lv3_exp.repeat_interleave(4, dim=1).to(torch.float32))
    effective_scale = sf[:, None] * hierarchy_multiplier
    standard_error_global = torch.zeros((row_count, channels), dtype=torch.float32)
    alternate_error_global = torch.zeros((row_count, channels), dtype=torch.float32)
    alternate_mantissa_global = torch.zeros((row_count, channels), dtype=torch.long)
    for block_index in range(blocks_per_row):
        block_rows = torch.arange(row_count) * blocks_per_row + block_index
        q4 = target[block_rows].abs() / effective_scale[block_rows].clamp_min(1e-30) * 4.0
        lower = torch.floor(q4).to(torch.long).clamp_(0, 7)
        upper = (lower + 1).clamp_(0, 7)
        alternate = torch.where(standard_mantissa[block_rows] == lower, upper, lower)
        standard_error_global[:, block_index * 64:(block_index + 1) * 64] = target[block_rows] - sign[block_rows] * standard_mantissa[block_rows].to(torch.float32) * 0.25 * effective_scale[block_rows]
        alternate_error_global[:, block_index * 64:(block_index + 1) * 64] = target[block_rows] - sign[block_rows] * alternate.to(torch.float32) * 0.25 * effective_scale[block_rows]
        alternate_mantissa_global[:, block_index * 64:(block_index + 1) * 64] = alternate
    error_difference = alternate_error_global - standard_error_global
    current_error = standard_error_global.clone()
    projected_error = current_error @ weighted_vectors.T
    importance_order = channel_energy.argsort(descending=True)
    usable_channels = channels - channels % group_size
    if int(max_channels) > 0:
        limited = min(int(max_channels), usable_channels)
        usable_channels = limited - limited % group_size
    group_columns = importance_order[:usable_channels].reshape(-1, group_size)
    group_count = int(group_columns.shape[0])
    flat_columns = group_columns.reshape(-1)
    gathered_vectors = weighted_vectors[:, flat_columns].reshape(rank, group_count, group_size).permute(1, 0, 2).contiguous()
    gathered_energy = diagonal_energy[flat_columns].reshape(group_count, group_size)
    gram_low_rank = torch.bmm(gathered_vectors.transpose(1, 2), gathered_vectors).contiguous()
    gram_hessian = (gram_low_rank + torch.diag_embed(gathered_energy)).contiguous()
    standard_group_error = standard_error_global[:, flat_columns].reshape(row_count, group_count, group_size).permute(1, 0, 2).contiguous()
    difference_group_error = error_difference[:, flat_columns].reshape(row_count, group_count, group_size).permute(1, 0, 2).contiguous()
    alternate_group_error = alternate_error_global[:, flat_columns].reshape(row_count, group_count, group_size).permute(1, 0, 2).contiguous()
    pattern_count = 2 ** group_size
    patterns = (torch.arange(pattern_count)[:, None] >> torch.arange(group_size)[None, :] & 1).to(torch.float32).reshape(pattern_count, 1, group_size)
    bits = torch.arange(group_size)
    if 'exact_block_columns' in svd or 'exact_block_hessian' in svd:
        if 'exact_block_columns' not in svd or 'exact_block_hessian' not in svd:
            raise ValueError('exact block Hessian state is incomplete')
        exact_block_columns = svd['exact_block_columns'].to(torch.long)
        exact_block_hessian = svd['exact_block_hessian'].to(torch.float32)
        if not torch.equal(exact_block_columns, flat_columns):
            raise ValueError('exact block Hessian columns do not match the rounding budget')
        if tuple(exact_block_hessian.shape) != (usable_channels, usable_channels):
            raise ValueError('exact block Hessian has an invalid shape')
        selected_vectors = weighted_vectors.index_select(1, flat_columns)
        approximate_block_hessian = selected_vectors.T @ selected_vectors + torch.diag(diagonal_energy.index_select(0, flat_columns))
        approximate_block_hessian = 0.5 * (approximate_block_hessian + approximate_block_hessian.T)
        exact_block_correction = (exact_block_hessian - approximate_block_hessian).contiguous()
        _schwarz_loop_exact_block(projected_error, current_error, group_columns, gathered_vectors, gram_low_rank, gram_hessian, exact_block_hessian, exact_block_correction, standard_group_error, difference_group_error, alternate_group_error, patterns, bits, int(sweeps), int(pattern_count), int(group_size))
    else:
        _schwarz_loop(projected_error, current_error, group_columns, gathered_vectors, gram_low_rank, gram_hessian, standard_group_error, difference_group_error, alternate_group_error, patterns, bits, int(sweeps), int(pattern_count), int(group_size))
    optimized_mantissa = standard_mantissa.clone()
    for block_index in range(blocks_per_row):
        block_rows = torch.arange(row_count) * blocks_per_row + block_index
        channel_slice = slice(block_index * 64, (block_index + 1) * 64)
        uses_alternate = (current_error[:, channel_slice] - standard_error_global[:, channel_slice]).abs() > 1e-30
        optimized_mantissa[block_rows] = torch.where(uses_alternate, alternate_mantissa_global[:, channel_slice], standard_mantissa[block_rows])
    return (sf, lv2_exp, lv3_exp, optimized_mantissa, sign)

def quantize_hif4_gptq_weight(weight: torch.Tensor, svd: dict[str, torch.Tensor], sweeps: int=GPTQ_SCHWARZ_SWEEPS) -> dict[str, torch.Tensor]:
    if weight.ndim != 2:
        raise ValueError('GPTQ Weight encoder requires a 2-D tensor')
    return quantize_hif4_gptq_tensor(weight, svd, sweeps=sweeps, hessian_aware_grid=True)

def quantize_hif4_gptq_tensor(tensor: torch.Tensor, svd: dict[str, torch.Tensor], sweeps: int=GPTQ_SCHWARZ_SWEEPS, hessian_aware_grid: bool=False) -> dict[str, torch.Tensor]:
    """Hessian-aware adjacent rounding for any tensor with block-64 channels."""
    shape = tuple((int(value) for value in tensor.shape))
    if not shape or shape[-1] % 64:
        raise ValueError('GPTQ encoder requires a non-empty tensor with block-64 channels')
    target = tensor.detach().to(dtype=torch.float32, device='cpu').contiguous().reshape(-1, 64)
    rounded = _schwarz_round(target, svd, shape[-1], sweeps=int(sweeps), hessian_aware_grid=bool(hessian_aware_grid))
    return _pack(*rounded, shape)

def refine_hif4_activation_exact_block64(tensor: torch.Tensor, params: dict[str, torch.Tensor], svd: dict[str, torch.Tensor], *, sweeps: int=2) -> dict[str, torch.Tensor]:
    """Optimize every Activation code under global+block-exact Q(W) Hessian.

    The global model is rank-8 plus diagonal.  For every contiguous HiF4
    block, ``activation_block_hessian`` replaces that approximation with the
    exact ``Q(W_block).T @ Q(W_block)``.  Scalar integer coordinate descent
    searches the complete legal signed-code range [-7, 7], keeps the current
    point as a candidate, and therefore monotonically decreases this legal
    quadratic proxy without ever forming ``A @ W``.
    """
    shape = tuple((int(value) for value in tensor.shape))
    channels = int(shape[-1])
    rows = int(tensor.numel()) // channels
    blocks_per_row = channels // 64
    target = tensor.detach().to(torch.float32).reshape(rows, channels)
    factor = svd['vw'].to(torch.float32)
    diagonal = svd['an_full'].to(torch.float32)
    block_hessians = svd['activation_block_hessian'].to(torch.float32)
    if tuple(block_hessians.shape) != (blocks_per_row, 64, 64):
        raise ValueError('invalid exact Activation block Hessian shape')
    code_shape = tuple((int(value) for value in params['mant'].shape))
    step = (params['scale_factor'].to(torch.float32) * params['scale_lv2'].to(torch.float32) * params['scale_lv3'].to(torch.float32) * 0.25).expand_as(params['mant']).reshape(rows, channels).clamp_min(1e-30)
    codes = (params['sign'].to(torch.float32) * params['mant'].to(torch.float32) * 4.0).reshape(rows, channels).round().clamp_(-7.0, 7.0)
    error = target - codes * step
    projected = error @ factor.T
    global_columns = svd.get('activation_global_exact_columns')
    global_exact = svd.get('activation_global_exact_hessian')
    global_position = torch.full((channels,), -1, dtype=torch.long)
    global_correction = None
    if global_columns is not None or global_exact is not None:
        if global_columns is None or global_exact is None:
            raise ValueError('incomplete global exact Activation Hessian state')
        global_columns = global_columns.to(torch.long)
        global_exact = global_exact.to(torch.float32)
        selected_count = int(global_columns.numel())
        if tuple(global_exact.shape) != (selected_count, selected_count):
            raise ValueError('invalid global exact Activation Hessian shape')
        global_position[global_columns] = torch.arange(selected_count, dtype=torch.long)
        selected_factor = factor.index_select(1, global_columns)
        global_approximate = selected_factor.T @ selected_factor + torch.diag(diagonal.index_select(0, global_columns))
        for block in range(blocks_per_row):
            in_block = global_columns // 64 == block
            positions = torch.nonzero(in_block, as_tuple=False).reshape(-1)
            if int(positions.numel()) == 0:
                continue
            local_columns = global_columns.index_select(0, positions) - block * 64
            local_factor = factor[:, block * 64:(block + 1) * 64]
            local_diagonal = diagonal[block * 64:(block + 1) * 64]
            block_approximate = local_factor.T @ local_factor + torch.diag(local_diagonal)
            block_correction = block_hessians[block] - block_approximate
            global_approximate[positions[:, None], positions[None, :]] += block_correction.index_select(0, local_columns).index_select(1, local_columns)
        global_correction = global_exact - global_approximate
    for _ in range(int(sweeps)):
        for block in range(blocks_per_row):
            start = block * 64
            end = start + 64
            local_factor = factor[:, start:end]
            local_diagonal = diagonal[start:end]
            exact = block_hessians[block]
            approximate = local_factor.T @ local_factor + torch.diag(local_diagonal)
            correction = exact - approximate
            local_error = error[:, start:end]
            for local_column in range(64):
                column = start + local_column
                old_error = error[:, column]
                hessian_times_error = projected @ factor[:, column] + local_diagonal[local_column] * old_error + local_error @ correction[:, local_column]
                selected_position = int(global_position[column].item())
                global_diagonal_correction = torch.tensor(0.0, dtype=torch.float32)
                if selected_position >= 0 and global_correction is not None:
                    hessian_times_error = hessian_times_error + error.index_select(1, global_columns) @ global_correction[:, selected_position]
                    global_diagonal_correction = global_correction[selected_position, selected_position]
                hessian_diagonal = (exact[local_column, local_column] + global_diagonal_correction).clamp_min(1e-20)
                cross = hessian_times_error - hessian_diagonal * old_error
                proposal_code = torch.round((target[:, column] + cross / hessian_diagonal) / step[:, column]).clamp_(-7.0, 7.0)
                proposal_error = target[:, column] - proposal_code * step[:, column]
                delta = proposal_error - old_error
                objective_delta = 2.0 * delta * cross + delta.square() * hessian_diagonal
                accepted_delta = torch.where(objective_delta < -1e-12, delta, torch.zeros_like(delta))
                changed = accepted_delta != 0.0
                if bool(changed.any().item()):
                    codes[:, column] = torch.where(changed, proposal_code, codes[:, column])
                    error[:, column] = old_error + accepted_delta
                    projected = projected + accepted_delta[:, None] * factor[:, column][None, :]
    result = dict(params)
    result['sign'] = torch.sign(codes).reshape(code_shape).to(torch.bfloat16)
    result['mant'] = (codes.abs() * 0.25).reshape(code_shape).to(torch.bfloat16)
    return result

def quantize_hif4_gptq_tensor_fast(tensor: torch.Tensor, svd: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
    """Optimize Weight-sensitive channels with an exact local Hessian block."""
    shape = tuple((int(value) for value in tensor.shape))
    if not shape or shape[-1] % 64:
        raise ValueError('fast GPTQ encoder requires block-64 channels')
    target = tensor.detach().to(dtype=torch.float32, device='cpu').contiguous().reshape(-1, 64)
    rounded = _schwarz_round(target, svd, shape[-1], sweeps=GPTQ_SCHWARZ_SWEEPS, max_channels=ACTIVATION_GPTQ_MAX_CHANNELS)
    return _pack(*rounded, shape)

def transform_linear_tensor(tensor: torch.Tensor, state: dict[str, Any], *, inverse_scale: bool) -> torch.Tensor:
    scale = state['smooth_scale'].to(torch.float32)
    result = tensor.to(torch.float32) / scale if inverse_scale else tensor.to(torch.float32) * scale
    permutation = state['permutation'].to(torch.long)
    result = result.index_select(-1, permutation)
    block_size = int(state.get('linear_hadamard_block_size', 0))
    if block_size:
        result = hadamard_transform(result, block_size, state['linear_hadamard_signs'])
    return result

def _within16_permutation(activation_amax: torch.Tensor, weight_amax: torch.Tensor) -> torch.Tensor:
    channels = int(activation_amax.numel())
    eps = 1e-12
    log_a = torch.log2(activation_amax.to(torch.float64).clamp_min(eps))
    log_w = torch.log2(weight_amax.to(torch.float64).clamp_min(eps))
    log_a -= log_a.mean()
    log_w -= log_w.mean()
    joint = 0.5 * (log_a + log_w)
    pieces: list[torch.Tensor] = []
    for start in range(0, channels, 16):
        original = torch.arange(start, start + 16, dtype=torch.long)
        local = torch.argsort(joint.index_select(0, original), stable=True)
        pieces.append(original.index_select(0, local))
    return torch.cat(pieces)

def _hg_sample_rows(tensor: torch.Tensor, maximum_rows: int) -> torch.Tensor:
    rows = int(tensor.shape[0])
    if rows <= maximum_rows:
        return tensor
    indices = torch.linspace(0, rows - 1, steps=maximum_rows).round().to(torch.long)
    return tensor.index_select(0, indices)

def _weighted_error(original: torch.Tensor, reconstructed: torch.Tensor, channel_weight: torch.Tensor) -> float:
    weight = channel_weight.to(torch.float64).clamp_min(1e-30)
    error = reconstructed.to(torch.float64) - original.to(torch.float64)
    numerator = (error.square() * weight).sum()
    denominator = (original.to(torch.float64).square() * weight).sum().clamp_min(1e-30)
    return float((numerator / denominator).item())

def select_linear_state(weight: torch.Tensor, calib_activation_list: list) -> dict[str, Any]:
    """Select a fixed D and gate one within-NVFP4-block hierarchy permutation."""
    weight32 = weight.to(torch.float32)
    channels = int(weight32.shape[-1])
    activation_folds: list[torch.Tensor] = []
    activation_amax = torch.zeros(channels, dtype=torch.float32)
    for quant, scale in calib_activation_list:
        activation = dequantize_nvfp4(quant, scale).to(torch.float32).reshape(-1, channels)
        activation_amax = torch.maximum(activation_amax, activation.abs().amax(dim=0))
        activation_folds.append(_hg_sample_rows(activation, 32))
    weight_amax = weight32.abs().amax(dim=0)
    smooth_scale = _linear_scale(activation_amax, weight_amax, LINEAR_FIXED_ALPHA)
    identity = torch.arange(channels, dtype=torch.long)
    candidate = _within16_permutation(activation_amax / smooth_scale, weight_amax * smooth_scale)
    rotation_state = {'linear_hadamard_block_size': int(LINEAR_HADAMARD_BLOCK_SIZE), 'linear_hadamard_sign_seed': int(LINEAR_HADAMARD_SIGN_SEED), 'linear_hadamard_signs': make_signs((channels,), LINEAR_HADAMARD_SIGN_SEED).cpu()}

    def fold_scores(permutation: torch.Tensor) -> tuple[float, ...]:
        state = {'smooth_scale': smooth_scale, 'permutation': permutation, **rotation_state}
        sampled_weight = _hg_sample_rows(weight32, 128)
        transformed_weight = transform_linear_tensor(sampled_weight, state, inverse_scale=False)
        reconstructed_weight = dequantize_hif4(quantize_hif4_direct(transformed_weight))
        scores: list[float] = []
        for activation in activation_folds:
            transformed_activation = transform_linear_tensor(activation, state, inverse_scale=True)
            reconstructed_activation = dequantize_hif4(quantize_hif4_direct(transformed_activation))
            activation_energy = transformed_activation.square().mean(dim=0)
            weight_energy = transformed_weight.square().mean(dim=0)
            scores.append(_weighted_error(transformed_weight, reconstructed_weight, activation_energy) + _weighted_error(transformed_activation, reconstructed_activation, weight_energy))
        return tuple(scores)
    reference_scores = fold_scores(identity)
    candidate_scores = fold_scores(candidate)
    gains = tuple(((reference - trial) / max(abs(reference), 1e-30) for reference, trial in zip(reference_scores, candidate_scores)))
    mean_gain = sum(gains) / len(gains)
    worst_gain = min(gains)
    gate_passed = mean_gain >= PERMUTATION_MEAN_GAIN_MIN and worst_gain >= PERMUTATION_WORST_GAIN_MIN
    selected = candidate if gate_passed else identity
    return {'version': 'linear-hierarchy-gptq', 'mode': 'smooth_hierarchy_gptq', 'alpha': float(LINEAR_FIXED_ALPHA), 'smooth_scale': smooth_scale.cpu(), 'permutation': selected.cpu(), 'permutation_scope': 16 if gate_passed else 0, 'permutation_gate_passed': bool(gate_passed), 'permutation_mean_proxy_gain': float(mean_gain), 'permutation_worst_proxy_gain': float(worst_gain), **rotation_state, 'linear_rotation_mode': 'signed_hadamard_two_halves_per_hif4_block', 'gptq_rank': int(GPTQ_RANK), 'gptq_schwarz_group': int(GPTQ_SCHWARZ_GROUP), 'gptq_schwarz_sweeps': int(GPTQ_SCHWARZ_SWEEPS)}
"Original-paper GPTQ adapted to a frozen hierarchical HiF4 grid.\n\nThe error-feedback loop follows Algorithm 1 of Frantar et al., GPTQ\n(arXiv:2210.17323) and the authors' reference ``gptq.py`` implementation:\nfixed column order, 1% Hessian damping, inverse-Hessian Cholesky factors,\n128-column lazy batches, and updates of all not-yet-quantized columns.\n\nThe paper assumes a fixed uniform grid.  Here the legal HiF4 base/lv2/lv3\nscales are selected once from the transformed Weight and then frozen.  GPTQ\nonly selects the signed mantissa code in [-7, 7].  Calibration uses A.T @ A\nonly; it never forms A @ W or fits the dynamic Activation quantizer.\n"
ORIGINAL_GPTQ_BLOCK_SIZE = 128
ORIGINAL_GPTQ_PERCDAMP = 0.01
ORIGINAL_GPTQ_CODE_LIMIT = 7

def accumulate_hessian(stream_fn: Callable[[], Iterable[torch.Tensor]], channels: int) -> tuple[torch.Tensor, int]:
    """Accumulate the exact calibration covariance without storing A."""
    hessian = torch.zeros((channels, channels), dtype=torch.float32)
    sample_count = 0
    for batch in stream_fn():
        activation = batch.detach().to(dtype=torch.float32, device='cpu').reshape(-1, channels)
        hessian += activation.T @ activation
        sample_count += int(activation.shape[0])
    if sample_count <= 0:
        raise ValueError('original GPTQ requires at least one calibration row')
    hessian /= float(sample_count)
    return (hessian, sample_count)

def inverse_hessian_cholesky(hessian: torch.Tensor, percdamp: float=ORIGINAL_GPTQ_PERCDAMP) -> tuple[torch.Tensor, float]:
    """Return the upper Cholesky factor of H^-1 used by GPTQ Algorithm 1."""
    matrix = hessian.detach().to(dtype=torch.float32, device='cpu').clone()
    if matrix.ndim != 2 or matrix.shape[0] != matrix.shape[1]:
        raise ValueError('Hessian must be a square matrix')
    diagonal = torch.diagonal(matrix)
    positive = diagonal[diagonal > 0]
    mean_diagonal = positive.mean() if int(positive.numel()) else torch.tensor(1.0)
    base_damp = max(float(mean_diagonal.item()) * float(percdamp), 1e-08)
    indices = torch.arange(int(matrix.shape[0]))
    for retry in range(5):
        damp = base_damp * 10.0 ** retry
        trial = matrix.clone()
        trial[indices, indices] += damp
        factor, info = torch.linalg.cholesky_ex(trial, check_errors=False)
        if int(info.max().item()) == 0:
            inverse = torch.cholesky_inverse(factor)
            return (torch.linalg.cholesky(inverse, upper=True), float(damp))
    raise RuntimeError('damped calibration Hessian is not positive definite')

def frozen_hif4_grid(weight: torch.Tensor) -> tuple[torch.Tensor, ...]:
    """Select legal hierarchy scales once and return their scalar grid step."""
    shape = tuple((int(value) for value in weight.shape))
    if len(shape) != 2 or shape[-1] % 64:
        raise ValueError('original GPTQ requires a 2-D block-64 Weight')
    blocks = weight.detach().to(dtype=torch.float32, device='cpu').contiguous().reshape(-1, 64)
    sf, lv2_exp, lv3_exp, _, _ = _encode_blocks(blocks)
    multiplier = torch.pow(2.0, lv2_exp.repeat_interleave(8, dim=1).to(torch.float32) + lv3_exp.repeat_interleave(4, dim=1).to(torch.float32))
    step = (sf[:, None] * multiplier * 0.25).reshape(shape)
    return (sf, lv2_exp, lv3_exp, step)

def quantize_hif4_original_gptq(weight: torch.Tensor, hessian: torch.Tensor, *, block_size: int=ORIGINAL_GPTQ_BLOCK_SIZE, percdamp: float=ORIGINAL_GPTQ_PERCDAMP) -> tuple[dict[str, torch.Tensor], dict[str, float | int | str | bool]]:
    """Quantize Weight with the original GPTQ Cholesky error-feedback loop."""
    shape = tuple((int(value) for value in weight.shape))
    if len(shape) != 2 or shape[-1] % 64:
        raise ValueError('original GPTQ requires a 2-D block-64 Weight')
    rows, channels = shape
    if tuple((int(value) for value in hessian.shape)) != (channels, channels):
        raise ValueError('Hessian shape does not match Weight input channels')
    if int(block_size) <= 0:
        raise ValueError('GPTQ block size must be positive')
    sf, lv2_exp, lv3_exp, step = frozen_hif4_grid(weight)
    hessian_factor, applied_damp = inverse_hessian_cholesky(hessian, percdamp)
    working = weight.detach().to(dtype=torch.float32, device='cpu').clone()
    codes = torch.empty((rows, channels), dtype=torch.int8)
    for block_start in range(0, channels, int(block_size)):
        block_end = min(block_start + int(block_size), channels)
        count = block_end - block_start
        working_block = working[:, block_start:block_end].clone()
        error_block = torch.empty_like(working_block)
        factor_block = hessian_factor[block_start:block_end, block_start:block_end]
        step_block = step[:, block_start:block_end]
        for local_column in range(count):
            current = working_block[:, local_column]
            scalar_step = step_block[:, local_column].clamp_min(1e-30)
            code = torch.round(current / scalar_step).clamp(-ORIGINAL_GPTQ_CODE_LIMIT, ORIGINAL_GPTQ_CODE_LIMIT)
            quantized = code * scalar_step
            codes[:, block_start + local_column] = code.to(torch.int8)
            diagonal = factor_block[local_column, local_column].clamp_min(1e-30)
            normalized_error = (current - quantized) / diagonal
            working_block[:, local_column:] -= normalized_error[:, None] * factor_block[local_column, local_column:][None, :]
            error_block[:, local_column] = normalized_error
        if block_end < channels:
            working[:, block_end:] -= error_block @ hessian_factor[block_start:block_end, block_end:]
    block_codes = codes.reshape(-1, 64)
    sign = torch.sign(block_codes).to(torch.float32)
    mantissa = block_codes.abs().to(torch.long)
    params = _pack(sf, lv2_exp, lv3_exp, mantissa, sign, shape)
    diagnostics: dict[str, float | int | str | bool] = {'gptq_kind': 'original_cholesky', 'gptq_block_size': int(block_size), 'gptq_percdamp': float(percdamp), 'gptq_applied_damp': float(applied_damp), 'gptq_cholesky': True, 'gptq_grid': 'frozen_hif4_hierarchy'}
    return (params, diagnostics)
"Structured mean-only Q/K transforms for the Attention candidate family.\n\nThe module keeps the platform-best hierarchy-gptq Linear path untouched and changes only\nAttention Q/K.  All transforms have the form::\n\n    Q' = (Q / D) P R\n    K' = (K * D) P R\n\nwhere P is a permutation and R is an orthogonal sequence of local Givens\nrotations.  The same transform is shared by the K head and every Q head in its\nGQA group, so the unquantized logits are preserved.  V remains direct because\nthe public API has no post-Attention inverse-transform hook.\n"
ATTENTION_STRUCTURED_MAX_CALIB_ROWS = 16
ATTENTION_Q_SCHWARZ_MAX_COLUMNS = 48
ATTENTION_K_SCHWARZ_MAX_COLUMNS = 64
ATTENTION_HIERARCHY_GRID_STRENGTH = 0.36
ATTENTION_HIERARCHY_WEIGHT_MIN = 0.25
ATTENTION_HIERARCHY_WEIGHT_MAX = 4.0
ATTENTION_STRUCTURED_MEAN_GAIN_MIN = 0.001
ATTENTION_STRUCTURED_PR_INCREMENTAL_GAIN_MIN = 0.0005
ATTENTION_STRUCTURED_CONSENSUS_FRACTION = 0.8
ATTENTION_STRUCTURED_ROTATION_PROFILES = {'r_only': ((1, 2, 4), (4, 8)), 'r_deep': ((1, 2, 4, 8), (4, 8)), 'r_block64': ((1, 2, 4), (4, 8, HIF4_BLOCK_SIZE)), 'r_wide': ((1, 2, 4, 8), (4, 8, HIF4_BLOCK_SIZE)), 'r_wide_robust': ((1, 2, 4, 8), (4, 8, HIF4_BLOCK_SIZE))}
ATTENTION_STRUCTURED_MAX_ROTATION_STEPS = max((max(profile[0]) for profile in ATTENTION_STRUCTURED_ROTATION_PROFILES.values()))
ATTENTION_STRUCTURED_PERMUTATION_RATIOS = (0.5, 1.0)
ATTENTION_STRUCTURED_VARIANTS = ('d_only', 'r_only', 'r_deep', 'r_block64', 'r_wide', 'r_wide_robust', 'p_only', 'p_then_r')

def _expand_group_tensor(grouped: torch.Tensor, q_num_heads: int, kv_num_heads: int) -> torch.Tensor:
    group_size = int(q_num_heads) // int(kv_num_heads)
    return grouped.repeat_interleave(group_size, dim=0)

def _apply_head_permutation(heads: torch.Tensor, permutation: torch.Tensor) -> torch.Tensor:
    indices = permutation.to(dtype=torch.long, device=heads.device)
    return torch.gather(heads, dim=-1, index=indices[None, :, :].expand(int(heads.shape[0]), -1, -1))

def center_attention_k(k: torch.Tensor, kv_num_heads: int, head_dim: int) -> torch.Tensor:
    """Subtract the per-head, per-channel mean across the key sequence.

    Every query's logits are shifted by one row-wise constant, so the
    unquantized softmax probabilities remain unchanged.
    """
    heads = k.to(torch.float32).reshape(-1, int(kv_num_heads), int(head_dim))
    if int(heads.shape[0]) == 0:
        raise ValueError('K centering requires at least one sequence row')
    centered = heads - heads.mean(dim=0, keepdim=True)
    return centered.reshape(k.shape)

def _apply_group_rotations(heads: torch.Tensor, group_steps: torch.Tensor, pairs: torch.Tensor, signs: torch.Tensor, *, q_num_heads: int, kv_num_heads: int) -> torch.Tensor:
    """Apply one block-64 Givens sequence per KV group."""
    result = heads.to(torch.float32).clone()
    block_size = HIF4_BLOCK_SIZE
    group_size = int(q_num_heads) // int(kv_num_heads)
    inverse_sqrt_two = 1.0 / math.sqrt(2.0)
    for kv_head in range(int(kv_num_heads)):
        steps = int(group_steps[kv_head].item())
        if steps <= 0:
            continue
        head_start = kv_head * group_size
        head_end = head_start + group_size
        group = result[:, head_start:head_end, :]
        original_shape = group.shape
        blocks = group.reshape(-1, block_size).clone()
        for step in range(steps):
            left_index = int(pairs[kv_head, step, 0].item())
            right_index = int(pairs[kv_head, step, 1].item())
            sign = float(signs[kv_head, step].item())
            left = blocks[:, left_index].clone()
            right = blocks[:, right_index].clone()
            blocks[:, left_index] = (left + sign * right) * inverse_sqrt_two
            blocks[:, right_index] = (-sign * left + right) * inverse_sqrt_two
        result[:, head_start:head_end, :] = blocks.reshape(original_shape)
    return result

def transform_attention_q_structured(q: torch.Tensor, q_num_heads: int, head_dim: int, state: dict[str, Any] | None) -> torch.Tensor:
    """Apply D, then optional hierarchy P, then optional local R to Q."""
    if not state or state.get('mode') == 'direct':
        return q.to(torch.float32)
    kv_num_heads = int(state['kv_num_heads'])
    heads = q.to(torch.float32).reshape(-1, int(q_num_heads), int(head_dim))
    scale = _expand_group_tensor(state['smooth_scale'].to(device=heads.device, dtype=torch.float32), q_num_heads, kv_num_heads)
    result = heads / scale[None, :, :]
    permutation = _expand_group_tensor(state['permutation'], q_num_heads, kv_num_heads)
    result = _apply_head_permutation(result, permutation)
    group_steps = state['rotation_group_steps'].to(device=result.device)
    if bool((group_steps > 0).any()):
        result = _apply_group_rotations(result, group_steps, state['rotation_pairs'].to(device=result.device), state['rotation_pair_signs'].to(device=result.device), q_num_heads=q_num_heads, kv_num_heads=kv_num_heads)
    return result.reshape(q.shape)

def transform_attention_k_structured(k: torch.Tensor, kv_num_heads: int, head_dim: int, state: dict[str, Any] | None) -> torch.Tensor:
    """Apply the same D/P/R coordinates to K."""
    if not state or state.get('mode') == 'direct':
        return k.to(torch.float32)
    heads = k.to(torch.float32).reshape(-1, int(kv_num_heads), int(head_dim))
    scale = state['smooth_scale'].to(device=heads.device, dtype=torch.float32)
    result = heads * scale[None, :, :]
    result = _apply_head_permutation(result, state['permutation'])
    group_steps = state['rotation_group_steps'].to(device=result.device)
    if bool((group_steps > 0).any()):
        result = _apply_group_rotations(result, group_steps, state['rotation_pairs'].to(device=result.device), state['rotation_pair_signs'].to(device=result.device), q_num_heads=kv_num_heads, kv_num_heads=kv_num_heads)
    return result.reshape(k.shape)

def _sample_aligned_rows(q: torch.Tensor, k: torch.Tensor, v: torch.Tensor, maximum_rows: int) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    rows = int(q.shape[0])
    if int(k.shape[0]) != rows or int(v.shape[0]) != rows:
        raise ValueError('calibration Q/K/V must have aligned sequence rows')
    if rows <= int(maximum_rows):
        return (q, k, v)
    indices = torch.linspace(0, rows - 1, steps=int(maximum_rows)).round().to(torch.long)
    return (q.index_select(0, indices), k.index_select(0, indices), v.index_select(0, indices))

def _structured_gqa_attention(q: torch.Tensor, k: torch.Tensor, v: torch.Tensor, q_num_heads: int, kv_num_heads: int, head_dim: int) -> torch.Tensor:
    sequence_length = int(q.shape[0])
    group_size = int(q_num_heads) // int(kv_num_heads)
    qh = q.to(torch.float32).reshape(sequence_length, q_num_heads, head_dim).transpose(0, 1)
    kh = k.to(torch.float32).reshape(sequence_length, kv_num_heads, head_dim)
    vh = v.to(torch.float32).reshape(sequence_length, kv_num_heads, head_dim)
    kh = kh.repeat_interleave(group_size, dim=1).transpose(0, 1)
    vh = vh.repeat_interleave(group_size, dim=1).transpose(0, 1)
    logits = torch.matmul(qh, kh.transpose(-1, -2)) / math.sqrt(float(head_dim))
    probabilities = torch.softmax(logits, dim=-1)
    output = torch.matmul(probabilities, vh)
    return output.transpose(0, 1).contiguous().reshape(sequence_length, q_num_heads * head_dim)

def _relative_output_mse(reference: torch.Tensor, actual: torch.Tensor) -> float:
    error = actual.to(torch.float64) - reference.to(torch.float64)
    denominator = reference.to(torch.float64).square().mean().clamp_min(1e-30)
    return float((error.square().mean() / denominator).item())

def _gains(reference_scores: tuple[float, ...], candidate_scores: tuple[float, ...]) -> tuple[float, ...]:
    return tuple(((reference - candidate) / max(abs(reference), 1e-30) for reference, candidate in zip(reference_scores, candidate_scores)))

def _structured_mean(values: tuple[float, ...]) -> float:
    return float(sum(values) / max(len(values), 1))

def _base_state(smooth_scale: torch.Tensor, kv_num_heads: int, head_dim: int, version: str) -> dict[str, Any]:
    identity = torch.arange(head_dim, dtype=torch.long).repeat(kv_num_heads, 1)
    return {'version': version, 'mode': 'reciprocal_smooth', 'structured_variant': 'd_only', 'strength': float(ATTENTION_FIXED_STRENGTH), 'kv_num_heads': int(kv_num_heads), 'smooth_scale': smooth_scale.to(torch.float32).cpu(), 'permutation': identity, 'permutation_active_groups': torch.zeros(kv_num_heads, dtype=torch.bool), 'permutation_active_blocks': torch.zeros((kv_num_heads, head_dim // HIF4_BLOCK_SIZE), dtype=torch.bool), 'permutation_scope': 0, 'rotation_block_size': 0, 'rotation_pairs': torch.zeros((kv_num_heads, ATTENTION_STRUCTURED_MAX_ROTATION_STEPS, 2), dtype=torch.long), 'rotation_pair_signs': torch.ones((kv_num_heads, ATTENTION_STRUCTURED_MAX_ROTATION_STEPS), dtype=torch.float32), 'rotation_group_steps': torch.zeros(kv_num_heads, dtype=torch.int16), 'rotation_group_subgroups': torch.zeros(kv_num_heads, dtype=torch.int16), 'gate_policy': 'mean_only'}

def _slice_group_state(state: dict[str, Any], kv_head: int) -> dict[str, Any]:
    result = dict(state)
    result['kv_num_heads'] = 1
    for key in ('smooth_scale', 'permutation', 'permutation_active_groups', 'permutation_active_blocks', 'rotation_pairs', 'rotation_pair_signs', 'rotation_group_steps', 'rotation_group_subgroups'):
        result[key] = state[key][kv_head:kv_head + 1]
    return result

def _prepare_context(calib_qkv_list: list, q_num_heads: int, kv_num_heads: int, head_dim: int, version: str) -> dict[str, Any]:
    if int(q_num_heads) % int(kv_num_heads):
        raise ValueError('q_num_heads must be divisible by kv_num_heads')
    if int(head_dim) % HIF4_BLOCK_SIZE:
        raise ValueError('head_dim must be divisible by 64')
    group_size = int(q_num_heads) // int(kv_num_heads)
    q_amax = torch.zeros((kv_num_heads, head_dim), dtype=torch.float32)
    k_amax = torch.zeros((kv_num_heads, head_dim), dtype=torch.float32)
    q_samples: list[torch.Tensor] = []
    k_samples: list[torch.Tensor] = []
    v_samples: list[torch.Tensor] = []
    fold_slices: list[tuple[int, int]] = []
    fold_start = 0
    for sample in calib_qkv_list:
        q = dequantize_nvfp4(*sample['q']).to(torch.float32)
        k = dequantize_nvfp4(*sample['k']).to(torch.float32)
        k = center_attention_k(k, kv_num_heads, head_dim)
        v = dequantize_nvfp4(*sample['v']).to(torch.float32)
        q_heads = q.reshape(-1, q_num_heads, head_dim).reshape(-1, kv_num_heads, group_size, head_dim)
        k_heads = k.reshape(-1, kv_num_heads, head_dim)
        q_amax = torch.maximum(q_amax, q_heads.abs().amax(dim=(0, 2)))
        k_amax = torch.maximum(k_amax, k_heads.abs().amax(dim=0))
        sampled_q, sampled_k, sampled_v = _sample_aligned_rows(q, k, v, ATTENTION_STRUCTURED_MAX_CALIB_ROWS)
        q_samples.append(sampled_q)
        k_samples.append(sampled_k)
        v_samples.append(sampled_v)
        fold_end = fold_start + int(sampled_q.shape[0])
        fold_slices.append((fold_start, fold_end))
        fold_start = fold_end
    if not q_samples:
        raise ValueError('attention calibration requires at least one Q/K/V sample')
    smooth_scale = _attention_scale(q_amax, k_amax, ATTENTION_FIXED_STRENGTH)
    reference_state = _base_state(smooth_scale, kv_num_heads, head_dim, version)
    sample_q = torch.cat(q_samples, dim=0)
    sample_k = torch.cat(k_samples, dim=0)
    sample_v = torch.cat(v_samples, dim=0)
    reconstructed_v = dequantize_hif4(quantize_hif4(sample_v))
    reference_outputs = tuple((_structured_gqa_attention(sample_q[start:end], sample_k[start:end], sample_v[start:end], q_num_heads, kv_num_heads, head_dim) for start, end in fold_slices))
    q_d = transform_attention_q_structured(sample_q, q_num_heads, head_dim, reference_state)
    k_d = transform_attention_k_structured(sample_k, kv_num_heads, head_dim, reference_state)
    reconstructed_q_d = dequantize_hif4(quantize_hif4(q_d))
    reconstructed_k_d = dequantize_hif4(quantize_hif4(k_d))
    reference_scores = tuple((_relative_output_mse(reference_outputs[fold_index], _structured_gqa_attention(reconstructed_q_d[start:end], reconstructed_k_d[start:end], reconstructed_v[start:end], q_num_heads, kv_num_heads, head_dim)) for fold_index, (start, end) in enumerate(fold_slices)))
    q_heads = sample_q.reshape(-1, q_num_heads, head_dim)
    k_heads = sample_k.reshape(-1, kv_num_heads, head_dim)
    v_heads = sample_v.reshape(-1, kv_num_heads, head_dim)
    reconstructed_v_heads = reconstructed_v.reshape(-1, kv_num_heads, head_dim)
    group_reference_outputs: list[tuple[torch.Tensor, ...]] = []
    for kv_head in range(kv_num_heads):
        q_start = kv_head * group_size
        q_end = q_start + group_size
        group_q = q_heads[:, q_start:q_end, :].reshape(-1, group_size * head_dim)
        group_k = k_heads[:, kv_head:kv_head + 1, :].reshape(-1, head_dim)
        group_v = v_heads[:, kv_head:kv_head + 1, :].reshape(-1, head_dim)
        group_reference_outputs.append(tuple((_structured_gqa_attention(group_q[start:end], group_k[start:end], group_v[start:end], group_size, 1, head_dim) for start, end in fold_slices)))
    return {'q_num_heads': int(q_num_heads), 'kv_num_heads': int(kv_num_heads), 'head_dim': int(head_dim), 'group_size': int(group_size), 'fold_slices': tuple(fold_slices), 'sample_q': sample_q, 'sample_k': sample_k, 'sample_v': sample_v, 'reconstructed_v': reconstructed_v, 'reference_outputs': reference_outputs, 'reference_state': reference_state, 'reference_scores': reference_scores, 'q_heads': q_heads, 'k_heads': k_heads, 'reconstructed_v_heads': reconstructed_v_heads, 'group_reference_outputs': tuple(group_reference_outputs), 'q_d': q_d, 'k_d': k_d, 'reconstructed_q_d': reconstructed_q_d, 'reconstructed_k_d': reconstructed_k_d}

def _evaluate_global(context: dict[str, Any], state: dict[str, Any]) -> tuple[float, ...]:
    q_num_heads = int(context['q_num_heads'])
    kv_num_heads = int(context['kv_num_heads'])
    head_dim = int(context['head_dim'])
    transformed_q = transform_attention_q_structured(context['sample_q'], q_num_heads, head_dim, state)
    transformed_k = transform_attention_k_structured(context['sample_k'], kv_num_heads, head_dim, state)
    reconstructed_q = dequantize_hif4(quantize_hif4(transformed_q))
    reconstructed_k = dequantize_hif4(quantize_hif4(transformed_k))
    return tuple((_relative_output_mse(context['reference_outputs'][fold_index], _structured_gqa_attention(reconstructed_q[start:end], reconstructed_k[start:end], context['reconstructed_v'][start:end], q_num_heads, kv_num_heads, head_dim)) for fold_index, (start, end) in enumerate(context['fold_slices'])))

def _evaluate_group(context: dict[str, Any], state: dict[str, Any], kv_head: int) -> tuple[float, ...]:
    group_size = int(context['group_size'])
    head_dim = int(context['head_dim'])
    q_start = int(kv_head) * group_size
    q_end = q_start + group_size
    group_q = context['q_heads'][:, q_start:q_end, :].reshape(-1, group_size * head_dim)
    group_k = context['k_heads'][:, kv_head:kv_head + 1, :].reshape(-1, head_dim)
    group_v_reconstructed = context['reconstructed_v_heads'][:, kv_head:kv_head + 1, :].reshape(-1, head_dim)
    group_state = _slice_group_state(state, kv_head)
    transformed_q = transform_attention_q_structured(group_q, group_size, head_dim, group_state)
    transformed_k = transform_attention_k_structured(group_k, 1, head_dim, group_state)
    reconstructed_q = dequantize_hif4(quantize_hif4(transformed_q))
    reconstructed_k = dequantize_hif4(quantize_hif4(transformed_k))
    return tuple((_relative_output_mse(context['group_reference_outputs'][kv_head][fold_index], _structured_gqa_attention(reconstructed_q[start:end], reconstructed_k[start:end], group_v_reconstructed[start:end], group_size, 1, head_dim)) for fold_index, (start, end) in enumerate(context['fold_slices'])))

def _rank_positions(score: torch.Tensor) -> torch.Tensor:
    order = torch.argsort(score, stable=True)
    ranks = torch.empty_like(order)
    ranks[order] = torch.arange(int(score.numel()), dtype=torch.long)
    return ranks

def _consensus_support(aggregate_score: torch.Tensor, fold_scores: torch.Tensor) -> float:
    """Fraction of channels with aggregate-rank support in >=80% folds."""
    aggregate_ranks = _rank_positions(aggregate_score)
    fold_ranks = torch.stack([_rank_positions(score) for score in fold_scores], dim=0)
    rank_tolerance = max(int(aggregate_score.numel()) // 4, 1)
    agreements = (fold_ranks - aggregate_ranks[None, :]).abs() <= rank_tolerance
    required = max(1, math.ceil(float(fold_scores.shape[0]) * ATTENTION_STRUCTURED_CONSENSUS_FRACTION))
    supported_channels = agreements.sum(dim=0) >= required
    return float(supported_channels.to(torch.float32).mean().item())

def _nested_order(score: torch.Tensor, start: int) -> torch.Tensor:
    order = torch.argsort(score, stable=True) + int(start)
    chunks = []
    for chunk_start in range(0, int(order.numel()), 4):
        chunks.append(torch.sort(order[chunk_start:chunk_start + 4]).values)
    return torch.cat(chunks, dim=0)

def _balanced_order(score: torch.Tensor, start: int) -> torch.Tensor:
    order = torch.argsort(score, stable=True) + int(start)
    group_count = int(order.numel()) // 4
    groups: list[list[int]] = [[] for _ in range(group_count)]
    for rank, channel in enumerate(order.tolist()):
        groups[rank % group_count].append(int(channel))
    return torch.tensor([channel for group in groups for channel in sorted(group)], dtype=torch.long)

def _joint_fold_scores(context: dict[str, Any], kv_head: int, statistic: str) -> torch.Tensor:
    group_size = int(context['group_size'])
    q_num_heads = int(context['q_num_heads'])
    kv_num_heads = int(context['kv_num_heads'])
    head_dim = int(context['head_dim'])
    q_d_heads = context['q_d'].reshape(-1, q_num_heads, head_dim)
    k_d_heads = context['k_d'].reshape(-1, kv_num_heads, head_dim)
    q_start = int(kv_head) * group_size
    q_end = q_start + group_size
    results: list[torch.Tensor] = []
    for start, end in context['fold_slices']:
        q_group = q_d_heads[start:end, q_start:q_end, :]
        k_group = k_d_heads[start:end, kv_head, :]
        if statistic == 'joint_peak':
            q_stat = q_group.abs().amax(dim=(0, 1))
            k_stat = k_group.abs().amax(dim=0)
        elif statistic == 'joint_rms':
            q_stat = q_group.square().mean(dim=(0, 1)).sqrt()
            k_stat = k_group.square().mean(dim=0).sqrt()
        else:
            raise ValueError(f'unsupported permutation statistic: {statistic}')
        results.append(torch.sqrt(q_stat.clamp_min(1e-30) * k_stat.clamp_min(1e-30)))
    return torch.stack(results, dim=0)

def _group_block_difficulty(context: dict[str, Any], kv_head: int) -> torch.Tensor:
    q_num_heads = int(context['q_num_heads'])
    kv_num_heads = int(context['kv_num_heads'])
    group_size = int(context['group_size'])
    head_dim = int(context['head_dim'])
    block_count = head_dim // HIF4_BLOCK_SIZE
    q_start = int(kv_head) * group_size
    q_end = q_start + group_size
    q = context['q_d'].reshape(-1, q_num_heads, block_count, HIF4_BLOCK_SIZE)[:, q_start:q_end]
    qr = context['reconstructed_q_d'].reshape(-1, q_num_heads, block_count, HIF4_BLOCK_SIZE)[:, q_start:q_end]
    k = context['k_d'].reshape(-1, kv_num_heads, block_count, HIF4_BLOCK_SIZE)[:, kv_head]
    kr = context['reconstructed_k_d'].reshape(-1, kv_num_heads, block_count, HIF4_BLOCK_SIZE)[:, kv_head]
    q_error = (qr - q).square().mean(dim=(0, 1, 3))
    q_energy = q.square().mean(dim=(0, 1, 3)).clamp_min(1e-30)
    k_error = (kr - k).square().mean(dim=(0, 2))
    k_energy = k.square().mean(dim=(0, 2)).clamp_min(1e-30)
    return q_error / q_energy + k_error / k_energy

def _build_structured_permutation(aggregate_score: torch.Tensor, fold_scores: torch.Tensor, difficulty: torch.Tensor, *, kind: str, ratio: float) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    head_dim = int(aggregate_score.numel())
    block_count = head_dim // HIF4_BLOCK_SIZE
    permutation = torch.arange(head_dim, dtype=torch.long)
    consensus = torch.zeros(block_count, dtype=torch.float32)
    eligible: list[int] = []
    for block_index in range(block_count):
        start = block_index * HIF4_BLOCK_SIZE
        end = start + HIF4_BLOCK_SIZE
        support = _consensus_support(aggregate_score[start:end], fold_scores[:, start:end])
        consensus[block_index] = float(support)
        if support >= ATTENTION_STRUCTURED_CONSENSUS_FRACTION:
            eligible.append(block_index)
    active = torch.zeros(block_count, dtype=torch.bool)
    if not eligible:
        return (permutation, active, consensus)
    requested = max(1, math.ceil(block_count * float(ratio)))
    selected = sorted(eligible, key=lambda index: float(difficulty[index].item()), reverse=True)[:min(requested, len(eligible))]
    for block_index in selected:
        start = block_index * HIF4_BLOCK_SIZE
        end = start + HIF4_BLOCK_SIZE
        local_score = aggregate_score[start:end]
        if kind == 'nested':
            order = _nested_order(local_score, start)
        elif kind == 'balanced':
            order = _balanced_order(local_score, start)
        else:
            raise ValueError(f'unsupported permutation kind: {kind}')
        permutation[start:end] = order
        active[block_index] = not torch.equal(order, torch.arange(start, end, dtype=torch.long))
    return (permutation, active, consensus)

def _select_p_candidate(context: dict[str, Any], reference_state: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    kv_num_heads = int(context['kv_num_heads'])
    combined = dict(reference_state)
    combined['permutation'] = reference_state['permutation'].clone()
    combined['permutation_active_groups'] = reference_state['permutation_active_groups'].clone()
    combined['permutation_active_blocks'] = reference_state['permutation_active_blocks'].clone()
    group_kinds: list[str] = []
    group_statistics: list[str] = []
    group_ratios = torch.zeros(kv_num_heads, dtype=torch.float32)
    group_mean_gains = torch.zeros(kv_num_heads, dtype=torch.float32)
    group_worst_gains = torch.zeros(kv_num_heads, dtype=torch.float32)
    group_consensus = torch.zeros(kv_num_heads, dtype=torch.float32)
    candidate_count = 0
    for kv_head in range(kv_num_heads):
        group_reference = _evaluate_group(context, reference_state, kv_head)
        difficulty = _group_block_difficulty(context, kv_head)
        ranked: list[tuple[float, float, dict[str, Any]]] = []
        for statistic in ('joint_peak', 'joint_rms'):
            fold_scores = _joint_fold_scores(context, kv_head, statistic)
            aggregate = torch.exp(torch.log(fold_scores.clamp_min(1e-30)).mean(dim=0))
            candidate_specs = (('nested', ATTENTION_STRUCTURED_PERMUTATION_RATIOS[0]), ('nested', ATTENTION_STRUCTURED_PERMUTATION_RATIOS[1]), ('balanced', ATTENTION_STRUCTURED_PERMUTATION_RATIOS[0]))
            for kind, ratio in candidate_specs:
                permutation, active_blocks, consensus = _build_structured_permutation(aggregate, fold_scores, difficulty, kind=kind, ratio=ratio)
                if not bool(active_blocks.any()):
                    continue
                candidate_count += 1
                candidate = dict(reference_state)
                candidate['permutation'] = reference_state['permutation'].clone()
                candidate['permutation'][kv_head] = permutation
                candidate['permutation_active_groups'] = reference_state['permutation_active_groups'].clone()
                candidate['permutation_active_groups'][kv_head] = True
                candidate['permutation_active_blocks'] = reference_state['permutation_active_blocks'].clone()
                candidate['permutation_active_blocks'][kv_head] = active_blocks
                candidate['permutation_scope'] = HIF4_BLOCK_SIZE
                candidate_scores = _evaluate_group(context, candidate, kv_head)
                gains = _gains(group_reference, candidate_scores)
                candidate.update({'tested_permutation_kind': kind, 'tested_permutation_statistic': statistic, 'tested_permutation_ratio': float(ratio), 'tested_permutation_consensus': float(consensus[active_blocks].mean().item())})
                ranked.append((_structured_mean(gains), min(gains), candidate))
        ranked.sort(key=lambda item: (item[0], item[1]), reverse=True)
        if not ranked:
            group_kinds.append('identity')
            group_statistics.append('identity')
            continue
        mean_gain, worst_gain, best = ranked[0]
        group_mean_gains[kv_head] = float(mean_gain)
        group_worst_gains[kv_head] = float(worst_gain)
        if mean_gain < ATTENTION_STRUCTURED_MEAN_GAIN_MIN:
            group_kinds.append('identity')
            group_statistics.append('identity')
            continue
        combined['permutation'][kv_head] = best['permutation'][kv_head]
        combined['permutation_active_groups'][kv_head] = True
        combined['permutation_active_blocks'][kv_head] = best['permutation_active_blocks'][kv_head]
        group_kinds.append(str(best['tested_permutation_kind']))
        group_statistics.append(str(best['tested_permutation_statistic']))
        group_ratios[kv_head] = float(best['tested_permutation_ratio'])
        group_consensus[kv_head] = float(best['tested_permutation_consensus'])
    active_groups = int(combined['permutation_active_groups'].sum().item())
    combined['permutation_scope'] = HIF4_BLOCK_SIZE if active_groups else 0
    combined['mode'] = 'reciprocal_smooth_structured_p' if active_groups else 'reciprocal_smooth'
    diagnostics = {'permutation_candidate_count': int(candidate_count), 'permutation_tested_active_groups': int(active_groups), 'permutation_group_kinds': group_kinds, 'permutation_group_statistics': group_statistics, 'permutation_group_ratios': group_ratios, 'permutation_group_consensus': group_consensus, 'permutation_group_mean_gains': group_mean_gains, 'permutation_group_worst_gains': group_worst_gains, 'permutation_consensus_fraction': float(ATTENTION_STRUCTURED_CONSENSUS_FRACTION)}
    return (combined, diagnostics)

def _set_group_rotation(state: dict[str, Any], kv_head: int, pairs: torch.Tensor, signs: torch.Tensor, steps: int, subgroup: int) -> dict[str, Any]:
    result = dict(state)
    result['rotation_pairs'] = state['rotation_pairs'].clone()
    result['rotation_pair_signs'] = state['rotation_pair_signs'].clone()
    result['rotation_group_steps'] = state['rotation_group_steps'].clone()
    result['rotation_group_subgroups'] = state['rotation_group_subgroups'].clone()
    result['rotation_pairs'][kv_head, :steps] = pairs[:steps]
    result['rotation_pair_signs'][kv_head, :steps] = signs[:steps]
    result['rotation_group_steps'][kv_head] = int(steps)
    result['rotation_group_subgroups'][kv_head] = int(subgroup)
    result['rotation_block_size'] = HIF4_BLOCK_SIZE
    return result

def _select_r_candidate(context: dict[str, Any], parent_state: dict[str, Any], *, require_active_p: bool, incremental_gain_min: float, rotation_steps: tuple[int, ...], rotation_subgroups: tuple[int, ...]) -> tuple[dict[str, Any], dict[str, Any]]:
    q_num_heads = int(context['q_num_heads'])
    kv_num_heads = int(context['kv_num_heads'])
    head_dim = int(context['head_dim'])
    group_size = int(context['group_size'])
    transformed_q = transform_attention_q_structured(context['sample_q'], q_num_heads, head_dim, parent_state).reshape(-1, q_num_heads, head_dim)
    transformed_k = transform_attention_k_structured(context['sample_k'], kv_num_heads, head_dim, parent_state).reshape(-1, kv_num_heads, head_dim)
    combined = dict(parent_state)
    combined['rotation_pairs'] = parent_state['rotation_pairs'].clone()
    combined['rotation_pair_signs'] = parent_state['rotation_pair_signs'].clone()
    combined['rotation_group_steps'] = parent_state['rotation_group_steps'].clone()
    combined['rotation_group_subgroups'] = parent_state['rotation_group_subgroups'].clone()
    group_mean_gains = torch.zeros(kv_num_heads, dtype=torch.float32)
    group_worst_gains = torch.zeros(kv_num_heads, dtype=torch.float32)
    candidate_count = 0
    for kv_head in range(kv_num_heads):
        if require_active_p and (not bool(parent_state['permutation_active_groups'][kv_head].item())):
            continue
        q_start = kv_head * group_size
        q_end = q_start + group_size
        primary = transformed_q[:, q_start:q_end, :].reshape(-1, head_dim)
        other = transformed_k[:, kv_head, :].reshape(-1, head_dim)
        group_reference = _evaluate_group(context, parent_state, kv_head)
        ranked: list[tuple[float, float, dict[str, Any]]] = []
        max_rotation_steps = max((int(steps) for steps in rotation_steps))
        for subgroup in rotation_subgroups:
            sequence = build_hif4_givens_rotation(primary, other, subgroup_size=subgroup, max_steps=max_rotation_steps, forced_steps=max_rotation_steps)
            for steps in rotation_steps:
                candidate_count += 1
                candidate = _set_group_rotation(parent_state, kv_head, sequence['rotation_pairs'], sequence['rotation_pair_signs'], steps, subgroup)
                candidate_scores = _evaluate_group(context, candidate, kv_head)
                gains = _gains(group_reference, candidate_scores)
                ranked.append((_structured_mean(gains), min(gains), candidate))
        ranked.sort(key=lambda item: (item[0], item[1]), reverse=True)
        if not ranked:
            continue
        mean_gain, worst_gain, best = ranked[0]
        group_mean_gains[kv_head] = float(mean_gain)
        group_worst_gains[kv_head] = float(worst_gain)
        if mean_gain < float(incremental_gain_min):
            continue
        combined['rotation_pairs'][kv_head] = best['rotation_pairs'][kv_head]
        combined['rotation_pair_signs'][kv_head] = best['rotation_pair_signs'][kv_head]
        combined['rotation_group_steps'][kv_head] = best['rotation_group_steps'][kv_head]
        combined['rotation_group_subgroups'][kv_head] = best['rotation_group_subgroups'][kv_head]
    active_groups = int((combined['rotation_group_steps'] > 0).sum().item())
    combined['rotation_block_size'] = HIF4_BLOCK_SIZE if active_groups else 0
    diagnostics = {'rotation_candidate_count': int(candidate_count), 'rotation_tested_active_groups': int(active_groups), 'rotation_group_mean_gains': group_mean_gains, 'rotation_group_worst_gains': group_worst_gains, 'rotation_incremental_gain_min': float(incremental_gain_min), 'rotation_steps_grid': tuple((int(value) for value in rotation_steps)), 'rotation_subgroups_grid': tuple((int(value) for value in rotation_subgroups))}
    return (combined, diagnostics)

def _finalize_p(context: dict[str, Any], candidate: dict[str, Any], diagnostics: dict[str, Any]) -> dict[str, Any]:
    reference = context['reference_state']
    reference_scores = context['reference_scores']
    candidate_scores = _evaluate_global(context, candidate)
    gains = _gains(reference_scores, candidate_scores)
    mean_gain = _structured_mean(gains)
    active_groups = int(candidate['permutation_active_groups'].sum().item())
    gate_passed = active_groups > 0 and mean_gain >= ATTENTION_STRUCTURED_MEAN_GAIN_MIN
    selected = dict(candidate if gate_passed else reference)
    selected['structured_variant'] = 'p_only' if gate_passed else 'd_only'
    selected['mode'] = 'reciprocal_smooth_structured_p' if gate_passed else 'reciprocal_smooth'
    selected.update(diagnostics)
    selected.update({'permutation_gate_passed': bool(gate_passed), 'permutation_mean_proxy_gain': float(mean_gain), 'permutation_worst_proxy_gain': float(min(gains)), 'reference_score': float(_structured_mean(reference_scores)), 'candidate_score': float(_structured_mean(candidate_scores)), 'mean_proxy_gain': float(mean_gain), 'worst_proxy_gain': float(min(gains)), 'gate_passed': bool(gate_passed), 'selection_policy': 'calibration-output-mean-only-structured-permutation', 'fold_count': int(len(context['fold_slices']))})
    return selected

def _finalize_r(context: dict[str, Any], parent: dict[str, Any], candidate: dict[str, Any], diagnostics: dict[str, Any], *, require_pr: bool, worst_gain_min: float | None=None, p_diagnostics: dict[str, Any] | None=None) -> dict[str, Any]:
    reference = context['reference_state']
    reference_scores = context['reference_scores']
    parent_scores = _evaluate_global(context, parent)
    candidate_scores = _evaluate_global(context, candidate)
    reference_gains = _gains(reference_scores, candidate_scores)
    incremental_gains = _gains(parent_scores, candidate_scores)
    mean_gain = _structured_mean(reference_gains)
    worst_gain = min(reference_gains)
    incremental_mean_gain = _structured_mean(incremental_gains)
    active_r = candidate['rotation_group_steps'] > 0
    active_p = candidate['permutation_active_groups']
    has_r = bool(active_r.any())
    has_pr_overlap = bool((active_r & active_p).any())
    gate_passed = has_r and mean_gain >= ATTENTION_STRUCTURED_MEAN_GAIN_MIN
    if worst_gain_min is not None:
        gate_passed = gate_passed and worst_gain >= float(worst_gain_min)
    if require_pr:
        gate_passed = gate_passed and has_pr_overlap and (incremental_mean_gain >= ATTENTION_STRUCTURED_PR_INCREMENTAL_GAIN_MIN)
    selected = dict(candidate if gate_passed else reference)
    if gate_passed and require_pr:
        selected['structured_variant'] = 'p_then_r'
        selected['mode'] = 'reciprocal_smooth_structured_p_r'
    elif gate_passed:
        selected['structured_variant'] = 'r_only'
        selected['mode'] = 'reciprocal_smooth_structured_r'
    else:
        selected['structured_variant'] = 'd_only'
        selected['mode'] = 'reciprocal_smooth'
    if p_diagnostics:
        selected.update(p_diagnostics)
    selected.update(diagnostics)
    selected.update({'rotation_gate_passed': bool(gate_passed), 'rotation_mean_proxy_gain': float(mean_gain), 'rotation_worst_proxy_gain': float(worst_gain), 'pr_incremental_mean_proxy_gain': float(incremental_mean_gain), 'pr_incremental_worst_proxy_gain': float(min(incremental_gains)), 'reference_score': float(_structured_mean(reference_scores)), 'parent_score': float(_structured_mean(parent_scores)), 'candidate_score': float(_structured_mean(candidate_scores)), 'mean_proxy_gain': float(mean_gain), 'worst_proxy_gain': float(worst_gain), 'gate_passed': bool(gate_passed), 'selection_policy': 'calibration-output-mean-only-permutation-then-rotation' if require_pr else 'calibration-output-mean-and-worst-local-rotation' if worst_gain_min is not None else 'calibration-output-mean-only-local-rotation', 'fold_count': int(len(context['fold_slices']))})
    if worst_gain_min is not None:
        selected['rotation_worst_gain_min'] = float(worst_gain_min)
    return selected

def select_attention_structured_transform(calib_qkv_list: list, q_num_heads: int, kv_num_heads: int, head_dim: int, *, variant: str) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    """Select a frozen D/P/R Attention profile using calibration output MSE."""
    if variant not in ATTENTION_STRUCTURED_VARIANTS:
        raise ValueError(f'unsupported structured Attention variant: {variant}')
    version = {'d_only': 'attention-qk-reciprocal-scale-control', 'r_only': 'attention-qk-local-rotation', 'r_deep': 'attention-qk-local-rotation-deep', 'r_block64': 'attention-qk-block64-rotation', 'r_wide': 'attention-qk-wide-rotation', 'r_wide_robust': 'attention-qk-wide-rotation-robust', 'p_only': 'attention-qk-permutation', 'p_then_r': 'attention-qk-permutation-rotation'}[variant]
    context = _prepare_context(calib_qkv_list, q_num_heads, kv_num_heads, head_dim, version)
    reference = context['reference_state']
    if variant == 'd_only':
        selected = dict(reference)
        selected.update({'selection_policy': 'fixed-reciprocal-scale-control', 'gate_passed': True, 'mean_proxy_gain': 0.0, 'worst_proxy_gain': 0.0, 'reference_score': float(_structured_mean(context['reference_scores'])), 'candidate_score': float(_structured_mean(context['reference_scores'])), 'fold_count': int(len(context['fold_slices']))})
    elif variant in ATTENTION_STRUCTURED_ROTATION_PROFILES:
        rotation_steps, rotation_subgroups = ATTENTION_STRUCTURED_ROTATION_PROFILES[variant]
        candidate, diagnostics = _select_r_candidate(context, reference, require_active_p=False, incremental_gain_min=ATTENTION_STRUCTURED_MEAN_GAIN_MIN, rotation_steps=rotation_steps, rotation_subgroups=rotation_subgroups)
        selected = _finalize_r(context, reference, candidate, diagnostics, require_pr=False, worst_gain_min=0.0 if variant == 'r_wide_robust' else None)
        selected['structured_variant'] = variant if selected.get('structured_variant') == 'r_only' else 'd_only'
        selected['rotation_profile'] = variant
    else:
        p_candidate, p_diagnostics = _select_p_candidate(context, reference)
        if variant == 'p_only':
            selected = _finalize_p(context, p_candidate, p_diagnostics)
        else:
            pr_candidate, r_diagnostics = _select_r_candidate(context, p_candidate, require_active_p=True, incremental_gain_min=ATTENTION_STRUCTURED_PR_INCREMENTAL_GAIN_MIN, rotation_steps=ATTENTION_STRUCTURED_ROTATION_PROFILES['r_only'][0], rotation_subgroups=ATTENTION_STRUCTURED_ROTATION_PROFILES['r_only'][1])
            selected = _finalize_r(context, p_candidate, pr_candidate, r_diagnostics, require_pr=True, worst_gain_min=None, p_diagnostics=p_diagnostics)
    q_state = dict(selected)
    k_state = dict(selected)
    v_state: dict[str, Any] = {'version': 'attention-value-direct', 'mode': 'direct'}
    return (q_state, k_state, v_state)
'Attention-aware Hessian/SVD transforms and frozen-grid HiF4 rounding.\n\nThe public Attention API quantizes Q and K independently at runtime.  This\nmodule therefore learns *expected* sensitivity from calibration data:\n\n* Q rounding uses curvature induced by calibration K.\n* K rounding uses curvature induced by the corresponding GQA Q heads.\n* A Fisher variant obtains output-space curvature with deterministic\n  Hutchinson probes through softmax and V.\n\nAll rounding variants first select a legal hierarchical HiF4 scale grid and\nthen only change signed mantissa codes on that frozen grid.  The generalized\nSVD variant applies blockwise ``Q @ T`` and ``K @ inv(T).T`` transforms, so\nunquantized logits are preserved exactly up to floating-point roundoff.\n'
ATTENTION_HESSIAN_METHODS = ('q_svd', 'k_svd', 'qk_svd', 'qk_block16_hessian', 'generalized_svd', 'fisher_svd')
ATTENTION_HESSIAN_RANK = 32
ATTENTION_HESSIAN_LOGIT_MIX = 2.5
ATTENTION_HESSIAN_SCHWARZ_GROUP = 4
ATTENTION_HESSIAN_SCHWARZ_SWEEPS = 2
ATTENTION_FULL_BLOCK_SIZE = 16
ATTENTION_FISHER_MAX_ROWS = 48
ATTENTION_FISHER_PROBES = 2
ATTENTION_ONLINE_GPTQ_BLEND = 0.125
ATTENTION_ONLINE_GPTQ_MAX_ROWS = 6
ATTENTION_GENERALIZED_BLOCK_SIZE = 16
ATTENTION_GENERALIZED_SINGULAR_MIN = 0.5
ATTENTION_GENERALIZED_SINGULAR_MAX = 2.0
ATTENTION_BLOCK_ROTATION_SIZE = 64
ATTENTION_BLOCK_ROTATION_MIN_ROWS = 128
ATTENTION_BLOCK_ROTATION_CALIB_ROWS = 48
ATTENTION_BLOCK_ROTATION_SEEDS = (0, 1, 2, 3, 4, 5)
ATTENTION_BLOCK_ROTATION_MEAN_GAIN_MIN = 0.005
ATTENTION_BLOCK_ROTATION_WORST_GAIN_MIN = 0.0
ATTENTION_Q_LONG_SF_MIN_ROWS = 1024
ATTENTION_Q_LONG_SEARCH_MULTIPLIERS = (0.5, 0.625, 0.75, 1.0, 1.25)
ATTENTION_K_OUTPUT_SEARCH_MULTIPLIERS = (0.5, 0.625, 0.75, 1.0, 1.125)
ATTENTION_K_LONG_SEARCH_MULTIPLIERS = (0.5, 0.625, 0.75, 1.0, 1.125, 1.25)

def _hessian_sample_rows(tensor: torch.Tensor, maximum_rows: int) -> torch.Tensor:
    rows = int(tensor.shape[0])
    if rows <= int(maximum_rows):
        return tensor
    indices = torch.linspace(0, rows - 1, steps=int(maximum_rows)).round().to(torch.long)
    return tensor.index_select(0, indices)

def _hessian_gqa_attention(q: torch.Tensor, k: torch.Tensor, v: torch.Tensor, q_num_heads: int, kv_num_heads: int, head_dim: int) -> torch.Tensor:
    rows = int(q.shape[0])
    group_size = int(q_num_heads) // int(kv_num_heads)
    qh = q.reshape(rows, int(q_num_heads), int(head_dim)).transpose(0, 1)
    kh = k.reshape(rows, int(kv_num_heads), int(head_dim))
    vh = v.reshape(rows, int(kv_num_heads), int(head_dim))
    kh = kh.repeat_interleave(group_size, dim=1).transpose(0, 1)
    vh = vh.repeat_interleave(group_size, dim=1).transpose(0, 1)
    logits = torch.matmul(qh, kh.transpose(-1, -2)) / math.sqrt(float(head_dim))
    probabilities = torch.softmax(logits, dim=-1)
    output = torch.matmul(probabilities, vh)
    return output.transpose(0, 1).contiguous().reshape(rows, int(q_num_heads) * int(head_dim))

def _collect_logit_hessians(calib_qkv_list: list, q_num_heads: int, kv_num_heads: int, head_dim: int, q_state: dict[str, Any], k_state: dict[str, Any]) -> tuple[torch.Tensor, torch.Tensor, int]:
    """Return per-KV-group Q and K logit-MSE Hessians."""
    q_hessian = torch.zeros((int(kv_num_heads), int(head_dim), int(head_dim)), dtype=torch.float32)
    k_hessian = torch.zeros_like(q_hessian)
    q_counts = torch.zeros(int(kv_num_heads), dtype=torch.float64)
    k_counts = torch.zeros(int(kv_num_heads), dtype=torch.float64)
    group_size = int(q_num_heads) // int(kv_num_heads)
    for sample in calib_qkv_list:
        q = dequantize_nvfp4(*sample['q']).to(torch.float32)
        k = dequantize_nvfp4(*sample['k']).to(torch.float32)
        k = center_attention_k(k, kv_num_heads, head_dim)
        q = transform_attention_q_structured(q, q_num_heads, head_dim, q_state)
        k = transform_attention_k_structured(k, kv_num_heads, head_dim, k_state)
        qh = q.reshape(-1, int(q_num_heads), int(head_dim))
        kh = k.reshape(-1, int(kv_num_heads), int(head_dim))
        rows = int(qh.shape[0])
        for kv_head in range(int(kv_num_heads)):
            q_group = qh[:, kv_head * group_size:(kv_head + 1) * group_size, :].reshape(-1, int(head_dim))
            k_group = kh[:, kv_head, :]
            q_hessian[kv_head] += k_group.T @ k_group
            k_hessian[kv_head] += q_group.T @ q_group
            q_counts[kv_head] += float(rows)
            k_counts[kv_head] += float(rows * group_size)
    for kv_head in range(int(kv_num_heads)):
        q_hessian[kv_head] /= max(float(q_counts[kv_head].item()), 1.0)
        k_hessian[kv_head] /= max(float(k_counts[kv_head].item()), 1.0)
    calibration_rows = int(q_counts.sum().item())
    return (q_hessian, k_hessian, calibration_rows)

def _collect_fisher_hessians(calib_qkv_list: list, q_num_heads: int, kv_num_heads: int, head_dim: int, q_state: dict[str, Any], k_state: dict[str, Any]) -> tuple[torch.Tensor, torch.Tensor, int]:
    """Estimate output-space Gauss-Newton curvature with Hutchinson probes."""
    q_hessian = torch.zeros((int(kv_num_heads), int(head_dim), int(head_dim)), dtype=torch.float32)
    k_hessian = torch.zeros_like(q_hessian)
    q_counts = torch.zeros(int(kv_num_heads), dtype=torch.float64)
    k_counts = torch.zeros(int(kv_num_heads), dtype=torch.float64)
    group_size = int(q_num_heads) // int(kv_num_heads)
    generator = torch.Generator(device='cpu')
    generator.manual_seed(260828)
    for sample in calib_qkv_list:
        q = _hessian_sample_rows(dequantize_nvfp4(*sample['q']).to(torch.float32), ATTENTION_FISHER_MAX_ROWS)
        k = center_attention_k(dequantize_nvfp4(*sample['k']).to(torch.float32), kv_num_heads, head_dim)
        k = _hessian_sample_rows(k, ATTENTION_FISHER_MAX_ROWS)
        v = _hessian_sample_rows(dequantize_nvfp4(*sample['v']).to(torch.float32), ATTENTION_FISHER_MAX_ROWS)
        q = transform_attention_q_structured(q, q_num_heads, head_dim, q_state)
        k = transform_attention_k_structured(k, kv_num_heads, head_dim, k_state)
        rows = int(q.shape[0])
        with torch.enable_grad():
            q_variable = q.detach().requires_grad_(True)
            k_variable = k.detach().requires_grad_(True)
            output = _hessian_gqa_attention(q_variable, k_variable, v, q_num_heads, kv_num_heads, head_dim)
            for probe_index in range(ATTENTION_FISHER_PROBES):
                probe = torch.randint(0, 2, output.shape, generator=generator, dtype=torch.int8).to(torch.float32)
                probe = probe.mul_(2.0).sub_(1.0)
                q_grad, k_grad = torch.autograd.grad((output * probe).sum(), (q_variable, k_variable), retain_graph=probe_index + 1 < ATTENTION_FISHER_PROBES)
                qg = q_grad.detach().reshape(rows, int(q_num_heads), int(head_dim))
                kg = k_grad.detach().reshape(rows, int(kv_num_heads), int(head_dim))
                for kv_head in range(int(kv_num_heads)):
                    q_group = qg[:, kv_head * group_size:(kv_head + 1) * group_size, :].reshape(-1, int(head_dim))
                    k_group = kg[:, kv_head, :]
                    q_hessian[kv_head] += q_group.T @ q_group
                    k_hessian[kv_head] += k_group.T @ k_group
                    q_counts[kv_head] += float(rows * group_size)
                    k_counts[kv_head] += float(rows)
    for kv_head in range(int(kv_num_heads)):
        q_hessian[kv_head] /= max(float(q_counts[kv_head].item()), 1.0)
        k_hessian[kv_head] /= max(float(k_counts[kv_head].item()), 1.0)
    calibration_rows = int(k_counts.sum().item() / max(ATTENTION_FISHER_PROBES, 1))
    return (q_hessian, k_hessian, calibration_rows)

def _collect_online_qhat_khat_hessians(calib_qkv_list: list, q_num_heads: int, kv_num_heads: int, head_dim: int, q_state: dict[str, Any], k_state: dict[str, Any]) -> tuple[torch.Tensor, torch.Tensor, int]:
    """Measure deterministic K output curvature induced by deployed Q-hat."""
    q_hessian = torch.zeros((int(kv_num_heads), int(head_dim), int(head_dim)), dtype=torch.float32)
    k_hessian = torch.zeros_like(q_hessian)
    k_counts = torch.zeros(int(kv_num_heads), dtype=torch.float64)
    group_size = int(q_num_heads) // int(kv_num_heads)
    count = len(calib_qkv_list)
    representatives = (calib_qkv_list[count // 4], calib_qkv_list[3 * count // 4])
    for sample in representatives:
        q = _hessian_sample_rows(dequantize_nvfp4(*sample['q']).to(torch.float32), ATTENTION_ONLINE_GPTQ_MAX_ROWS)
        k = center_attention_k(dequantize_nvfp4(*sample['k']).to(torch.float32), kv_num_heads, head_dim)
        k = _hessian_sample_rows(k, ATTENTION_ONLINE_GPTQ_MAX_ROWS)
        v = _hessian_sample_rows(dequantize_nvfp4(*sample['v']).to(torch.float32), ATTENTION_ONLINE_GPTQ_MAX_ROWS)
        q = transform_attention_q_structured(q, q_num_heads, head_dim, q_state)
        k = transform_attention_k_structured(k, kv_num_heads, head_dim, k_state)
        q = apply_attention_extra_transform(q, q_num_heads, head_dim, q_state)
        k = apply_attention_extra_transform(k, kv_num_heads, head_dim, k_state)
        q_hat = dequantize_hif4(quantize_attention_hessian(q, q_num_heads, head_dim, q_state))
        rows = min(int(q_hat.shape[0]), int(k.shape[0]), int(v.shape[0]))
        q_heads = q_hat[:rows].reshape(rows, int(q_num_heads), int(head_dim)).transpose(0, 1)
        k_heads = k[:rows].reshape(rows, int(kv_num_heads), int(head_dim)).repeat_interleave(group_size, dim=1).transpose(0, 1)
        v_heads = v[:rows].reshape(rows, int(kv_num_heads), int(head_dim)).repeat_interleave(group_size, dim=1).transpose(0, 1)
        probability = torch.softmax(torch.matmul(q_heads, k_heads.transpose(-1, -2)) / math.sqrt(float(head_dim)), dim=-1)
        output = torch.matmul(probability, v_heads)
        value_difference_energy = (v_heads[:, None, :, :] - output[:, :, None, :]).square().sum(dim=-1)
        query_weight = (probability.square() * value_difference_energy).sum(dim=-1).clamp_min(1e-20)
        for kv_head in range(int(kv_num_heads)):
            start = kv_head * group_size
            end = start + group_size
            group_q = q_heads[start:end]
            group_weight = query_weight[start:end]
            k_hessian[kv_head] += torch.einsum('gtd,gt,gte->de', group_q, group_weight, group_q)
            k_counts[kv_head] += float(group_size * rows)
    for kv_head in range(int(kv_num_heads)):
        k_hessian[kv_head] /= max(float(k_counts[kv_head].item()), 1.0)
    return (q_hessian, k_hessian, int(k_counts.sum().item()))

def _low_rank_factors(hessian: torch.Tensor, rank: int) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Factor H as F.T@F + diag(residual), returning spectral diagnostics."""
    group_count, channels, _ = hessian.shape
    actual_rank = min(int(rank), int(channels))
    factors = torch.zeros((group_count, actual_rank, channels), dtype=torch.float32)
    residuals = torch.zeros((group_count, channels), dtype=torch.float32)
    explained = torch.zeros(group_count, dtype=torch.float32)
    for group in range(int(group_count)):
        matrix = hessian[group].to(torch.float32)
        matrix = (matrix + matrix.T) * 0.5
        diagonal = torch.diagonal(matrix).clamp_min(0.0)
        mean_diagonal = diagonal.mean().clamp_min(1e-12)
        matrix = matrix + torch.eye(channels, dtype=torch.float32) * (mean_diagonal * 1e-06)
        eigenvalues, eigenvectors = torch.linalg.eigh(matrix)
        order = eigenvalues.argsort(descending=True)[:actual_rank]
        selected_values = eigenvalues.index_select(0, order).clamp_min(0.0)
        selected_vectors = eigenvectors.index_select(1, order)
        factor = selected_values.sqrt()[:, None] * selected_vectors.T
        low_rank_diagonal = factor.square().sum(dim=0)
        residual = (diagonal - low_rank_diagonal).clamp_min(mean_diagonal * 1e-05)
        factors[group] = factor
        residuals[group] = residual
        explained[group] = selected_values.sum() / eigenvalues.clamp_min(0.0).sum().clamp_min(1e-30)
    return (factors.contiguous(), residuals.contiguous(), explained)

def _block_inverse_factors(hessian: torch.Tensor, block_size: int) -> tuple[torch.Tensor, torch.Tensor]:
    groups, channels, _ = hessian.shape
    if int(channels) % int(block_size):
        raise ValueError('head_dim must be divisible by the Hessian block size')
    block_count = int(channels) // int(block_size)
    factors = torch.zeros((int(groups), block_count, int(block_size), int(block_size)), dtype=torch.float32)
    damping = torch.zeros((int(groups), block_count), dtype=torch.float32)
    for group in range(int(groups)):
        for block in range(block_count):
            start = block * int(block_size)
            end = start + int(block_size)
            factor, applied_damp = inverse_hessian_cholesky(hessian[group, start:end, start:end], percdamp=0.01)
            factors[group, block] = factor
            damping[group, block] = float(applied_damp)
    return (factors.contiguous(), damping.contiguous())

def _hadamard(size: int) -> torch.Tensor:
    if int(size) <= 0 or int(size) & int(size) - 1:
        raise ValueError('Hadamard size must be a positive power of two')
    result = torch.ones((1, 1), dtype=torch.float32)
    while int(result.shape[0]) < int(size):
        result = torch.cat([torch.cat([result, result], dim=1), torch.cat([result, -result], dim=1)], dim=0)
    return result / math.sqrt(float(size))

def _build_attention_block64_rotation(kv_num_heads: int, head_dim: int, seed: int) -> torch.Tensor:
    """Build one deterministic signed-Hadamard rotation per HiF4 block."""
    block_size = int(ATTENTION_BLOCK_ROTATION_SIZE)
    if int(head_dim) % block_size:
        raise ValueError('Attention head_dim must align with the rotation block')
    block_count = int(head_dim) // block_size
    base = _hadamard(block_size)
    generator = torch.Generator(device='cpu')
    generator.manual_seed(91000 + int(seed))
    matrices = torch.empty((int(kv_num_heads), block_count, block_size, block_size), dtype=torch.float32)
    for kv_head in range(int(kv_num_heads)):
        for block in range(block_count):
            signs = torch.randint(0, 2, (block_size,), generator=generator, dtype=torch.int8).to(torch.float32).mul_(2.0).sub_(1.0)
            permutation = torch.randperm(block_size, generator=generator)
            matrices[kv_head, block] = (signs[:, None] * base).index_select(1, permutation)
    return matrices.contiguous()

def _rotate_attention_hessian_state(state: dict[str, Any], matrices: torch.Tensor, *, seed: int, minimum_rows: int) -> dict[str, Any]:
    """Rotate the low-rank Fisher model with the exact shared Q/K basis."""
    result = dict(state)
    factor = state['attention_hessian_factor'].to(torch.float32)
    diagonal = state['attention_hessian_diagonal'].to(torch.float32)
    if int(factor.shape[0]) != int(matrices.shape[0]):
        raise ValueError('rotation groups do not match the Attention Hessian')
    block_size = int(matrices.shape[-1])
    if int(factor.shape[-1]) % block_size:
        raise ValueError('Attention Hessian does not align with the rotation')
    block_count = int(factor.shape[-1]) // block_size
    if int(matrices.shape[1]) != block_count:
        raise ValueError('rotation block count does not match the Attention Hessian')
    rotated_factor = torch.empty_like(factor)
    rotated_diagonal = torch.empty_like(diagonal)
    for kv_head in range(int(factor.shape[0])):
        for block in range(block_count):
            start = block * block_size
            end = start + block_size
            matrix = matrices[kv_head, block]
            rotated_factor[kv_head, :, start:end] = factor[kv_head, :, start:end] @ matrix
            rotated_diagonal[kv_head, start:end] = diagonal[kv_head, start:end] @ matrix.square()
    result.update({'attention_extra_transform': matrices.to(torch.float32).cpu(), 'attention_extra_transform_role': 'shared-block64-orthogonal', 'attention_extra_transform_block': int(block_size), 'attention_extra_transform_min_rows': int(minimum_rows), 'attention_unrotated_hessian_factor': factor.cpu(), 'attention_unrotated_hessian_diagonal': diagonal.cpu(), 'attention_hessian_factor': rotated_factor.cpu(), 'attention_hessian_diagonal': rotated_diagonal.cpu(), 'attention_block_rotation_seed': int(seed)})
    return result

def _attention_hessian_terms(state: dict[str, Any], row_count: int) -> tuple[torch.Tensor, torch.Tensor]:
    """Return Hessian terms in the basis actually used for this sequence."""
    minimum_rows = int(state.get('attention_extra_transform_min_rows', 0))
    if minimum_rows > 0 and int(row_count) < minimum_rows and ('attention_unrotated_hessian_factor' in state):
        return (state['attention_unrotated_hessian_factor'].to(torch.float32), state['attention_unrotated_hessian_diagonal'].to(torch.float32))
    return (state['attention_hessian_factor'].to(torch.float32), state['attention_hessian_diagonal'].to(torch.float32))

def _generalized_matrices(q_hessian: torch.Tensor, k_hessian: torch.Tensor, block_size: int) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Build conditioned block transforms that jointly balance Q and K."""
    groups, channels, _ = q_hessian.shape
    block_count = int(channels) // int(block_size)
    q_matrices = torch.zeros((int(groups), block_count, int(block_size), int(block_size)), dtype=torch.float32)
    k_matrices = torch.zeros_like(q_matrices)
    conditions = torch.zeros((int(groups), block_count), dtype=torch.float32)
    spreading = _hadamard(int(block_size))
    for group in range(int(groups)):
        for block in range(block_count):
            start = block * int(block_size)
            end = start + int(block_size)
            a = q_hessian[group, start:end, start:end].to(torch.float32)
            b = k_hessian[group, start:end, start:end].to(torch.float32)
            a = (a + a.T) * 0.5
            b = (b + b.T) * 0.5
            identity = torch.eye(int(block_size), dtype=torch.float32)
            a_scale = torch.diagonal(a).mean().clamp_min(1e-12)
            b_scale = torch.diagonal(b).mean().clamp_min(1e-12)
            a = a / a_scale + identity * 0.001
            b = b / b_scale + identity * 0.001
            a_values, a_vectors = torch.linalg.eigh(a)
            a_values = a_values.clamp_min(1e-06)
            a_sqrt = a_vectors * a_values.sqrt()[None, :] @ a_vectors.T
            a_inv_sqrt = a_vectors * a_values.rsqrt()[None, :] @ a_vectors.T
            middle = a_sqrt @ b @ a_sqrt
            middle = (middle + middle.T) * 0.5
            values, vectors = torch.linalg.eigh(middle)
            values = values.clamp_min(1e-06)
            transform = a_inv_sqrt @ vectors @ torch.diag(values.pow(0.25)) @ spreading
            left, singular, right = torch.linalg.svd(transform, full_matrices=False)
            singular = singular.clamp(ATTENTION_GENERALIZED_SINGULAR_MIN, ATTENTION_GENERALIZED_SINGULAR_MAX)
            transform = left * singular[None, :] @ right
            inverse_transpose = torch.linalg.inv(transform).T
            q_matrices[group, block] = transform
            k_matrices[group, block] = inverse_transpose
            conditions[group, block] = singular.max() / singular.min().clamp_min(1e-30)
    return (q_matrices.contiguous(), k_matrices.contiguous(), conditions)

def calibrate_attention_hessian(calib_qkv_list: list, q_num_heads: int, kv_num_heads: int, head_dim: int, *, method: str) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    """Calibrate an R-only parent plus one Attention Hessian/SVD mechanism."""
    if method not in ATTENTION_HESSIAN_METHODS:
        raise ValueError(f'unsupported Attention Hessian method: {method}')
    q_state, k_state, v_state = select_attention_structured_transform(calib_qkv_list, q_num_heads, kv_num_heads, head_dim, variant='r_only')
    q_state = dict(q_state)
    k_state = dict(k_state)
    v_state = dict(v_state)
    v_state.update({'v_rounding_mode': 'mean_balanced_adjacent', 'v_mean_penalty': float(V_MEAN_PENALTY)})
    if method == 'fisher_svd':
        q_fisher, k_fisher, fisher_rows = _collect_fisher_hessians(calib_qkv_list, q_num_heads, kv_num_heads, head_dim, q_state, k_state)
        q_logit, k_logit, logit_rows = _collect_logit_hessians(calib_qkv_list, q_num_heads, kv_num_heads, head_dim, q_state, k_state)

        def mix_hessian(fisher: torch.Tensor, logit: torch.Tensor) -> torch.Tensor:
            fisher_trace = fisher.diagonal(dim1=-2, dim2=-1).sum(dim=-1)
            logit_trace = logit.diagonal(dim1=-2, dim2=-1).sum(dim=-1)
            scale = (fisher_trace / logit_trace.clamp_min(1e-30))[:, None, None]
            return fisher + ATTENTION_HESSIAN_LOGIT_MIX * logit * scale
        q_hessian = mix_hessian(q_fisher, q_logit)
        k_hessian = mix_hessian(k_fisher, k_logit)
        calibration_rows = max(int(fisher_rows), int(logit_rows))
        curvature = 'normalized-fisher-plus-logit'
    else:
        q_hessian, k_hessian, calibration_rows = _collect_logit_hessians(calib_qkv_list, q_num_heads, kv_num_heads, head_dim, q_state, k_state)
        curvature = 'opposite-operand-logit-hessian'
    common: dict[str, Any] = {'attention_hessian_method': method, 'attention_hessian_curvature': curvature, 'attention_hessian_calibration_rows': int(calibration_rows), 'attention_hessian_head_dim': int(head_dim), 'attention_hessian_kv_heads': int(kv_num_heads)}
    q_state.update(common)
    k_state.update(common)
    k_state['attention_k_centering'] = 'per_sequence_token_mean'
    if method == 'generalized_svd':
        q_matrices, k_matrices, conditions = _generalized_matrices(q_hessian, k_hessian, ATTENTION_GENERALIZED_BLOCK_SIZE)
        q_state.update({'attention_rounding_mode': 'direct', 'attention_extra_transform': q_matrices.cpu(), 'attention_extra_transform_role': 'q_t', 'attention_extra_transform_block': ATTENTION_GENERALIZED_BLOCK_SIZE, 'attention_extra_transform_condition_max': float(conditions.max().item())})
        k_state.update({'attention_rounding_mode': 'direct', 'attention_extra_transform': k_matrices.cpu(), 'attention_extra_transform_role': 'k_inverse_t', 'attention_extra_transform_block': ATTENTION_GENERALIZED_BLOCK_SIZE, 'attention_extra_transform_condition_max': float(conditions.max().item())})
        return (q_state, k_state, v_state)
    if method == 'qk_block16_hessian':
        q_factors, q_damping = _block_inverse_factors(q_hessian, ATTENTION_FULL_BLOCK_SIZE)
        k_factors, k_damping = _block_inverse_factors(k_hessian, ATTENTION_FULL_BLOCK_SIZE)
        q_state.update({'attention_rounding_mode': 'block_hessian_gptq', 'attention_hessian_block_size': ATTENTION_FULL_BLOCK_SIZE, 'attention_hessian_inverse_cholesky': q_factors.cpu(), 'attention_hessian_damping': q_damping.cpu()})
        k_state.update({'attention_rounding_mode': 'block_hessian_gptq', 'attention_hessian_block_size': ATTENTION_FULL_BLOCK_SIZE, 'attention_hessian_inverse_cholesky': k_factors.cpu(), 'attention_hessian_damping': k_damping.cpu()})
        return (q_state, k_state, v_state)
    q_enabled = method in ('q_svd', 'qk_svd', 'fisher_svd')
    k_enabled = method in ('k_svd', 'qk_svd', 'fisher_svd')
    if method == 'fisher_svd' and q_enabled and k_enabled:
        provisional_q_factor, provisional_q_residual, _ = _low_rank_factors(q_hessian, 8)
        provisional_k_factor, provisional_k_residual, _ = _low_rank_factors(k_hessian, 8)
        q_state.update({'attention_rounding_mode': 'low_rank_schwarz', 'attention_hessian_factor': provisional_q_factor.cpu(), 'attention_hessian_diagonal': provisional_q_residual.cpu(), 'attention_hessian_schwarz_group': ATTENTION_HESSIAN_SCHWARZ_GROUP, 'attention_hessian_schwarz_sweeps': ATTENTION_HESSIAN_SCHWARZ_SWEEPS, 'attention_hessian_max_columns': 32})
        k_state.update({'attention_rounding_mode': 'low_rank_schwarz', 'attention_hessian_factor': provisional_k_factor.cpu(), 'attention_hessian_diagonal': provisional_k_residual.cpu(), 'attention_hessian_schwarz_group': ATTENTION_HESSIAN_SCHWARZ_GROUP, 'attention_hessian_schwarz_sweeps': ATTENTION_HESSIAN_SCHWARZ_SWEEPS, 'attention_hessian_max_columns': 48})
        online_q_fisher, online_k_fisher, online_rows = _collect_online_qhat_khat_hessians(calib_qkv_list, q_num_heads, kv_num_heads, head_dim, q_state, k_state)

        def blend_online_fisher(original: torch.Tensor, realized: torch.Tensor) -> torch.Tensor:
            original_trace = original.diagonal(dim1=-2, dim2=-1).sum(dim=-1)
            realized_trace = realized.diagonal(dim1=-2, dim2=-1).sum(dim=-1)
            normalized_realized = realized * (original_trace / realized_trace.clamp_min(1e-30))[:, None, None]
            blend = float(ATTENTION_ONLINE_GPTQ_BLEND)
            return original * (1.0 - blend) + normalized_realized * blend
        q_hessian = mix_hessian(q_fisher, q_logit)
        k_hessian = mix_hessian(blend_online_fisher(k_fisher, online_k_fisher), k_logit)
        q_state.update({'attention_online_gptq': 'v10-q-unchanged', 'attention_online_gptq_blend': float(ATTENTION_ONLINE_GPTQ_BLEND), 'attention_online_gptq_rows': int(online_rows)})
        k_state.update({'attention_online_gptq': 'qhat-analytic-output-fisher-k', 'attention_online_gptq_blend': float(ATTENTION_ONLINE_GPTQ_BLEND), 'attention_online_gptq_rows': int(online_rows)})
    q_factor, q_residual, q_explained = _low_rank_factors(q_hessian, ATTENTION_HESSIAN_RANK)
    k_factor, k_residual, k_explained = _low_rank_factors(k_hessian, ATTENTION_HESSIAN_RANK)
    if q_enabled:
        q_state.update({'attention_rounding_mode': 'low_rank_schwarz', 'attention_hessian_rank': int(q_factor.shape[1]), 'attention_hessian_factor': q_factor.cpu(), 'attention_hessian_diagonal': q_residual.cpu(), 'attention_hessian_explained_mean': float(q_explained.mean().item()), 'attention_hessian_schwarz_group': ATTENTION_HESSIAN_SCHWARZ_GROUP, 'attention_hessian_schwarz_sweeps': ATTENTION_HESSIAN_SCHWARZ_SWEEPS})
    else:
        q_state['attention_rounding_mode'] = 'direct'
    if k_enabled:
        k_state.update({'attention_rounding_mode': 'low_rank_schwarz', 'attention_hessian_rank': int(k_factor.shape[1]), 'attention_hessian_factor': k_factor.cpu(), 'attention_hessian_diagonal': k_residual.cpu(), 'attention_hessian_explained_mean': float(k_explained.mean().item()), 'attention_hessian_schwarz_group': ATTENTION_HESSIAN_SCHWARZ_GROUP, 'attention_hessian_schwarz_sweeps': ATTENTION_HESSIAN_SCHWARZ_SWEEPS})
    else:
        k_state['attention_rounding_mode'] = 'direct'
    return (q_state, k_state, v_state)

def apply_attention_extra_transform(tensor: torch.Tensor, num_heads: int, head_dim: int, state: dict[str, Any] | None) -> torch.Tensor:
    matrices = None if not state else state.get('attention_extra_transform')
    if matrices is None:
        return tensor.to(torch.float32)
    minimum_rows = int(state.get('attention_extra_transform_min_rows', 0))
    if minimum_rows > 0 and int(tensor.shape[0]) < minimum_rows:
        return tensor.to(torch.float32)
    block_size = int(state['attention_extra_transform_block'])
    kv_num_heads = int(state['kv_num_heads'])
    matrix = matrices.to(device=tensor.device, dtype=torch.float32)
    if int(num_heads) != kv_num_heads:
        if int(num_heads) % kv_num_heads:
            raise ValueError('Q heads must be divisible by KV heads')
        matrix = matrix.repeat_interleave(int(num_heads) // kv_num_heads, dim=0)
    heads = tensor.to(torch.float32).reshape(-1, int(num_heads), int(head_dim))
    blocks = heads.reshape(int(heads.shape[0]), int(num_heads), int(head_dim) // block_size, block_size)
    transformed = torch.einsum('nhbi,hbij->nhbj', blocks, matrix)
    return transformed.reshape(tensor.shape)

def _grid_step(params: dict[str, torch.Tensor], shape: tuple[int, ...]) -> torch.Tensor:
    effective = params['scale_factor'].to(torch.float32) * params['scale_lv2'].to(torch.float32) * params['scale_lv3'].to(torch.float32)
    return (effective * 0.25).expand_as(params['mant']).reshape(shape)

def _pack_signed_codes(params: dict[str, torch.Tensor], signed_codes: torch.Tensor) -> dict[str, torch.Tensor]:
    result = dict(params)
    code_shape = tuple((int(value) for value in params['mant'].shape))
    codes = signed_codes.reshape(code_shape)
    result['sign'] = torch.sign(codes).to(torch.bfloat16)
    result['mant'] = (codes.abs().to(torch.float32) * 0.25).to(torch.bfloat16)
    return result

def _adjacent_codes(target: torch.Tensor, step: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    scaled = target / step.clamp_min(1e-30)
    lower = torch.floor(scaled).clamp(-7.0, 7.0)
    upper = torch.ceil(scaled).clamp(-7.0, 7.0)
    standard = torch.round(scaled).clamp(-7.0, 7.0)
    alternate = torch.where(standard == lower, upper, lower)
    return (standard.to(torch.int8), alternate.to(torch.int8))

def _low_rank_round_group(target: torch.Tensor, step: torch.Tensor, factor: torch.Tensor, diagonal: torch.Tensor, group_size: int, sweeps: int, max_columns: int) -> torch.Tensor:
    standard_code, alternate_code = _adjacent_codes(target, step)
    standard_error = target - standard_code.to(torch.float32) * step
    alternate_error = target - alternate_code.to(torch.float32) * step
    current_error = standard_error.clone()
    current_code = standard_code.clone()
    projected = current_error @ factor.T
    importance = (factor.square().sum(dim=0) + diagonal).argsort(descending=True)
    usable = min(int(target.shape[1]), int(max_columns))
    usable -= usable % int(group_size)
    groups = importance[:usable].reshape(-1, int(group_size))
    pattern_count = 2 ** int(group_size)
    pattern_bits = (torch.arange(pattern_count)[:, None] >> torch.arange(int(group_size))[None, :] & 1).to(torch.bool)
    for _ in range(int(sweeps)):
        for columns in groups:
            old_error = current_error[:, columns]
            old_projected = old_error @ factor[:, columns].T
            outside = projected - old_projected
            standard = standard_error[:, columns]
            alternate = alternate_error[:, columns]
            trials = torch.where(pattern_bits[:, None, :], alternate[None, :, :], standard[None, :, :])
            trial_projection = outside[None, :, :] + torch.einsum('pnc,rc->pnr', trials, factor[:, columns])
            costs = trial_projection.square().sum(dim=-1) + (trials.square() * diagonal[columns][None, None, :]).sum(dim=-1)
            best = costs.argmin(dim=0)
            chosen_bits = pattern_bits.index_select(0, best)
            new_error = torch.where(chosen_bits, alternate, standard)
            new_code = torch.where(chosen_bits, alternate_code[:, columns], standard_code[:, columns])
            current_error[:, columns] = new_error
            current_code[:, columns] = new_code
            projected = outside + new_error @ factor[:, columns].T
    return current_code

def _quantize_attention_hierarchy_grid(tensor: torch.Tensor, num_heads: int, head_dim: int, state: dict[str, Any]) -> dict[str, torch.Tensor]:
    """Select sf/lv2/lv3 using the deployed Attention Hessian diagonal."""
    strength = float(state.get('attention_hierarchy_grid_strength', 0.0))
    search_multipliers = state.get('attention_search_multipliers', DEFAULT_SEARCH_MULTIPLIERS)
    long_minimum_rows = int(state.get('attention_search_long_min_rows', 0))
    if long_minimum_rows > 0 and int(tensor.shape[0]) >= long_minimum_rows:
        search_multipliers = state.get('attention_search_long_multipliers', search_multipliers)
    if strength <= 0.0:
        return quantize_hif4(tensor, search_multipliers=search_multipliers)
    factor, diagonal = _attention_hessian_terms(state, int(tensor.shape[0]))
    importance = factor.square().sum(dim=1) + diagonal
    importance = importance / importance.mean(dim=1, keepdim=True).clamp_min(1e-20)
    importance = importance.clamp(float(ATTENTION_HIERARCHY_WEIGHT_MIN), float(ATTENTION_HIERARCHY_WEIGHT_MAX))
    kv_num_heads = int(state['kv_num_heads'])
    if int(num_heads) % kv_num_heads:
        raise ValueError('Attention heads must be divisible by KV heads')
    group_size = int(num_heads) // kv_num_heads
    head_weight = importance.repeat_interleave(group_size, dim=0)
    heads = tensor.reshape(-1, int(num_heads), int(head_dim))
    element_weight = (1.0 - strength + strength * head_weight[None, :, :]).expand_as(heads).reshape_as(tensor)
    return quantize_hif4(tensor, search_multipliers=search_multipliers, element_weight=element_weight)

def _quantize_low_rank(tensor: torch.Tensor, num_heads: int, head_dim: int, state: dict[str, Any]) -> dict[str, torch.Tensor]:
    params = _quantize_attention_hierarchy_grid(tensor, num_heads, head_dim, state)
    step = _grid_step(params, tuple((int(value) for value in tensor.shape)))
    heads = tensor.to(torch.float32).reshape(-1, int(num_heads), int(head_dim))
    step_heads = step.reshape_as(heads)
    codes = torch.empty_like(heads, dtype=torch.int8)
    kv_num_heads = int(state['kv_num_heads'])
    group_size = int(num_heads) // kv_num_heads
    factors, diagonals = _attention_hessian_terms(state, int(tensor.shape[0]))
    schwarz_group = int(state['attention_hessian_schwarz_group'])
    sweeps = int(state['attention_hessian_schwarz_sweeps'])
    max_columns = int(state['attention_hessian_max_columns'])
    for kv_head in range(kv_num_heads):
        start = kv_head * group_size
        end = start + group_size
        group_target = heads[:, start:end, :].reshape(-1, int(head_dim))
        group_step = step_heads[:, start:end, :].reshape(-1, int(head_dim))
        group_codes = _low_rank_round_group(group_target, group_step, factors[kv_head], diagonals[kv_head], schwarz_group, sweeps, max_columns)
        codes[:, start:end, :] = group_codes.reshape(-1, group_size, int(head_dim))
    return _pack_signed_codes(params, codes.reshape(tensor.shape))

def _quantize_block_hessian(tensor: torch.Tensor, num_heads: int, head_dim: int, state: dict[str, Any]) -> dict[str, torch.Tensor]:
    params = quantize_hif4(tensor)
    step = _grid_step(params, tuple((int(value) for value in tensor.shape)))
    heads = tensor.to(torch.float32).reshape(-1, int(num_heads), int(head_dim))
    step_heads = step.reshape_as(heads)
    codes = torch.empty_like(heads, dtype=torch.int8)
    kv_num_heads = int(state['kv_num_heads'])
    group_size = int(num_heads) // kv_num_heads
    block_size = int(state['attention_hessian_block_size'])
    factors = state['attention_hessian_inverse_cholesky'].to(torch.float32)
    block_count = int(head_dim) // block_size
    for kv_head in range(kv_num_heads):
        head_start = kv_head * group_size
        head_end = head_start + group_size
        group_target = heads[:, head_start:head_end, :].reshape(-1, int(head_dim))
        group_step = step_heads[:, head_start:head_end, :].reshape(-1, int(head_dim))
        group_codes = torch.empty_like(group_target, dtype=torch.int8)
        for block in range(block_count):
            start = block * block_size
            end = start + block_size
            working = group_target[:, start:end].clone()
            local_step = group_step[:, start:end]
            factor = factors[kv_head, block]
            for column in range(block_size):
                scalar_step = local_step[:, column].clamp_min(1e-30)
                code = torch.round(working[:, column] / scalar_step).clamp(-7.0, 7.0)
                quantized = code * scalar_step
                group_codes[:, start + column] = code.to(torch.int8)
                diagonal = factor[column, column].clamp_min(1e-30)
                normalized_error = (working[:, column] - quantized) / diagonal
                working[:, column:] -= normalized_error[:, None] * factor[column, column:][None, :]
        codes[:, head_start:head_end, :] = group_codes.reshape(-1, group_size, int(head_dim))
    return _pack_signed_codes(params, codes.reshape(tensor.shape))

def quantize_attention_hessian(tensor: torch.Tensor, num_heads: int, head_dim: int, state: dict[str, Any] | None) -> dict[str, torch.Tensor]:
    mode = 'direct' if not state else str(state.get('attention_rounding_mode', 'direct'))
    if mode == 'direct':
        return quantize_hif4(tensor)
    if mode == 'low_rank_schwarz':
        return _quantize_low_rank(tensor, num_heads, head_dim, state)
    if mode == 'block_hessian_gptq':
        return _quantize_block_hessian(tensor, num_heads, head_dim, state)
    raise ValueError(f'unsupported Attention rounding mode: {mode}')

def decode_attention_candidate(tensor: torch.Tensor, num_heads: int, head_dim: int, state: dict[str, Any]) -> torch.Tensor:
    """Test helper: apply any extra transform, quantize, and reconstruct."""
    transformed = apply_attention_extra_transform(tensor, num_heads, head_dim, state)
    return dequantize_hif4(quantize_attention_hessian(transformed, num_heads, head_dim, state))

def _attention_rotation_calibration_scores(calib_qkv_list: list, q_num_heads: int, kv_num_heads: int, head_dim: int, q_state: dict[str, Any], k_state: dict[str, Any]) -> tuple[float, ...]:
    """Measure a rotation with output MSE on bounded long-sequence folds."""
    scores: list[float] = []
    for sample in calib_qkv_list:
        original_rows = int(sample['q'][0].shape[0])
        if original_rows < int(ATTENTION_BLOCK_ROTATION_MIN_ROWS):
            continue
        q = dequantize_nvfp4(*sample['q']).to(torch.float32)
        k = center_attention_k(dequantize_nvfp4(*sample['k']).to(torch.float32), kv_num_heads, head_dim)
        v = dequantize_nvfp4(*sample['v']).to(torch.float32)
        q = _hessian_sample_rows(q, ATTENTION_BLOCK_ROTATION_CALIB_ROWS)
        k = _hessian_sample_rows(k, ATTENTION_BLOCK_ROTATION_CALIB_ROWS)
        v = _hessian_sample_rows(v, ATTENTION_BLOCK_ROTATION_CALIB_ROWS)
        reference = _hessian_gqa_attention(q, k, v, q_num_heads, kv_num_heads, head_dim)
        reconstructed_v = dequantize_hif4(quantize_hif4(v)).to(torch.float32)
        transformed_q = transform_attention_q_structured(q, q_num_heads, head_dim, q_state)
        transformed_q = apply_attention_extra_transform(transformed_q, q_num_heads, head_dim, q_state)
        transformed_k = transform_attention_k_structured(k, kv_num_heads, head_dim, k_state)
        transformed_k = apply_attention_extra_transform(transformed_k, kv_num_heads, head_dim, k_state)
        reconstructed_q = dequantize_hif4(quantize_attention_hessian(transformed_q, q_num_heads, head_dim, q_state)).to(torch.float32)
        reconstructed_k = dequantize_hif4(quantize_attention_hessian(transformed_k, kv_num_heads, head_dim, k_state)).to(torch.float32)
        actual = _hessian_gqa_attention(reconstructed_q, reconstructed_k, reconstructed_v, q_num_heads, kv_num_heads, head_dim)
        scores.append(_relative_output_mse(reference, actual))
    return tuple(scores)

def select_attention_block64_rotation(calib_qkv_list: list, q_num_heads: int, kv_num_heads: int, head_dim: int, q_state: dict[str, Any], k_state: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    """Select one shared block rotation with a no-regression fold gate."""
    baseline_scores = _attention_rotation_calibration_scores(calib_qkv_list, q_num_heads, kv_num_heads, head_dim, q_state, k_state)
    best: tuple[float, float, int, torch.Tensor] | None = None
    for seed in ATTENTION_BLOCK_ROTATION_SEEDS:
        matrices = _build_attention_block64_rotation(kv_num_heads, head_dim, int(seed))
        trial_q = _rotate_attention_hessian_state(q_state, matrices, seed=int(seed), minimum_rows=0)
        trial_k = _rotate_attention_hessian_state(k_state, matrices, seed=int(seed), minimum_rows=0)
        trial_scores = _attention_rotation_calibration_scores(calib_qkv_list, q_num_heads, kv_num_heads, head_dim, trial_q, trial_k)
        if len(trial_scores) != len(baseline_scores) or not trial_scores:
            continue
        gains = tuple(((baseline - trial) / max(abs(baseline), 1e-30) for baseline, trial in zip(baseline_scores, trial_scores)))
        mean_gain = float(sum(gains) / len(gains))
        worst_gain = float(min(gains))
        if mean_gain < float(ATTENTION_BLOCK_ROTATION_MEAN_GAIN_MIN):
            continue
        if worst_gain < float(ATTENTION_BLOCK_ROTATION_WORST_GAIN_MIN):
            continue
        ranked = (mean_gain, worst_gain, -int(seed), matrices)
        if best is None or ranked[:3] > best[:3]:
            best = ranked
    selected_q = dict(q_state)
    selected_k = dict(k_state)
    enabled = best is not None
    selected_seed = -1
    mean_gain = 0.0
    worst_gain = 0.0
    if best is not None:
        mean_gain, worst_gain, negative_seed, matrices = best
        selected_seed = -int(negative_seed)
        selected_q = _rotate_attention_hessian_state(q_state, matrices, seed=selected_seed, minimum_rows=ATTENTION_BLOCK_ROTATION_MIN_ROWS)
        selected_k = _rotate_attention_hessian_state(k_state, matrices, seed=selected_seed, minimum_rows=ATTENTION_BLOCK_ROTATION_MIN_ROWS)
    diagnostics = {'attention_block_rotation_enabled': bool(enabled), 'attention_block_rotation_selected_seed': int(selected_seed), 'attention_block_rotation_candidate_count': int(len(ATTENTION_BLOCK_ROTATION_SEEDS)), 'attention_block_rotation_fold_count': int(len(baseline_scores)), 'attention_block_rotation_mean_gain': float(mean_gain), 'attention_block_rotation_worst_gain': float(worst_gain), 'attention_block_rotation_min_rows': int(ATTENTION_BLOCK_ROTATION_MIN_ROWS), 'attention_block_rotation_policy': 'long-sequence-output-mse-mean-and-worst-gated'}
    selected_q.update(diagnostics)
    selected_k.update(diagnostics)
    return (selected_q, selected_k)
'Shared six-function implementation for Attention Hessian/SVD variants.'

def calibration_and_quantize_weight(weight_quant: torch.Tensor, weight_scale: torch.Tensor, calib_activation_list: list) -> dict[str, Any]:
    """Keep the scored hierarchy-GPTQ Linear path fixed across all variants."""
    weight = dequantize_nvfp4(weight_quant, weight_scale).to(torch.float32)
    state = select_linear_state(weight, calib_activation_list)
    transformed_weight = transform_linear_tensor(weight, state, inverse_scale=False)
    channels = int(weight.shape[-1])

    def stream():
        for quant, scale in calib_activation_list:
            activation = dequantize_nvfp4(quant, scale).to(torch.float32).reshape(-1, channels)
            transformed = transform_linear_tensor(activation, state, inverse_scale=True)
            for start in range(0, int(transformed.shape[0]), 256):
                yield transformed[start:start + 256]
    weight_params = quantize_hif4_greedy(transformed_weight)
    quantized_weight = dequantize_hif4(weight_params)
    activation_hessian = quantized_weight_hessian_svd(quantized_weight, ACTIVATION_GPTQ_RANK)
    activation_state = dict(state)
    activation_state.update({'weight_grid_mode': 'activation-hessian-weighted', 'weight_grid_strength': float(GPTQ_WEIGHT_GRID_STRENGTH), 'activation_rounding_mode': 'qw_svd_top64_exact_block', 'activation_hessian_rank': int(activation_hessian['vw'].shape[0]), 'activation_hessian': activation_hessian})
    return {'weight_params': weight_params, 'activation_state': activation_state}

def dynamic_quantize_activation(activation_quant: torch.Tensor, activation_scale: torch.Tensor, activation_state: Any) -> dict[str, torch.Tensor]:
    activation = dequantize_nvfp4(activation_quant, activation_scale).to(torch.float32)
    transformed = transform_linear_tensor(activation, activation_state, inverse_scale=True)
    params = quantize_hif4_gptq_tensor_fast(transformed, activation_state['activation_hessian'])
    return params

def calibration_attention(calib_qkv_list: list, q_num_heads: int, kv_num_heads: int, head_dim: int, *, method: str) -> dict[str, Any]:
    q_state, k_state, v_state = calibrate_attention_hessian(calib_qkv_list, q_num_heads, kv_num_heads, head_dim, method=method)
    q_state['attention_hessian_max_columns'] = ATTENTION_Q_SCHWARZ_MAX_COLUMNS
    k_state['attention_hessian_max_columns'] = ATTENTION_K_SCHWARZ_MAX_COLUMNS
    q_state['attention_hierarchy_grid_strength'] = float(ATTENTION_HIERARCHY_GRID_STRENGTH)
    k_state['attention_hierarchy_grid_strength'] = float(ATTENTION_HIERARCHY_GRID_STRENGTH)
    q_state['attention_hierarchy_grid_mode'] = 'online-hessian-diagonal-full-hierarchy'
    k_state['attention_hierarchy_grid_mode'] = 'online-hessian-diagonal-full-hierarchy'
    v_state.update({'v_rounding_mode': 'length-adaptive-local-low-frequency', 'v_local_window': int(V_LOCAL_WINDOW), 'v_local_mean_penalty': float(V_LOCAL_MEAN_PENALTY), 'v_local_mode_penalty': float(V_LOCAL_MODE_PENALTY), 'v_local_mode_count': int(V_LOCAL_MODE_COUNT), 'v_long_sequence_min_rows': int(V_LONG_SEQUENCE_MIN_ROWS), 'v_long_window': int(V_LONG_WINDOW), 'v_long_mode_count': int(V_LONG_MODE_COUNT), 'v_output_shape_min_rows': 512, 'v_output_shape_search_multipliers': (0.5, 0.625, 0.75, 1.0, 1.125, 1.25), 'v_output_shape_window': 40, 'v_output_shape_mode_count': 6, 'v_output_shape_max_steps': 4, 'v_output_shape_position_weight_strength': 1.0})
    block_rotation = _build_attention_block64_rotation(kv_num_heads, head_dim, seed=0)
    q_state = _rotate_attention_hessian_state(q_state, block_rotation, seed=0, minimum_rows=ATTENTION_BLOCK_ROTATION_MIN_ROWS)
    k_state = _rotate_attention_hessian_state(k_state, block_rotation, seed=0, minimum_rows=ATTENTION_BLOCK_ROTATION_MIN_ROWS)
    fixed_rotation = {'attention_block_rotation_enabled': True, 'attention_block_rotation_selected_seed': 0, 'attention_block_rotation_candidate_count': 1, 'attention_block_rotation_fold_count': 0, 'attention_block_rotation_mean_gain': 0.0, 'attention_block_rotation_worst_gain': 0.0, 'attention_block_rotation_min_rows': int(ATTENTION_BLOCK_ROTATION_MIN_ROWS), 'attention_block_rotation_policy': 'fixed-seed0-no-candidate-replay'}
    q_state.update(fixed_rotation)
    k_state.update(fixed_rotation)
    q_state.update({'attention_search_long_min_rows': int(ATTENTION_Q_LONG_SF_MIN_ROWS), 'attention_search_long_multipliers': ATTENTION_Q_LONG_SEARCH_MULTIPLIERS, 'attention_q_sf_search_policy': 'pruned-grid-for-very-long-sequences'})
    k_state.update({'attention_search_multipliers': ATTENTION_K_OUTPUT_SEARCH_MULTIPLIERS, 'attention_search_long_min_rows': int(ATTENTION_BLOCK_ROTATION_MIN_ROWS), 'attention_search_long_multipliers': ATTENTION_K_LONG_SEARCH_MULTIPLIERS, 'attention_k_sf_search_enabled': True, 'attention_k_sf_search_policy': 'length-adaptive-output-ablation-grid'})
    return {'q_state': q_state, 'k_state': k_state, 'v_state': v_state}

def dynamic_quantize_q(q_quant: torch.Tensor, q_scale: torch.Tensor, q_num_heads: int, head_dim: int, q_state: Any) -> dict[str, torch.Tensor]:
    q = dequantize_nvfp4(q_quant, q_scale).to(torch.float32)
    q = transform_attention_q_structured(q, q_num_heads, head_dim, q_state)
    q = apply_attention_extra_transform(q, q_num_heads, head_dim, q_state)
    return quantize_attention_hessian(q, q_num_heads, head_dim, q_state)

def dynamic_quantize_k(k_quant: torch.Tensor, k_scale: torch.Tensor, kv_num_heads: int, head_dim: int, k_state: Any) -> dict[str, torch.Tensor]:
    k = dequantize_nvfp4(k_quant, k_scale).to(torch.float32)
    k = center_attention_k(k, kv_num_heads, head_dim)
    k = transform_attention_k_structured(k, kv_num_heads, head_dim, k_state)
    k = apply_attention_extra_transform(k, kv_num_heads, head_dim, k_state)
    return quantize_attention_hessian(k, kv_num_heads, head_dim, k_state)

def dynamic_quantize_v(v_quant: torch.Tensor, v_scale: torch.Tensor, kv_num_heads: int, head_dim: int, v_state: Any) -> dict[str, torch.Tensor]:
    del kv_num_heads, head_dim
    v = dequantize_nvfp4(v_quant, v_scale).to(torch.float32)
    window = int(V_LOCAL_WINDOW)
    mean_penalty = float(V_LOCAL_MEAN_PENALTY)
    mode_penalty = float(V_LOCAL_MODE_PENALTY)
    mode_count = int(V_LOCAL_MODE_COUNT)
    long_sequence_min_rows = int(V_LONG_SEQUENCE_MIN_ROWS)
    long_window = int(V_LONG_WINDOW)
    long_mode_count = int(V_LONG_MODE_COUNT)
    output_shape_min_rows = 512
    output_shape_search_multipliers = DEFAULT_SEARCH_MULTIPLIERS
    output_shape_window = 40
    output_shape_mode_count = 6
    output_shape_max_steps = 4
    output_shape_position_weight_strength = 1.0
    if isinstance(v_state, dict):
        window = int(v_state.get('v_local_window', window))
        mean_penalty = float(v_state.get('v_local_mean_penalty', mean_penalty))
        mode_penalty = float(v_state.get('v_local_mode_penalty', mode_penalty))
        mode_count = int(v_state.get('v_local_mode_count', mode_count))
        long_sequence_min_rows = int(v_state.get('v_long_sequence_min_rows', long_sequence_min_rows))
        long_window = int(v_state.get('v_long_window', long_window))
        long_mode_count = int(v_state.get('v_long_mode_count', long_mode_count))
        output_shape_min_rows = int(v_state.get('v_output_shape_min_rows', output_shape_min_rows))
        output_shape_search_multipliers = tuple((float(value) for value in v_state.get('v_output_shape_search_multipliers', output_shape_search_multipliers)))
        output_shape_window = int(v_state.get('v_output_shape_window', output_shape_window))
        output_shape_mode_count = int(v_state.get('v_output_shape_mode_count', output_shape_mode_count))
        output_shape_max_steps = int(v_state.get('v_output_shape_max_steps', output_shape_max_steps))
        output_shape_position_weight_strength = float(v_state.get('v_output_shape_position_weight_strength', output_shape_position_weight_strength))
    search_multipliers = DEFAULT_SEARCH_MULTIPLIERS
    max_steps = None
    position_weight_strength = 0.0
    if int(v.shape[0]) >= long_sequence_min_rows:
        window = long_window
        mode_count = long_mode_count
    if int(v.shape[0]) >= output_shape_min_rows:
        search_multipliers = output_shape_search_multipliers
        window = output_shape_window
        mode_count = output_shape_mode_count
        max_steps = output_shape_max_steps
        position_weight_strength = output_shape_position_weight_strength
    return quantize_hif4_v_local_modes(v, window=window, mean_penalty=mean_penalty, mode_penalty=mode_penalty, mode_count=mode_count, search_multipliers=search_multipliers, max_steps=max_steps, position_weight_strength=position_weight_strength)
'v21.1-fast: v20 plus fixed, zero-replay block-64 Fisher rotation.'
METHOD = 'fisher_svd'
hif4_calibration_and_quantize_weight = calibration_and_quantize_weight
hif4_dynamic_quantize_activation = dynamic_quantize_activation
hif4_dynamic_quantize_q = dynamic_quantize_q
hif4_dynamic_quantize_k = dynamic_quantize_k
hif4_dynamic_quantize_v = dynamic_quantize_v

def hif4_calibration_attention(calib_qkv_list: list, q_num_heads: int, kv_num_heads: int, head_dim: int) -> dict[str, Any]:
    return calibration_attention(calib_qkv_list, q_num_heads, kv_num_heads, head_dim, method=METHOD)
ACTIVATION_GPTQ_RANK = 512
LINEAR_OUTPUT_COMPENSATION_DAMP = 0.001

def _top24_linear_rank512_calibration_and_quantize_weight(
    weight_quant,
    weight_scale,
    calib_activation_list,
    *,
    _return_context=False,
):
    weight = dequantize_nvfp4(weight_quant, weight_scale).to(torch.float32)
    state = select_linear_state(weight, calib_activation_list)
    transformed_weight = transform_linear_tensor(weight, state, inverse_scale=False)
    channels = int(weight.shape[-1])

    # Every consumer below is read-only. Materialize the selected transform
    # once instead of replaying dequantization and the Hadamard transform.
    # This cache stays private and never enters the public frozen state.
    transformed_calibration = []
    for quant, scale in calib_activation_list:
        activation = dequantize_nvfp4(quant, scale).to(torch.float32).reshape(
            -1, channels
        )
        transformed_calibration.append(
            transform_linear_tensor(activation, state, inverse_scale=True)
        )

    def stream():
        for transformed in transformed_calibration:
            for start in range(0, int(transformed.shape[0]), 256):
                yield transformed[start:start + 256]
    svd = streaming_svd(stream, channels, GPTQ_RANK)
    weight_params = quantize_hif4_gptq_weight(transformed_weight, svd, sweeps=GPTQ_SCHWARZ_SWEEPS)
    weight_block_hessian = torch.zeros((channels // 64, 64, 64), dtype=torch.float32)
    for activation_batch in stream():
        activation_blocks = activation_batch.reshape(-1, channels // 64, 64)
        weight_block_hessian += torch.einsum('nbc,nbd->bcd', activation_blocks, activation_blocks)
    weight_factor = svd['vw'].to(torch.float32)
    weight_diagonal = (svd['an_full'].to(torch.float32) - weight_factor.square().sum(dim=0)).clamp_min(svd['an_full'].to(torch.float32).mean() * 1e-06)
    weight_cd_state = {'vw': weight_factor, 'an_full': weight_diagonal, 'activation_block_hessian': weight_block_hessian}
    weight_params = refine_hif4_activation_exact_block64(transformed_weight, weight_params, weight_cd_state, sweeps=1)
    quantized_weight = dequantize_hif4(weight_params)
    output_hessian = quantized_weight.T @ quantized_weight
    v21_dor_hessian = output_hessian
    output_cross_residual = quantized_weight.T @ (transformed_weight - quantized_weight)
    output_diagonal_mean = torch.diagonal(output_hessian).mean().clamp_min(1e-30)
    output_hessian = output_hessian + torch.eye(channels, dtype=torch.float32) * (output_diagonal_mean * LINEAR_OUTPUT_COMPENSATION_DAMP)
    output_cholesky = torch.linalg.cholesky(output_hessian)
    output_correction_transpose = torch.cholesky_solve(output_cross_residual, output_cholesky)
    output_preconditioner = (torch.eye(channels, dtype=torch.float32) + output_correction_transpose.T).contiguous()
    activation_hessian = quantized_weight_hessian_svd(quantized_weight, ACTIVATION_GPTQ_RANK)
    weight_blocks = quantized_weight.reshape(int(quantized_weight.shape[0]), channels // 64, 64)
    activation_hessian['activation_block_hessian'] = torch.einsum('obc,obd->bcd', weight_blocks, weight_blocks).contiguous()
    activation_state = dict(state)
    activation_state.update({'weight_grid_mode': 'activation-hessian-weighted', 'weight_grid_strength': float(GPTQ_WEIGHT_GRID_STRENGTH), 'activation_rounding_mode': 'qw_svd_top64_exact_block', 'activation_hessian_rank': int(activation_hessian['vw'].shape[0]), 'activation_hessian': activation_hessian, 'activation_output_compensation': 'global-cross-target', 'activation_output_compensation_damp': float(LINEAR_OUTPUT_COMPENSATION_DAMP), 'activation_output_preconditioner': output_preconditioner})
    result = {'weight_params': weight_params, 'activation_state': activation_state}
    if _return_context:
        return result, {
            'raw_weight': weight,
            'transformed_weight': transformed_weight,
            'quantized_weight': quantized_weight,
            'v21_dor_hessian': v21_dor_hessian,
            'transformed_calibration': transformed_calibration,
        }
    return result

def _top24_linear_rank512_dynamic_quantize_activation(activation_quant, activation_scale, activation_state):
    activation = dequantize_nvfp4(activation_quant, activation_scale).to(torch.float32)
    transformed = transform_linear_tensor(activation, activation_state, inverse_scale=True)
    transformed = transformed @ activation_state['activation_output_preconditioner'].to(torch.float32)
    params = quantize_hif4_gptq_tensor_fast(transformed, activation_state['activation_hessian'])
    return refine_hif4_activation_exact_block64(transformed, params, activation_state['activation_hessian'])
hif4_calibration_and_quantize_weight = _top24_linear_rank512_calibration_and_quantize_weight
hif4_dynamic_quantize_activation = _top24_linear_rank512_dynamic_quantize_activation
_V21_DOR_COLORS = 1
_v21_dor_parent_cal = hif4_calibration_and_quantize_weight

def _v21_dor_cal(
    weight_quant,
    weight_scale,
    calib_activation_list,
    *,
    _return_context=False,
):
    result, context = _v21_dor_parent_cal(
        weight_quant,
        weight_scale,
        calib_activation_list,
        _return_context=True,
    )
    state = result['activation_state']
    quantized_weight = context['quantized_weight']
    hessian = context['v21_dor_hessian']
    channels = int(hessian.shape[0])
    blocks = channels // 64
    colors = math.gcd(blocks, _V21_DOR_COLORS)
    blocks_per_color = blocks // colors
    block_indices = torch.arange(blocks, dtype=torch.long)
    columns = torch.empty((64, colors, blocks_per_color), dtype=torch.long)
    diagonal = torch.empty((64, colors, blocks_per_color), dtype=torch.float32)
    local_hessian = torch.empty((64, colors, blocks_per_color, blocks_per_color), dtype=torch.float32)
    hessian_rows = torch.empty((64, colors, blocks_per_color, channels), dtype=torch.float32)
    for local_column in range(64):
        for color in range(colors):
            selected = block_indices[color::colors] * 64 + local_column
            columns[local_column, color] = selected
            diagonal[local_column, color] = hessian[selected, selected]
            local_hessian[local_column, color] = hessian.index_select(0, selected).index_select(1, selected)
            hessian_rows[local_column, color] = hessian.index_select(0, selected)
    state.update({'v21_dor_hessian': hessian.contiguous(), 'v21_dor_columns': columns, 'v21_dor_diagonal': diagonal.clamp_min(1e-20), 'v21_dor_local_hessian': local_hessian, 'v21_dor_hessian_rows': hessian_rows, 'v21_dor_colors': int(colors)})
    if _return_context:
        return result, context
    return result

def _v21_dor_dynamic(activation_quant, activation_scale, activation_state):
    raw = dequantize_nvfp4(activation_quant, activation_scale).to(torch.float32)
    raw = transform_linear_tensor(raw, activation_state, inverse_scale=True)
    target = raw @ activation_state['activation_output_preconditioner'].to(torch.float32)
    params = quantize_hif4_gptq_tensor_fast(target, activation_state['activation_hessian'])
    params = refine_hif4_activation_exact_block64(target, params, activation_state['activation_hessian'])
    shape = tuple((int(value) for value in target.shape))
    channels = int(shape[-1])
    rows = int(target.numel()) // channels
    blocks = channels // 64
    scale_factor = params['scale_factor'].to(torch.float32).reshape(rows, blocks)
    scale_lv2 = params['scale_lv2'].to(torch.float32).reshape(rows, blocks, 8)
    scale_lv3 = params['scale_lv3'].to(torch.float32).reshape(rows, blocks, 8, 2)
    step = (scale_factor[:, :, None, None, None] * scale_lv2[:, :, :, None, None] * scale_lv3[:, :, :, :, None] * 0.25).expand(-1, -1, -1, -1, 4).reshape(rows, channels)
    codes = (params['sign'].to(torch.float32) * params['mant'].to(torch.float32) * 4.0).reshape(rows, channels).round().clamp_(-7.0, 7.0)
    quantized = codes * step
    hessian = activation_state['v21_dor_hessian'].to(torch.float32)
    damping = torch.diagonal(hessian).mean() * float(LINEAR_OUTPUT_COMPENSATION_DAMP)
    residual_gradient = (target.reshape(rows, channels) - quantized) @ hessian + damping * (target.reshape(rows, channels) - raw.reshape(rows, channels))
    columns_all = activation_state['v21_dor_columns'].to(torch.long)
    diagonal_all = activation_state['v21_dor_diagonal'].to(torch.float32)
    local_hessian_all = activation_state['v21_dor_local_hessian'].to(torch.float32)
    hessian_rows_all = activation_state['v21_dor_hessian_rows'].to(torch.float32)
    colors = int(activation_state['v21_dor_colors'])
    local_diagonal = torch.diagonal(hessian).reshape(blocks, 64).clamp_min(1e-20)
    order_score = (residual_gradient.reshape(rows, blocks, 64).square() / local_diagonal[None, :, :]).sum(dim=(0, 1))
    local_column_order = order_score.argsort(descending=True, stable=True).tolist()
    local_column_order = local_column_order + local_column_order[:32]
    for local_column in local_column_order:
        for color in range(colors):
            columns = columns_all[local_column, color]
            diagonal = diagonal_all[local_column, color]
            local_hessian = local_hessian_all[local_column, color]
            hessian_rows = hessian_rows_all[local_column, color]
            local_step = step.index_select(1, columns)
            old_codes = codes.index_select(1, columns)
            old_quantized = old_codes * local_step
            local_gradient = residual_gradient.index_select(1, columns)
            proposal_codes = torch.round((old_quantized + local_gradient / diagonal) / local_step).clamp_(-7.0, 7.0)
            delta = proposal_codes * local_step - old_quantized
            objective_delta = -2.0 * (delta * local_gradient).sum(dim=1)
            objective_delta += torch.einsum('ni,ij,nj->n', delta, local_hessian, delta)
            accepted = objective_delta < -1e-12
            accepted_delta = torch.where(accepted[:, None], delta, torch.zeros_like(delta))
            codes[:, columns] = torch.where(accepted[:, None], proposal_codes, old_codes)
            residual_gradient.sub_(accepted_delta @ hessian_rows)
    result = dict(params)
    code_shape = tuple((int(value) for value in params['mant'].shape))
    result['sign'] = torch.sign(codes).reshape(code_shape).to(torch.bfloat16)
    result['mant'] = (codes.abs() * 0.25).reshape(code_shape).to(torch.bfloat16)
    return result
hif4_calibration_and_quantize_weight = _v21_dor_cal
hif4_dynamic_quantize_activation = _v21_dor_dynamic
_JOINT_LONG_RANK_MIN_ROWS = 128
_JOINT_LONG_SWEEPS = 1
_joint_rank_parent_cal = hif4_calibration_attention

def _joint_make_short_terms(state, short_max_columns):
    original_factor = state['attention_unrotated_hessian_factor'].to(torch.float32)
    original_diagonal = state['attention_unrotated_hessian_diagonal'].to(torch.float32)
    short_factor = original_factor[:, :8, :].contiguous()
    total_diagonal = original_factor.square().sum(dim=1) + original_diagonal
    short_diagonal = (total_diagonal - short_factor.square().sum(dim=1)).clamp_min(total_diagonal.mean(dim=1, keepdim=True) * 1e-05)
    rotated_factor = state['attention_hessian_factor'].to(torch.float32)[:, :8, :].contiguous()
    matrices = state['attention_extra_transform'].to(torch.float32)
    rotated_diagonal = torch.empty_like(short_diagonal)
    block_size = int(state['attention_extra_transform_block'])
    for head in range(int(short_diagonal.shape[0])):
        for block in range(int(short_diagonal.shape[1]) // block_size):
            start = block * block_size
            end = start + block_size
            rotated_diagonal[head, start:end] = short_diagonal[head, start:end] @ matrices[head, block].square()
    state.update({'joint_short_unrotated_factor': short_factor, 'joint_short_unrotated_diagonal': short_diagonal, 'joint_short_rotated_factor': rotated_factor, 'joint_short_rotated_diagonal': rotated_diagonal, 'joint_short_max_columns': int(short_max_columns), 'joint_long_rank_min_rows': int(_JOINT_LONG_RANK_MIN_ROWS)})

def hif4_calibration_attention(calib_qkv_list, q_num_heads, kv_num_heads, head_dim):
    result = _joint_rank_parent_cal(calib_qkv_list, q_num_heads, kv_num_heads, head_dim)
    _joint_make_short_terms(result['q_state'], 32)
    _joint_make_short_terms(result['k_state'], 48)
    return result

def _attention_hessian_terms(state, row_count):
    if int(row_count) < int(state.get('joint_long_rank_min_rows', 0)) and 'joint_short_rotated_factor' in state:
        minimum_rows = int(state.get('attention_extra_transform_min_rows', 0))
        if minimum_rows > 0 and int(row_count) < minimum_rows:
            return (state['joint_short_unrotated_factor'].to(torch.float32), state['joint_short_unrotated_diagonal'].to(torch.float32))
        return (state['joint_short_rotated_factor'].to(torch.float32), state['joint_short_rotated_diagonal'].to(torch.float32))
    minimum_rows = int(state.get('attention_extra_transform_min_rows', 0))
    if minimum_rows > 0 and int(row_count) < minimum_rows and ('attention_unrotated_hessian_factor' in state):
        return (state['attention_unrotated_hessian_factor'].to(torch.float32), state['attention_unrotated_hessian_diagonal'].to(torch.float32))
    return (state['attention_hessian_factor'].to(torch.float32), state['attention_hessian_diagonal'].to(torch.float32))
_joint_rank_parent_q = hif4_dynamic_quantize_q
_joint_rank_parent_k = hif4_dynamic_quantize_k

def _joint_set_length_budget(state, row_count, short_columns):
    state = dict(state)
    if int(row_count) < int(state.get('joint_long_rank_min_rows', 0)):
        state['attention_hessian_max_columns'] = int(short_columns)
        state['attention_hessian_schwarz_sweeps'] = 2
    else:
        state['attention_hessian_schwarz_sweeps'] = int(_JOINT_LONG_SWEEPS)
    return state

def hif4_dynamic_quantize_q(q_quant, q_scale, q_num_heads, head_dim, q_state):
    return _joint_rank_parent_q(q_quant, q_scale, q_num_heads, head_dim, _joint_set_length_budget(q_state, int(q_quant.shape[0]), 32))

def hif4_dynamic_quantize_k(k_quant, k_scale, kv_num_heads, head_dim, k_state):
    return _joint_rank_parent_k(k_quant, k_scale, kv_num_heads, head_dim, _joint_set_length_budget(k_state, int(k_quant.shape[0]), 48))
_JOINT_PATTERN_BITS_2 = torch.tensor(((False, False), (True, False), (False, True), (True, True)), dtype=torch.bool)
_JOINT_PATTERN_BITS_3 = (torch.arange(8)[:, None] >> torch.arange(3)[None, :] & 1).to(torch.bool)
_JOINT_PATTERN_BITS_4 = (torch.arange(16)[:, None] >> torch.arange(4)[None, :] & 1).to(torch.bool)
_joint_exec_parent_cal = hif4_calibration_attention

def _joint_prepare_one_terms(state, prefix, factor_key, diagonal_key, max_columns):
    if factor_key not in state or diagonal_key not in state:
        return
    factor = state[factor_key].to(torch.float32)
    diagonal = state[diagonal_key].to(torch.float32)
    importance = factor.square().sum(dim=1) + diagonal
    usable = min(int(factor.shape[-1]), int(max_columns))
    group_size = int(state.get('attention_hessian_schwarz_group', 2))
    usable -= usable % group_size
    groups = importance.argsort(dim=1, descending=True)[:, :usable].reshape(int(factor.shape[0]), -1, group_size)
    state['joint_' + prefix + '_importance'] = importance.contiguous()
    state['joint_' + prefix + '_groups'] = groups.to(torch.long).contiguous()

def _joint_prepare_attention_state(state):
    max_columns = int(state['attention_hessian_max_columns'])
    _joint_prepare_one_terms(state, 'rotated', 'attention_hessian_factor', 'attention_hessian_diagonal', max_columns)
    _joint_prepare_one_terms(state, 'unrotated', 'attention_unrotated_hessian_factor', 'attention_unrotated_hessian_diagonal', max_columns)
    short_columns = int(state.get('joint_short_max_columns', max_columns))
    _joint_prepare_one_terms(state, 'short_rotated', 'joint_short_rotated_factor', 'joint_short_rotated_diagonal', short_columns)
    _joint_prepare_one_terms(state, 'short_unrotated', 'joint_short_unrotated_factor', 'joint_short_unrotated_diagonal', short_columns)

def hif4_calibration_attention(calib_qkv_list, q_num_heads, kv_num_heads, head_dim):
    result = _joint_exec_parent_cal(calib_qkv_list, q_num_heads, kv_num_heads, head_dim)
    _joint_prepare_attention_state(result['q_state'])
    _joint_prepare_attention_state(result['k_state'])
    return result

def _joint_select_terms(state, row_count):
    minimum_rows = int(state.get('attention_extra_transform_min_rows', 0))
    unrotated = minimum_rows > 0 and int(row_count) < minimum_rows
    short = 'joint_short_rotated_factor' in state and int(row_count) < int(state.get('joint_long_rank_min_rows', 0))
    if short:
        prefix = 'short_unrotated' if unrotated else 'short_rotated'
        factor_key = 'joint_short_unrotated_factor' if unrotated else 'joint_short_rotated_factor'
        diagonal_key = 'joint_short_unrotated_diagonal' if unrotated else 'joint_short_rotated_diagonal'
    else:
        prefix = 'unrotated' if unrotated else 'rotated'
        factor_key = 'attention_unrotated_hessian_factor' if unrotated else 'attention_hessian_factor'
        diagonal_key = 'attention_unrotated_hessian_diagonal' if unrotated else 'attention_hessian_diagonal'
    factor = state[factor_key].to(torch.float32)
    diagonal = state[diagonal_key].to(torch.float32)
    importance_key = 'joint_' + prefix + '_importance'
    groups_key = 'joint_' + prefix + '_groups'
    if importance_key in state and groups_key in state:
        importance = state[importance_key].to(torch.float32)
        groups = state[groups_key].to(torch.long)
    else:
        importance = factor.square().sum(dim=1) + diagonal
        max_columns = int(state['attention_hessian_max_columns'])
        usable = min(int(factor.shape[-1]), max_columns)
        group_size = int(state.get('attention_hessian_schwarz_group', 2))
        usable -= usable % group_size
        groups = importance.argsort(dim=1, descending=True)[:, :usable].reshape(int(factor.shape[0]), -1, group_size)
    return (factor, diagonal, importance, groups)

def _quantize_attention_hierarchy_grid(tensor, num_heads, head_dim, state):
    strength = float(state.get('attention_hierarchy_grid_strength', 0.0))
    search_multipliers = state.get('attention_search_multipliers', DEFAULT_SEARCH_MULTIPLIERS)
    long_minimum_rows = int(state.get('attention_search_long_min_rows', 0))
    if long_minimum_rows > 0 and int(tensor.shape[0]) >= long_minimum_rows:
        search_multipliers = state.get('attention_search_long_multipliers', search_multipliers)
    if strength <= 0.0:
        return quantize_hif4(tensor, search_multipliers=search_multipliers)
    _, _, importance, _ = _joint_select_terms(state, int(tensor.shape[0]))
    importance = importance / importance.mean(dim=1, keepdim=True).clamp_min(1e-20)
    importance = importance.clamp(float(ATTENTION_HIERARCHY_WEIGHT_MIN), float(ATTENTION_HIERARCHY_WEIGHT_MAX))
    kv_num_heads = int(state['kv_num_heads'])
    group_size = int(num_heads) // kv_num_heads
    head_weight = importance.repeat_interleave(group_size, dim=0)
    heads = tensor.reshape(-1, int(num_heads), int(head_dim))
    element_weight = (1.0 - strength + strength * head_weight[None, :, :]).expand_as(heads).reshape_as(tensor)
    return quantize_hif4(tensor, search_multipliers=search_multipliers, element_weight=element_weight)

def _joint_choose_second_groups_single(current_error, current_code, standard_error, alternate_error, standard_code, projected, factor, diagonal, groups, selected_count):
    other_error = torch.where(current_code == standard_code, alternate_error, standard_error)
    difference = other_error - current_error
    gradient = torch.einsum('hnr,hrc->hnc', projected, factor)
    hessian_diagonal = factor.square().sum(dim=1) + diagonal
    coordinate_gain = -(2.0 * difference * gradient + difference.square() * hessian_diagonal[:, None, :]).sum(dim=1)
    head_count = int(groups.shape[0])
    group_count = int(groups.shape[1])
    group_size = int(groups.shape[2])
    group_gain = torch.gather(coordinate_gain, 1, groups.reshape(head_count, -1)).reshape(head_count, group_count, group_size).sum(dim=2)
    selected = group_gain.topk(min(int(selected_count), group_count), dim=1, largest=True, sorted=True).indices
    return torch.gather(groups, 1, selected[:, :, None].expand(-1, -1, group_size))

def _joint_choose_second_groups(current_error, standard_error, alternate_error, projected, factor, diagonal, groups, selected_count, pattern_bits):
    head_count, rows, channels = current_error.shape
    group_count = int(groups.shape[1])
    group_size = int(groups.shape[2])
    row_index = groups[:, None, :, :].expand(-1, rows, -1, -1)
    expanded_current = current_error[:, :, None, :].expand(-1, -1, group_count, -1)
    expanded_standard = standard_error[:, :, None, :].expand(-1, -1, group_count, -1)
    expanded_alternate = alternate_error[:, :, None, :].expand(-1, -1, group_count, -1)
    current = torch.gather(expanded_current, 3, row_index)
    standard = torch.gather(expanded_standard, 3, row_index)
    alternate = torch.gather(expanded_alternate, 3, row_index)
    rank = int(factor.shape[1])
    factor_index = groups[:, None, :, :].expand(-1, rank, -1, -1)
    factor_columns = torch.gather(factor[:, :, None, :].expand(-1, -1, group_count, -1), 3, factor_index).permute(0, 2, 1, 3)
    factor_gram = torch.einsum('hgrc,hgrd->hgcd', factor_columns, factor_columns)
    gradient = torch.einsum('hnr,hgrc->hngc', projected, factor_columns) + torch.einsum('hngc,hgcd->hngd', standard - current, factor_gram)
    difference = alternate - standard
    weights = pattern_bits.to(torch.float32)
    weighted_difference = weights[:, None, None, None, :] * difference[None, :, :, :, :]
    diagonal_columns = torch.gather(diagonal, 1, groups.reshape(head_count, -1)).reshape(head_count, group_count, group_size)
    diagonal_delta = (alternate.square() - standard.square()) * diagonal_columns[:, None, :, :]
    candidate_cost = 2.0 * torch.einsum('phngc,hngc->phng', weighted_difference, gradient) + torch.einsum('phngc,hgcd,phngd->phng', weighted_difference, factor_gram, weighted_difference) + torch.einsum('pc,hngc->phng', weights, diagonal_delta)
    current_difference = current - standard
    current_cost = 2.0 * (current_difference * gradient).sum(dim=-1) + torch.einsum('hngc,hgcd,hngd->hng', current_difference, factor_gram, current_difference) + ((current.square() - standard.square()) * diagonal_columns[:, None, :, :]).sum(dim=-1)
    gain = (current_cost - candidate_cost.min(dim=0).values).sum(dim=1)
    selected = gain.topk(min(int(selected_count), group_count), dim=1, largest=True, sorted=True).indices
    return torch.gather(groups, 1, selected[:, :, None].expand(-1, -1, group_size))

def _joint_low_rank_round_batched(target, step, factor, diagonal, groups, sweeps, second_sweep_groups=0, dynamic_second=False):
    standard_code, alternate_code = _adjacent_codes(target, step)
    standard_error = target - standard_code.to(torch.float32) * step
    alternate_error = target - alternate_code.to(torch.float32) * step
    current_error = standard_error.clone()
    current_code = standard_code.clone()
    projected = torch.einsum('gnc,grc->gnr', current_error, factor)
    group_count, rows, _ = current_error.shape
    rank = int(factor.shape[1])
    schwarz_group = int(groups.shape[2])
    pattern_bits = _JOINT_PATTERN_BITS_2 if schwarz_group == 2 else _JOINT_PATTERN_BITS_3 if schwarz_group == 3 else _JOINT_PATTERN_BITS_4
    pattern_weights = pattern_bits.to(torch.float32)
    for sweep_index in range(int(sweeps)):
        sweep_group_columns = groups
        sweep_groups = int(sweep_group_columns.shape[1])
        if sweep_index > 0 and int(second_sweep_groups) > 0:
            sweep_groups = min(sweep_groups, int(second_sweep_groups))
            if int(dynamic_second) == 1:
                sweep_group_columns = _joint_choose_second_groups(current_error, standard_error, alternate_error, projected, factor, diagonal, groups, sweep_groups, pattern_bits)
            elif int(dynamic_second) == 2:
                sweep_group_columns = _joint_choose_second_groups_single(current_error, current_code, standard_error, alternate_error, standard_code, projected, factor, diagonal, groups, sweep_groups)
        for group_index in range(sweep_groups):
            columns = sweep_group_columns[:, group_index, :]
            row_index = columns[:, None, :].expand(-1, rows, -1)
            rank_index = columns[:, None, :].expand(-1, rank, -1)
            old_error = torch.gather(current_error, 2, row_index)
            factor_columns = torch.gather(factor, 2, rank_index)
            old_projected = torch.einsum('gnc,grc->gnr', old_error, factor_columns)
            outside = projected - old_projected
            standard = torch.gather(standard_error, 2, row_index)
            alternate = torch.gather(alternate_error, 2, row_index)
            difference = alternate - standard
            pattern_weights = pattern_bits.to(torch.float32)
            weighted_difference = pattern_weights[:, None, None, :] * difference[None, :, :, :]
            base_projection = outside + torch.einsum('gnc,grc->gnr', standard, factor_columns)
            projected_gradient = torch.einsum('gnr,grc->gnc', base_projection, factor_columns)
            factor_gram = torch.einsum('grc,grd->gcd', factor_columns, factor_columns)
            diagonal_columns = torch.gather(diagonal, 1, columns)
            diagonal_delta = (alternate.square() - standard.square()) * diagonal_columns[:, None, :]
            costs = 2.0 * torch.einsum('pgnc,gnc->pgn', weighted_difference, projected_gradient) + torch.einsum('pgnc,gcd,pgnd->pgn', weighted_difference, factor_gram, weighted_difference) + torch.einsum('pc,gnc->pgn', pattern_weights, diagonal_delta)
            best = costs.argmin(dim=0)
            chosen_bits = pattern_bits.index_select(0, best.reshape(-1)).reshape(group_count, rows, schwarz_group)
            new_error = torch.where(chosen_bits, alternate, standard)
            standard_codes = torch.gather(standard_code, 2, row_index)
            alternate_codes = torch.gather(alternate_code, 2, row_index)
            new_code = torch.where(chosen_bits, alternate_codes, standard_codes)
            current_error.scatter_(2, row_index, new_error)
            current_code.scatter_(2, row_index, new_code)
            projected = outside + torch.einsum('gnc,grc->gnr', new_error, factor_columns)
    return current_code

def _quantize_low_rank(tensor, num_heads, head_dim, state):
    params = _quantize_attention_hierarchy_grid(tensor, num_heads, head_dim, state)
    step = _grid_step(params, tuple((int(value) for value in tensor.shape)))
    heads = tensor.to(torch.float32).reshape(-1, int(num_heads), int(head_dim))
    step_heads = step.reshape_as(heads)
    kv_num_heads = int(state['kv_num_heads'])
    group_size = int(num_heads) // kv_num_heads
    grouped_target = heads.reshape(-1, kv_num_heads, group_size, int(head_dim)).permute(1, 0, 2, 3).reshape(kv_num_heads, -1, int(head_dim))
    grouped_step = step_heads.reshape(-1, kv_num_heads, group_size, int(head_dim)).permute(1, 0, 2, 3).reshape(kv_num_heads, -1, int(head_dim))
    factors, diagonals, _, groups = _joint_select_terms(state, int(tensor.shape[0]))
    codes = _joint_low_rank_round_batched(grouped_target, grouped_step, factors, diagonals, groups, int(state['attention_hessian_schwarz_sweeps']), int(state.get('joint_second_sweep_groups', 0)), int(state.get('joint_dynamic_second', 0)))
    codes = codes.reshape(kv_num_heads, -1, group_size, int(head_dim)).permute(1, 0, 2, 3).reshape_as(heads)
    return _pack_signed_codes(params, codes.reshape(tensor.shape))
_kshrink_vdc_parent_calibration_attention = hif4_calibration_attention

def _kshrink_vdc_scale_hessian(state, factor_scale):
    for factor_key, diagonal_key in (('attention_hessian_factor', 'attention_hessian_diagonal'), ('attention_unrotated_hessian_factor', 'attention_unrotated_hessian_diagonal')):
        factor = state[factor_key].to(torch.float32)
        diagonal = state[diagonal_key].to(torch.float32)
        exact_diagonal = factor.square().sum(dim=1) + diagonal
        scaled_factor = factor * float(factor_scale)
        scaled_diagonal = (exact_diagonal - scaled_factor.square().sum(dim=1)).clamp_min(exact_diagonal.mean(dim=1, keepdim=True) * 1e-05)
        state[factor_key] = scaled_factor.contiguous()
        state[diagonal_key] = scaled_diagonal.contiguous()

def hif4_calibration_attention(calib_qkv_list, q_num_heads, kv_num_heads, head_dim):
    result = _kshrink_vdc_parent_calibration_attention(calib_qkv_list, q_num_heads, kv_num_heads, head_dim)
    _kshrink_vdc_scale_hessian(result['k_state'], 0.8125)
    return result

def _focus_proposal8_codes(target, final_step):
    group_count, rows, channels = target.shape
    if channels % 8:
        return torch.round(target / final_step.clamp_min(1e-30)).clamp(-7.0, 7.0).to(torch.int8)
    proposal_target = target.reshape(group_count, rows, channels // 8, 8)
    proposal_step = (proposal_target.abs().amax(dim=-1, keepdim=True) / 7.0).clamp_min(HIF4_MIN_SCALE)
    proposal_value = (torch.round(proposal_target / proposal_step).clamp(-7.0, 7.0) * proposal_step).reshape_as(target)
    return torch.round(proposal_value / final_step.clamp_min(1e-30)).clamp(-7.0, 7.0).to(torch.int8)

def _focus_low_rank_round_batched(target, step, factor, diagonal, groups, sweeps, proposal_code, proposal_group_count):
    standard_code, alternate_code = _adjacent_codes(target, step)
    standard_error = target - standard_code.to(torch.float32) * step
    alternate_error = target - alternate_code.to(torch.float32) * step
    proposal_error = target - proposal_code.to(torch.float32) * step
    current_error = standard_error.clone()
    current_code = standard_code.clone()
    projected = torch.einsum('gnc,grc->gnr', current_error, factor)
    head_count, rows, _ = current_error.shape
    rank = int(factor.shape[1])
    schwarz_group = int(groups.shape[2])
    pattern_bits = _JOINT_PATTERN_BITS_2 if schwarz_group == 2 else _JOINT_PATTERN_BITS_3 if schwarz_group == 3 else _JOINT_PATTERN_BITS_4
    pattern_weights = pattern_bits.to(torch.float32)
    pattern_count = int(pattern_bits.shape[0])
    for _ in range(int(sweeps)):
        for group_index in range(int(groups.shape[1])):
            columns = groups[:, group_index, :]
            row_index = columns[:, None, :].expand(-1, rows, -1)
            rank_index = columns[:, None, :].expand(-1, rank, -1)
            old_error = torch.gather(current_error, 2, row_index)
            factor_columns = torch.gather(factor, 2, rank_index)
            outside = projected - torch.einsum('gnc,grc->gnr', old_error, factor_columns)
            standard = torch.gather(standard_error, 2, row_index)
            alternate = torch.gather(alternate_error, 2, row_index)
            difference = alternate - standard
            weighted_difference = pattern_weights[:, None, None, :] * difference[None, :, :, :]
            base_projection = outside + torch.einsum('gnc,grc->gnr', standard, factor_columns)
            projected_gradient = torch.einsum('gnr,grc->gnc', base_projection, factor_columns)
            factor_gram = torch.einsum('grc,grd->gcd', factor_columns, factor_columns)
            diagonal_columns = torch.gather(diagonal, 1, columns)
            diagonal_delta = (alternate.square() - standard.square()) * diagonal_columns[:, None, :]
            costs = 2.0 * torch.einsum('pgnc,gnc->pgn', weighted_difference, projected_gradient) + torch.einsum('pgnc,gcd,pgnd->pgn', weighted_difference, factor_gram, weighted_difference) + torch.einsum('pc,gnc->pgn', pattern_weights, diagonal_delta)
            use_proposal = group_index < int(proposal_group_count)
            if use_proposal:
                proposal = torch.gather(proposal_error, 2, row_index)
                proposal_difference = proposal - standard
                proposal_cost = 2.0 * (proposal_difference * projected_gradient).sum(dim=-1) + torch.einsum('gnc,gcd,gnd->gn', proposal_difference, factor_gram, proposal_difference) + ((proposal.square() - standard.square()) * diagonal_columns[:, None, :]).sum(dim=-1)
                costs = torch.cat((costs, proposal_cost[None, :, :]), dim=0)
            best = costs.argmin(dim=0)
            binary_best = best.clamp_max(pattern_count - 1)
            chosen_bits = pattern_bits.index_select(0, binary_best.reshape(-1)).reshape(head_count, rows, schwarz_group)
            new_error = torch.where(chosen_bits, alternate, standard)
            standard_codes = torch.gather(standard_code, 2, row_index)
            alternate_codes = torch.gather(alternate_code, 2, row_index)
            new_code = torch.where(chosen_bits, alternate_codes, standard_codes)
            if use_proposal:
                choose_proposal = best.eq(pattern_count)[:, :, None]
                proposal_codes = torch.gather(proposal_code, 2, row_index)
                new_error = torch.where(choose_proposal, proposal, new_error)
                new_code = torch.where(choose_proposal, proposal_codes, new_code)
            current_error.scatter_(2, row_index, new_error)
            current_code.scatter_(2, row_index, new_code)
            projected = outside + torch.einsum('gnc,grc->gnr', new_error, factor_columns)
    return current_code

def _quantize_low_rank(tensor, num_heads, head_dim, state):
    params = _quantize_attention_hierarchy_grid(tensor, num_heads, head_dim, state)
    step = _grid_step(params, tuple((int(value) for value in tensor.shape)))
    heads = tensor.to(torch.float32).reshape(-1, int(num_heads), int(head_dim))
    step_heads = step.reshape_as(heads)
    kv_num_heads = int(state['kv_num_heads'])
    q_per_kv = int(num_heads) // kv_num_heads
    grouped_target = heads.reshape(-1, kv_num_heads, q_per_kv, int(head_dim)).permute(1, 0, 2, 3).reshape(kv_num_heads, -1, int(head_dim))
    grouped_step = step_heads.reshape(-1, kv_num_heads, q_per_kv, int(head_dim)).permute(1, 0, 2, 3).reshape(kv_num_heads, -1, int(head_dim))
    factors, diagonals, _, groups = _joint_select_terms(state, int(tensor.shape[0]))
    proposal_groups = 4 if int(tensor.shape[0]) >= 512 and q_per_kv == 1 else 0
    if proposal_groups <= 0:
        codes = _joint_low_rank_round_batched(grouped_target, grouped_step, factors, diagonals, groups, int(state['attention_hessian_schwarz_sweeps']), int(state.get('joint_second_sweep_groups', 0)), int(state.get('joint_dynamic_second', 0)))
    else:
        proposal_code = _focus_proposal8_codes(grouped_target, grouped_step)
        codes = _focus_low_rank_round_batched(grouped_target, grouped_step, factors, diagonals, groups, int(state['attention_hessian_schwarz_sweeps']), proposal_code, proposal_groups)
    codes = codes.reshape(kv_num_heads, -1, q_per_kv, int(head_dim)).permute(1, 0, 2, 3).reshape_as(heads)
    return _pack_signed_codes(params, codes.reshape(tensor.shape))
_vh_parent_calibration_attention = hif4_calibration_attention
_vh_parent_dynamic_v = hif4_dynamic_quantize_v
_VH_MIN_ROWS = 512
_VH_QUERY_ROWS = 8
_VH_RANK = 8
_VH_MAX_TOKENS = 8
_VH_STABILITY_MIN = 0.25

def _vh_query_indices(rows):
    if int(rows) <= int(_VH_QUERY_ROWS):
        return torch.arange(int(rows), dtype=torch.long)
    return torch.linspace(0, int(rows) - 1, int(_VH_QUERY_ROWS)).round().to(torch.long)

def _vh_probabilities(q, k, q_num_heads, kv_num_heads, head_dim):
    query_indices = _vh_query_indices(int(q.shape[0]))
    qh = q.index_select(0, query_indices).reshape(-1, int(q_num_heads), int(head_dim)).permute(1, 0, 2)
    kh = k.reshape(-1, int(kv_num_heads), int(head_dim)).permute(1, 0, 2)
    q_per_kv = int(q_num_heads) // int(kv_num_heads)
    result = []
    for kv_head in range(int(kv_num_heads)):
        q_group = qh[kv_head * q_per_kv:(kv_head + 1) * q_per_kv]
        result.append(torch.softmax(torch.matmul(q_group, kh[kv_head].T) / math.sqrt(float(head_dim)), dim=-1).reshape(-1, int(k.shape[0])).contiguous())
    return result

def _vh_stable_factor(folds):
    rows = int(folds[0].shape[1])
    dc = torch.full((1, rows), 1.0 / float(rows), dtype=torch.float32)
    centered = [fold - 1.0 / float(rows) for fold in folds]
    total_observations = sum((int(fold.shape[0]) for fold in centered))
    stacked = torch.cat(centered, dim=0) / math.sqrt(float(max(total_observations, 1)))
    if len(folds) < 2 or int(stacked.shape[0]) == 0:
        factor = dc
        stability = torch.empty(0, dtype=torch.float32)
    else:
        _, singular, vectors = torch.linalg.svd(stacked, full_matrices=False)
        candidate_count = min(int(_VH_RANK) - 1, int(vectors.shape[0]))
        vectors = vectors[:candidate_count]
        singular = singular[:candidate_count]
        fold_energy = torch.stack([(fold_centered @ vectors.T).square().mean(dim=0) for fold_centered in centered], dim=0)
        stability = fold_energy.amin(dim=0) / fold_energy.mean(dim=0).clamp_min(1e-30)
        keep = stability >= float(_VH_STABILITY_MIN)
        residual_factor = singular[keep, None] * vectors[keep]
        factor = torch.cat((dc, residual_factor), dim=0)
    exact_diagonal = torch.cat(folds, dim=0).square().mean(dim=0)
    diagonal = (exact_diagonal - factor.square().sum(dim=0)).clamp_min(exact_diagonal.mean().clamp_min(1e-30) * 1e-06)
    return (factor.contiguous(), diagonal.contiguous(), stability)

def _vh_build_states(calib_qkv_list, q_num_heads, kv_num_heads, head_dim):
    buckets = {}
    eligible_counts = {}
    for sample in calib_qkv_list:
        rows = int(sample['k'][0].shape[0])
        if rows >= int(_VH_MIN_ROWS):
            eligible_counts[rows] = eligible_counts.get(rows, 0) + 1
    for sample in calib_qkv_list:
        rows = int(sample['k'][0].shape[0])
        if rows < int(_VH_MIN_ROWS) or int(eligible_counts.get(rows, 0)) < 2:
            continue
        q = dequantize_nvfp4(*sample['q']).to(torch.float32)
        k = dequantize_nvfp4(*sample['k']).to(torch.float32)
        probabilities = _vh_probabilities(q, k, q_num_heads, kv_num_heads, head_dim)
        bucket = buckets.setdefault(rows, [[] for _ in range(int(kv_num_heads))])
        for kv_head in range(int(kv_num_heads)):
            bucket[kv_head].append(probabilities[kv_head])
    states = []
    for rows in sorted(buckets):
        factors = []
        diagonals = []
        stable_counts = []
        for kv_head in range(int(kv_num_heads)):
            factor, diagonal, stability = _vh_stable_factor(buckets[rows][kv_head])
            factors.append(factor)
            diagonals.append(diagonal)
            stable_counts.append(int(factor.shape[0]) - 1)
        if max(stable_counts) <= 0:
            continue
        max_rank = max((int(value.shape[0]) for value in factors))
        padded = []
        for value in factors:
            if int(value.shape[0]) < max_rank:
                value = torch.cat((value, torch.zeros((max_rank - int(value.shape[0]), int(rows)), dtype=torch.float32)), dim=0)
            padded.append(value)
        states.append({'sequence_length': int(rows), 'factor': torch.stack(padded, dim=0).contiguous(), 'diagonal': torch.stack(diagonals, dim=0).contiguous(), 'stable_mode_counts': tuple(stable_counts)})
    return states

def hif4_calibration_attention(calib_qkv_list, q_num_heads, kv_num_heads, head_dim):
    result = _vh_parent_calibration_attention(calib_qkv_list, q_num_heads, kv_num_heads, head_dim)
    v_state = dict(result['v_state'])
    v_state.update({'v_hessian_mode': 'role-local-stable-ptp-r8-diag-scale-code', 'v_hessian_query_rows': int(_VH_QUERY_ROWS), 'v_hessian_rank_max': int(_VH_RANK), 'v_hessian_max_tokens': int(_VH_MAX_TOKENS), 'v_hessian_length_states': _vh_build_states(calib_qkv_list, q_num_heads, kv_num_heads, head_dim)})
    result['v_state'] = v_state
    return result

def _vh_select_state(state, rows):
    if not isinstance(state, dict):
        return None
    for candidate in state.get('v_hessian_length_states', ()):
        if int(candidate['sequence_length']) == int(rows):
            return candidate
    return None

def _vh_candidate_values(sf, lv2_exp, lv3_exp, mantissa, sign):
    exponent = lv2_exp.repeat_interleave(8, dim=1) + lv3_exp.repeat_interleave(4, dim=1)
    return sign * mantissa.to(torch.float32) * 0.25 * sf[:, None] * torch.pow(2.0, exponent.to(torch.float32))

def _vh_polish_head(params, target, current, factor, diagonal, kv_head, head_dim):
    rows = int(target.shape[0])
    blocks_per_head = int(head_dim) // 64
    first_block = int(kv_head) * blocks_per_head
    error = (target - current).T.contiguous()
    projected = error @ factor.T
    importance = factor.square().sum(dim=0) + diagonal
    token_count = min(int(_VH_MAX_TOKENS), rows)
    tokens = importance.topk(token_count, largest=True, sorted=True).indices
    token_order = tokens.to(device='cpu').tolist()
    proposal_blocks = target.index_select(0, tokens).reshape(-1, 64)
    sf, lv2_exp, lv3_exp, mantissa, sign = _encode_blocks(proposal_blocks)
    proposal_values = _vh_candidate_values(sf, lv2_exp, lv3_exp, mantissa, sign).reshape(token_count, blocks_per_head, 64)
    sf = sf.reshape(token_count, blocks_per_head)
    lv2_exp = lv2_exp.reshape(token_count, blocks_per_head, 8)
    lv3_exp = lv3_exp.reshape(token_count, blocks_per_head, 16)
    mantissa = mantissa.reshape(token_count, blocks_per_head, 8, 2, 4)
    sign = sign.reshape(token_count, blocks_per_head, 8, 2, 4)
    sf_view = params['scale_factor'].reshape(rows, -1)
    lv2_view = params['scale_lv2'].reshape(rows, -1, 8)
    lv3_view = params['scale_lv3'].reshape(rows, -1, 16)
    sign_view = params['sign'].reshape(rows, -1, 8, 2, 4)
    mant_view = params['mant'].reshape(rows, -1, 8, 2, 4)
    block_indices = torch.arange(first_block, first_block + blocks_per_head, dtype=torch.long)
    for order, token in enumerate(token_order):
        candidate = proposal_values[order].reshape(int(head_dim))
        old_error = error[:, token]
        candidate_error = target[token] - candidate
        delta = candidate_error - old_error
        gradient = projected @ factor[:, token] + old_error * diagonal[token]
        hessian_diagonal = importance[token]
        block_cost = (2.0 * delta * gradient + hessian_diagonal * delta.square()).reshape(blocks_per_head, 64).sum(dim=1)
        accepted = block_cost < -1e-12
        accepted_delta = torch.where(accepted[:, None], delta.reshape(blocks_per_head, 64), 0.0).reshape(int(head_dim))
        error[:, token] += accepted_delta
        projected += accepted_delta[:, None] * factor[:, token][None, :]
        chosen = block_indices[accepted]
        sf_view[token, chosen] = sf[order, accepted].to(sf_view.dtype)
        lv2_view[token, chosen] = torch.pow(2.0, lv2_exp[order, accepted].to(torch.float32)).to(lv2_view.dtype)
        lv3_view[token, chosen] = torch.pow(2.0, lv3_exp[order, accepted].to(torch.float32)).to(lv3_view.dtype)
        sign_view[token, chosen] = sign[order, accepted].to(sign_view.dtype)
        mant_view[token, chosen] = (mantissa[order, accepted].to(torch.float32) * 0.25).to(mant_view.dtype)

def hif4_dynamic_quantize_v(v_quant, v_scale, kv_num_heads, head_dim, v_state):
    params = _vh_parent_dynamic_v(v_quant, v_scale, kv_num_heads, head_dim, v_state)
    rows = int(v_quant.shape[0])
    selected = _vh_select_state(v_state, rows)
    if selected is None:
        return params
    target = dequantize_nvfp4(v_quant, v_scale).to(torch.float32).contiguous()
    current = dequantize_hif4(params).to(torch.float32).reshape_as(target)
    target_heads = target.reshape(rows, int(kv_num_heads), int(head_dim))
    current_heads = current.reshape_as(target_heads)
    factors = selected['factor'].to(torch.float32)
    diagonals = selected['diagonal'].to(torch.float32)
    result = {key: value.clone() for key, value in params.items()}
    for kv_head in range(int(kv_num_heads)):
        _vh_polish_head(result, target_heads[:, kv_head, :], current_heads[:, kv_head, :], factors[kv_head], diagonals[kv_head], kv_head, head_dim)
    return result
ATTENTION_HESSIAN_RANK = 64
ATTENTION_HESSIAN_SCHWARZ_GROUP = 8
_JOINT_LONG_SWEEPS = 1
_QSG_Q_COLUMNS = 120
_QSG_K_COLUMNS = 152
_QSG_GROUP = 8
_QSG_MAX_TOGGLES = 2
_qsg_all_bits = (torch.arange(1 << int(_QSG_GROUP), dtype=torch.long)[:, None] >> torch.arange(int(_QSG_GROUP), dtype=torch.long)[None, :] & 1).to(torch.bool)
_JOINT_PATTERN_BITS_4 = _qsg_all_bits[_qsg_all_bits.sum(dim=1) <= int(_QSG_MAX_TOGGLES)].contiguous()
_QSG_PARENT_CALIBRATION = hif4_calibration_attention

def hif4_calibration_attention(calib_qkv_list, q_num_heads, kv_num_heads, head_dim):
    result = _QSG_PARENT_CALIBRATION(calib_qkv_list, q_num_heads, kv_num_heads, head_dim)
    for state, columns in ((result['q_state'], int(_QSG_Q_COLUMNS)), (result['k_state'], int(_QSG_K_COLUMNS))):
        state['attention_hessian_schwarz_group'] = int(_QSG_GROUP)
        state['attention_hessian_max_columns'] = int(columns)
        state['joint_second_sweep_groups'] = 0
        state['joint_dynamic_second'] = 0
        _joint_prepare_attention_state(state)
    return result
_VSR_PARENT_DYNAMIC_V = hif4_dynamic_quantize_v
_VSR_MULTIPLIERS = (0.5, 0.625, 0.75, 1.0, 1.125, 1.25, 1.375, 1.5, 1.625)
_VSR_WINDOW = 40
_VSR_MODES = 6
_VSR_STEPS = 4
_VSR_POSITION = 1.0

def hif4_dynamic_quantize_v(v_quant, v_scale, kv_num_heads, head_dim, v_state):
    state = dict(v_state) if isinstance(v_state, dict) else {}
    state['v_output_shape_min_rows'] = 512
    state['v_output_shape_search_multipliers'] = _VSR_MULTIPLIERS
    state['v_output_shape_window'] = int(_VSR_WINDOW)
    state['v_output_shape_mode_count'] = int(_VSR_MODES)
    state['v_output_shape_max_steps'] = int(_VSR_STEPS)
    state['v_output_shape_position_weight_strength'] = float(_VSR_POSITION)
    return _VSR_PARENT_DYNAMIC_V(v_quant, v_scale, kv_num_heads, head_dim, state)
_SH2_LEFT = torch.tensor([left for left in range(8) for right in range(left + 1, 8)], dtype=torch.long)
_SH2_RIGHT = torch.tensor([right for left in range(8) for right in range(left + 1, 8)], dtype=torch.long)
_sh2_canonical_codes = torch.tensor([0] + [1 << index for index in range(8)] + [1 << left | 1 << right for left in range(8) for right in range(left + 1, 8)], dtype=torch.long)
_sh2_pattern_codes = (_JOINT_PATTERN_BITS_4.to(torch.long) * (1 << torch.arange(8, dtype=torch.long))[None, :]).sum(dim=1)
_SH2_PATTERN_ORDER = (_sh2_pattern_codes[:, None] == _sh2_canonical_codes[None, :]).to(torch.long).argmax(dim=1)

def _sparse_hamming2_costs(difference, projected_gradient, factor_gram, diagonal_delta):
    factor_diagonal = torch.diagonal(factor_gram, dim1=1, dim2=2)
    coordinate_cost = 2.0 * difference * projected_gradient + difference.square() * factor_diagonal[:, None, :] + diagonal_delta
    left_difference = difference.index_select(2, _SH2_LEFT)
    right_difference = difference.index_select(2, _SH2_RIGHT)
    cross = 2.0 * left_difference * right_difference * factor_gram[:, _SH2_LEFT, _SH2_RIGHT][:, None, :]
    pair_cost = coordinate_cost.index_select(2, _SH2_LEFT) + coordinate_cost.index_select(2, _SH2_RIGHT) + cross
    packed = torch.cat((torch.zeros((1, int(difference.shape[0]), int(difference.shape[1])), dtype=difference.dtype), coordinate_cost.permute(2, 0, 1), pair_cost.permute(2, 0, 1)), dim=0)
    return packed.index_select(0, _SH2_PATTERN_ORDER)

def _joint_low_rank_round_batched(target, step, factor, diagonal, groups, sweeps, second_sweep_groups=0, dynamic_second=False, initial_projected=None):
    standard_code, alternate_code = _adjacent_codes(target, step)
    standard_error = target - standard_code.to(torch.float32) * step
    alternate_error = target - alternate_code.to(torch.float32) * step
    current_error = None if int(sweeps) == 1 else standard_error.clone()
    current_code = standard_code.clone()
    projected = initial_projected if initial_projected is not None else torch.einsum('gnc,grc->gnr', standard_error, factor)
    group_count, rows, _ = standard_error.shape
    rank = int(factor.shape[1])
    schwarz_group = int(groups.shape[2])
    pattern_bits = _JOINT_PATTERN_BITS_2 if schwarz_group == 2 else _JOINT_PATTERN_BITS_3 if schwarz_group == 3 else _JOINT_PATTERN_BITS_4
    if int(sweeps) == 1:
        # The one-sweep path visits disjoint columns exactly once. Gather all
        # invariant group data in bulk, precompute every small Gram matrix, and
        # scatter the resulting codes once after the Gauss-Seidel updates.
        sweep_groups = int(groups.shape[1])
        flat_columns = groups.reshape(group_count, -1)
        flat_width = int(flat_columns.shape[1])
        data_index = flat_columns[:, None, :].expand(group_count, rows, flat_width)
        standard_all = torch.gather(standard_error, 2, data_index).reshape(group_count, rows, sweep_groups, schwarz_group).permute(0, 2, 1, 3).contiguous()
        alternate_all = torch.gather(alternate_error, 2, data_index).reshape(group_count, rows, sweep_groups, schwarz_group).permute(0, 2, 1, 3).contiguous()
        standard_code_all = torch.gather(standard_code, 2, data_index).reshape(group_count, rows, sweep_groups, schwarz_group).permute(0, 2, 1, 3).contiguous()
        alternate_code_all = torch.gather(alternate_code, 2, data_index).reshape(group_count, rows, sweep_groups, schwarz_group).permute(0, 2, 1, 3).contiguous()
        factor_index = flat_columns[:, None, :].expand(group_count, rank, flat_width)
        factor_all = torch.gather(factor, 2, factor_index).reshape(group_count, rank, sweep_groups, schwarz_group).permute(0, 2, 1, 3).contiguous()
        factor_gram_all = torch.einsum('hgrc,hgrd->hgcd', factor_all, factor_all)
        diagonal_all = torch.gather(diagonal, 1, flat_columns).reshape(group_count, sweep_groups, schwarz_group)
        code_updates = []
        for group_index in range(sweep_groups):
            standard = standard_all[:, group_index]
            alternate = alternate_all[:, group_index]
            difference = alternate - standard
            factor_columns = factor_all[:, group_index]
            projected_gradient = torch.einsum('gnr,grc->gnc', projected, factor_columns)
            factor_gram = factor_gram_all[:, group_index]
            diagonal_columns = diagonal_all[:, group_index]
            diagonal_delta = (alternate.square() - standard.square()) * diagonal_columns[:, None, :]
            costs = _sparse_hamming2_costs(difference, projected_gradient, factor_gram, diagonal_delta)
            best = costs.argmin(dim=0)
            chosen_bits = pattern_bits.index_select(0, best.reshape(-1)).reshape(group_count, rows, schwarz_group)
            new_error = torch.where(chosen_bits, alternate, standard)
            new_code = torch.where(chosen_bits, alternate_code_all[:, group_index], standard_code_all[:, group_index])
            code_updates.append(new_code)
            projected.add_(torch.einsum('gnc,grc->gnr', new_error - standard, factor_columns))
        packed_codes = torch.stack(code_updates, dim=1).permute(0, 2, 1, 3).reshape(group_count, rows, flat_width)
        current_code.scatter_(2, data_index, packed_codes)
        return current_code
    for sweep_index in range(int(sweeps)):
        sweep_group_columns = groups
        sweep_groups = int(sweep_group_columns.shape[1])
        if sweep_index > 0 and int(second_sweep_groups) > 0:
            sweep_groups = min(sweep_groups, int(second_sweep_groups))
            if int(dynamic_second) == 1:
                sweep_group_columns = _joint_choose_second_groups(current_error, standard_error, alternate_error, projected, factor, diagonal, groups, sweep_groups, pattern_bits)
            elif int(dynamic_second) == 2:
                sweep_group_columns = _joint_choose_second_groups_single(current_error, current_code, standard_error, alternate_error, standard_code, projected, factor, diagonal, groups, sweep_groups)
        for group_index in range(sweep_groups):
            columns = sweep_group_columns[:, group_index, :]
            row_index = columns[:, None, :].expand(-1, rows, -1)
            rank_index = columns[:, None, :].expand(-1, rank, -1)
            factor_columns = torch.gather(factor, 2, rank_index)
            standard = torch.gather(standard_error, 2, row_index)
            alternate = torch.gather(alternate_error, 2, row_index)
            difference = alternate - standard
            if sweep_index == 0:
                # Groups contain disjoint columns, so their first-visit error is
                # still `standard`.  The old code subtracted and immediately
                # re-added the same projection before computing this gradient.
                base_projection = projected
            else:
                old_error = torch.gather(current_error, 2, row_index)
                old_projected = torch.einsum('gnc,grc->gnr', old_error, factor_columns)
                outside = projected - old_projected
                base_projection = outside + torch.einsum('gnc,grc->gnr', standard, factor_columns)
            projected_gradient = torch.einsum('gnr,grc->gnc', base_projection, factor_columns)
            factor_gram = torch.einsum('grc,grd->gcd', factor_columns, factor_columns)
            diagonal_columns = torch.gather(diagonal, 1, columns)
            diagonal_delta = (alternate.square() - standard.square()) * diagonal_columns[:, None, :]
            costs = _sparse_hamming2_costs(difference, projected_gradient, factor_gram, diagonal_delta)
            best = costs.argmin(dim=0)
            chosen_bits = pattern_bits.index_select(0, best.reshape(-1)).reshape(group_count, rows, schwarz_group)
            new_error = torch.where(chosen_bits, alternate, standard)
            standard_codes = torch.gather(standard_code, 2, row_index)
            alternate_codes = torch.gather(alternate_code, 2, row_index)
            new_code = torch.where(chosen_bits, alternate_codes, standard_codes)
            current_error.scatter_(2, row_index, new_error)
            current_code.scatter_(2, row_index, new_code)
            if sweep_index == 0:
                projected = projected + torch.einsum('gnc,grc->gnr', new_error - standard, factor_columns)
            else:
                projected = outside + torch.einsum('gnc,grc->gnr', new_error, factor_columns)
    return current_code

def _focus_low_rank_round_batched(target, step, factor, diagonal, groups, sweeps, proposal_code, proposal_group_count):
    standard_code, alternate_code = _adjacent_codes(target, step)
    standard_error = target - standard_code.to(torch.float32) * step
    alternate_error = target - alternate_code.to(torch.float32) * step
    proposal_error = target - proposal_code.to(torch.float32) * step
    current_error = standard_error.clone()
    current_code = standard_code.clone()
    projected = torch.einsum('gnc,grc->gnr', current_error, factor)
    head_count, rows, _ = current_error.shape
    rank = int(factor.shape[1])
    schwarz_group = int(groups.shape[2])
    pattern_bits = _JOINT_PATTERN_BITS_2 if schwarz_group == 2 else _JOINT_PATTERN_BITS_3 if schwarz_group == 3 else _JOINT_PATTERN_BITS_4
    pattern_weights = pattern_bits.to(torch.float32)
    pattern_count = int(pattern_bits.shape[0])
    for _ in range(int(sweeps)):
        for group_index in range(int(groups.shape[1])):
            columns = groups[:, group_index, :]
            row_index = columns[:, None, :].expand(-1, rows, -1)
            rank_index = columns[:, None, :].expand(-1, rank, -1)
            old_error = torch.gather(current_error, 2, row_index)
            factor_columns = torch.gather(factor, 2, rank_index)
            outside = projected - torch.einsum('gnc,grc->gnr', old_error, factor_columns)
            standard = torch.gather(standard_error, 2, row_index)
            alternate = torch.gather(alternate_error, 2, row_index)
            difference = alternate - standard
            base_projection = outside + torch.einsum('gnc,grc->gnr', standard, factor_columns)
            projected_gradient = torch.einsum('gnr,grc->gnc', base_projection, factor_columns)
            factor_gram = torch.einsum('grc,grd->gcd', factor_columns, factor_columns)
            diagonal_columns = torch.gather(diagonal, 1, columns)
            diagonal_delta = (alternate.square() - standard.square()) * diagonal_columns[:, None, :]
            costs = _sparse_hamming2_costs(difference, projected_gradient, factor_gram, diagonal_delta)
            use_proposal = group_index < int(proposal_group_count)
            if use_proposal:
                proposal = torch.gather(proposal_error, 2, row_index)
                proposal_difference = proposal - standard
                proposal_cost = 2.0 * (proposal_difference * projected_gradient).sum(dim=-1) + torch.einsum('gnc,gcd,gnd->gn', proposal_difference, factor_gram, proposal_difference) + ((proposal.square() - standard.square()) * diagonal_columns[:, None, :]).sum(dim=-1)
                costs = torch.cat((costs, proposal_cost[None, :, :]), dim=0)
            best = costs.argmin(dim=0)
            binary_best = best.clamp_max(pattern_count - 1)
            chosen_bits = pattern_bits.index_select(0, binary_best.reshape(-1)).reshape(head_count, rows, schwarz_group)
            new_error = torch.where(chosen_bits, alternate, standard)
            standard_codes = torch.gather(standard_code, 2, row_index)
            alternate_codes = torch.gather(alternate_code, 2, row_index)
            new_code = torch.where(chosen_bits, alternate_codes, standard_codes)
            if use_proposal:
                choose_proposal = best.eq(pattern_count)[:, :, None]
                proposal_codes = torch.gather(proposal_code, 2, row_index)
                new_error = torch.where(choose_proposal, proposal, new_error)
                new_code = torch.where(choose_proposal, proposal_codes, new_code)
            current_error.scatter_(2, row_index, new_error)
            current_code.scatter_(2, row_index, new_code)
            projected = outside + torch.einsum('gnc,grc->gnr', new_error, factor_columns)
    return current_code
_VH_MAX_TOKENS = 16
_DFR_ONLINE_RANK = 48
_VH_MAX_TOKENS = 16

def _dfr_factors(target, step, factor, diagonal):
    standard, _ = _adjacent_codes(target, step)
    error = target - standard.to(torch.float32) * step
    projected = torch.einsum('hnc,hrc->hnr', error, factor)
    energy = projected.square().sum(dim=1)
    selected = torch.argsort(energy, dim=1, descending=True, stable=True)[:, :int(_DFR_ONLINE_RANK)]
    gather_index = selected[:, :, None].expand(-1, -1, int(factor.shape[2]))
    compressed = torch.gather(factor, 1, gather_index).contiguous()
    exact_diagonal = factor.square().sum(dim=1) + diagonal
    residual = exact_diagonal - compressed.square().sum(dim=1)
    residual = residual.clamp_min(exact_diagonal.mean(dim=1, keepdim=True).clamp_min(1e-30) * 1e-06)
    selected_projected = torch.gather(projected, 2, selected[:, None, :].expand(-1, int(projected.shape[1]), -1)).contiguous()
    return (compressed, residual.contiguous(), selected_projected)

def _quantize_low_rank(tensor, num_heads, head_dim, state):
    params = _quantize_attention_hierarchy_grid(tensor, num_heads, head_dim, state)
    step = _grid_step(params, tuple((int(value) for value in tensor.shape)))
    heads = tensor.to(torch.float32).reshape(-1, int(num_heads), int(head_dim))
    step_heads = step.reshape_as(heads)
    kv_num_heads = int(state['kv_num_heads'])
    q_per_kv = int(num_heads) // kv_num_heads
    grouped_target = heads.reshape(-1, kv_num_heads, q_per_kv, int(head_dim)).permute(1, 0, 2, 3).reshape(kv_num_heads, -1, int(head_dim))
    grouped_step = step_heads.reshape(-1, kv_num_heads, q_per_kv, int(head_dim)).permute(1, 0, 2, 3).reshape(kv_num_heads, -1, int(head_dim))
    factors, diagonals, _, groups = _joint_select_terms(state, int(tensor.shape[0]))
    is_k = 'attention_k_centering' in state
    initial_projected = None
    if not is_k:
        factors, diagonals, initial_projected = _dfr_factors(grouped_target, grouped_step, factors, diagonals)
    proposal_groups = 4 if int(tensor.shape[0]) >= 512 and q_per_kv == 1 else 0
    if proposal_groups <= 0:
        codes = _joint_low_rank_round_batched(grouped_target, grouped_step, factors, diagonals, groups, int(state['attention_hessian_schwarz_sweeps']), int(state.get('joint_second_sweep_groups', 0)), int(state.get('joint_dynamic_second', 0)), initial_projected)
    else:
        proposal_code = _focus_proposal8_codes(grouped_target, grouped_step)
        codes = _focus_low_rank_round_batched(grouped_target, grouped_step, factors, diagonals, groups, int(state['attention_hessian_schwarz_sweeps']), proposal_code, proposal_groups)
    codes = codes.reshape(kv_num_heads, -1, q_per_kv, int(head_dim)).permute(1, 0, 2, 3).reshape_as(heads)
    return _pack_signed_codes(params, codes.reshape(tensor.shape))

_QSG_Q_COLUMNS = 136
_DFR_ONLINE_RANK = 64


# Cross-interface-free K repair: calibration Q/Qhat prototypes live inside
# k_state.  Current K selects a same-length prototype using K-only statistics.
_KPR_PARENT_CAL = hif4_calibration_attention
_KPR_PARENT_K = hif4_dynamic_quantize_k
_KPR_QUERY_ROWS = 128
_KPR_GROUP_SIZE = 4
_KPR_GROUPS = 8
_KPR_TOKEN_BUDGET = 384
_KPR_DYNAMIC_SELECTION = 1
_KPR_PATTERNS = (
    torch.arange(1 << int(_KPR_GROUP_SIZE), dtype=torch.long)[:, None]
    >> torch.arange(int(_KPR_GROUP_SIZE), dtype=torch.long)[None, :]
    & 1
).to(torch.bool)

def _kpr_indices(rows, device):
    count = int(_KPR_QUERY_ROWS)
    if int(rows) == count:
        return torch.arange(int(rows), dtype=torch.long, device=device)
    return torch.linspace(0, int(rows) - 1, count, device=device).round().to(torch.long)

def _kpr_descriptor(k, kv_num_heads, head_dim):
    heads = k.to(torch.float32).reshape(-1, int(kv_num_heads), int(head_dim))
    value = heads.square().mean(dim=0).clamp_min(1e-20).log()
    value = value.reshape(int(kv_num_heads), int(head_dim) // 8, 8).mean(dim=2)
    return (value - value.mean(dim=1, keepdim=True)).contiguous()

def hif4_calibration_attention(calib_qkv_list, q_num_heads, kv_num_heads, head_dim):
    result = _KPR_PARENT_CAL(calib_qkv_list, q_num_heads, kv_num_heads, head_dim)
    references = []
    quantized = []
    descriptors = []
    lengths = []
    q_per_kv = int(q_num_heads) // int(kv_num_heads)
    for sample in calib_qkv_list:
        rows = int(sample['q'][0].shape[0])
        if rows < 128:
            continue
        indices = _kpr_indices(rows, sample['q'][0].device)
        q_reference = dequantize_nvfp4(*sample['q']).to(torch.float32)
        q_quantized = transform_attention_q_structured(q_reference, q_num_heads, head_dim, result['q_state'])
        q_quantized = apply_attention_extra_transform(q_quantized, q_num_heads, head_dim, result['q_state'])
        references.append(q_reference.reshape(rows, int(kv_num_heads), q_per_kv, int(head_dim)).index_select(0, indices).permute(1, 2, 0, 3).reshape(int(kv_num_heads), -1, int(head_dim)).to(torch.bfloat16))
        quantized.append(q_quantized.reshape(rows, int(kv_num_heads), q_per_kv, int(head_dim)).index_select(0, indices).permute(1, 2, 0, 3).reshape(int(kv_num_heads), -1, int(head_dim)).to(torch.bfloat16))
        k_reference = dequantize_nvfp4(*sample['k']).to(torch.float32)
        descriptors.append(_kpr_descriptor(k_reference, kv_num_heads, head_dim))
        lengths.append(rows)
    state = dict(result['k_state'])
    if len(references) >= 2:
        state['kpr_q_reference'] = torch.stack(references, dim=0).contiguous()
        state['kpr_q_quantized'] = torch.stack(quantized, dim=0).contiguous()
        state['kpr_k_descriptor'] = torch.stack(descriptors, dim=0).contiguous()
        state['kpr_lengths'] = torch.tensor(lengths, dtype=torch.long)
        state['kpr_q_num_heads'] = int(q_num_heads)
    result['k_state'] = state
    return result

def _kpr_repair(q_reference, q_quantized, k_reference, step, code, groups):
    head_count, rows, head_dim = k_reference.shape
    root_dim = math.sqrt(float(head_dim))
    current_code = code.to(torch.float32).clone()
    current = current_code * step
    reference_probability = torch.softmax(torch.bmm(q_reference, k_reference.transpose(1, 2)) / root_dim, dim=2)
    logits = torch.bmm(q_quantized, current.transpose(1, 2)) / root_dim
    probability = torch.softmax(logits, dim=2)
    if groups is None:
        gradient = torch.bmm((probability - reference_probability).transpose(1, 2), q_quantized) / root_dim
        hessian_diagonal = torch.bmm((probability * (1.0 - probability)).transpose(1, 2), q_quantized.square()) / float(head_dim)
        raw_jump = torch.round(-gradient / (hessian_diagonal * step).clamp_min(1e-30)).clamp(-1.0, 1.0)
        fallback = torch.where(gradient > 0.0, -torch.ones_like(raw_jump), torch.ones_like(raw_jump))
        jump = torch.where(raw_jump == 0.0, fallback, raw_jump)
        jump = torch.maximum(torch.minimum(jump, 7.0 - current_code), -7.0 - current_code)
        delta = jump * step
        gain = (-(delta * gradient + 0.5 * delta.square() * hessian_diagonal)).clamp_min(0.0).sum(dim=1)
        usable = int(_KPR_GROUP_SIZE) * int(_KPR_GROUPS)
        groups = gain.topk(usable, dim=1, largest=True, sorted=True).indices.reshape(head_count, int(_KPR_GROUPS), int(_KPR_GROUP_SIZE))
    patterns = _KPR_PATTERNS.to(device=logits.device, dtype=torch.float32)
    current_loss = -(reference_probability * torch.log_softmax(logits, dim=2)).sum(dim=(1, 2))
    for group_index in range(int(groups.shape[1])):
        columns = groups[:, group_index, :]
        q_index = columns[:, None, :].expand(head_count, int(q_quantized.shape[1]), int(_KPR_GROUP_SIZE))
        token_index = columns[:, None, :].expand(head_count, rows, int(_KPR_GROUP_SIZE))
        q_group = torch.gather(q_quantized, 2, q_index)
        group_gradient = torch.bmm((probability - reference_probability).transpose(1, 2), q_group) / root_dim
        weights = probability * (1.0 - probability)
        token_hessian = torch.einsum('hon,hoi,hoj->hnij', weights, q_group, q_group) / float(head_dim)
        group_step = torch.gather(step, 2, token_index)
        group_code = torch.gather(current_code, 2, token_index)
        token_diagonal = torch.diagonal(token_hessian, dim1=2, dim2=3)
        raw_jump = torch.round(-group_gradient / (token_diagonal * group_step).clamp_min(1e-30)).clamp(-1.0, 1.0)
        fallback = torch.where(group_gradient > 0.0, -1.0, 1.0)
        jump = torch.where(raw_jump == 0.0, fallback, raw_jump)
        jump = torch.maximum(torch.minimum(jump, 7.0 - group_code), -7.0 - group_code)
        proposal_delta = jump * group_step
        costs = _kpr_sparse_hamming2_costs(proposal_delta, group_gradient, token_hessian)
        best = costs.argmin(dim=0)
        best_cost = torch.gather(costs, 0, best[None, :, :]).squeeze(0)
        chosen = patterns.index_select(0, best.reshape(-1)).reshape(head_count, rows, int(_KPR_GROUP_SIZE)) * proposal_delta
        if int(_KPR_TOKEN_BUDGET) >= rows:
            chosen = torch.where(best_cost[:, :, None] < 0.0, chosen, 0.0)
        else:
            selected_tokens = best_cost.topk(int(_KPR_TOKEN_BUDGET), dim=1, largest=False, sorted=True).indices
            token_mask = torch.zeros((head_count, rows), dtype=torch.bool, device=chosen.device)
            token_mask.scatter_(1, selected_tokens, True)
            chosen = torch.where(token_mask[:, :, None] & (best_cost[:, :, None] < 0.0), chosen, 0.0)
        candidate_logits = logits + torch.bmm(q_group, chosen.transpose(1, 2)) / root_dim
        candidate_log_probability = torch.log_softmax(candidate_logits, dim=2)
        candidate_loss = -(reference_probability * candidate_log_probability).sum(dim=(1, 2))
        candidate_probability = candidate_log_probability.exp()
        accept = candidate_loss < current_loss
        chosen = torch.where(accept[:, None, None], chosen, torch.zeros_like(chosen))
        logits = torch.where(accept[:, None, None], candidate_logits, logits)
        current_loss = torch.where(accept, candidate_loss, current_loss)
        probability = torch.where(accept[:, None, None], candidate_probability, probability)
        new_code = torch.round(group_code + chosen / group_step.clamp_min(1e-30)).clamp(-7.0, 7.0)
        current_code.scatter_(2, token_index, new_code)
    return current_code.to(torch.int8)

def hif4_dynamic_quantize_k(k_quant, k_scale, kv_num_heads, head_dim, k_state):
    params = _KPR_PARENT_K(k_quant, k_scale, kv_num_heads, head_dim, k_state)
    rows = int(k_quant.shape[0])
    if rows < 128 or 'kpr_q_reference' not in k_state:
        return params
    k_raw = dequantize_nvfp4(k_quant, k_scale).to(torch.float32)
    descriptor = _kpr_descriptor(k_raw, kv_num_heads, head_dim)
    distance = (k_state['kpr_k_descriptor'].to(torch.float32) - descriptor[None, :, :]).square().mean(dim=2)
    prototype_lengths = k_state['kpr_lengths'].to(torch.long)
    if rows < 512:
        # The short branch is new and must use its exact-length prototype.
        distance = distance + prototype_lengths.ne(rows)[:, None].to(distance.dtype) * 1.0e6
    else:
        # Preserve the scored 20531 long routing bit-for-bit: the newly stored
        # 128-row prototype is not eligible for an existing >=512 call.
        distance = distance + prototype_lengths.lt(512)[:, None].to(distance.dtype) * 1.0e6
    selected = distance.argmin(dim=0)
    head_index = torch.arange(int(kv_num_heads), dtype=torch.long, device=selected.device)
    q_reference = k_state['kpr_q_reference'][selected, head_index].to(torch.float32)
    q_quantized = k_state['kpr_q_quantized'][selected, head_index].to(torch.float32)
    q_per_kv = max(int(k_state.get('kpr_q_num_heads', kv_num_heads)) // int(kv_num_heads), 1)
    desired_queries = min(rows, int(_KPR_QUERY_ROWS)) * q_per_kv
    if desired_queries < int(q_reference.shape[1]):
        short_index = torch.linspace(
            0, int(q_reference.shape[1]) - 1, desired_queries,
            device=q_reference.device,
        ).round().to(torch.long)
        q_reference = q_reference.index_select(1, short_index)
        q_quantized = q_quantized.index_select(1, short_index)
    k_reference = k_raw.reshape(rows, int(kv_num_heads), int(head_dim)).permute(1, 0, 2).contiguous()
    step = _grid_step(params, tuple((int(value) for value in k_quant.shape))).reshape(rows, int(kv_num_heads), int(head_dim)).permute(1, 0, 2).contiguous()
    codes = torch.round(params['sign'].to(torch.float32) * params['mant'].to(torch.float32) * 4.0).to(torch.int8).reshape(rows, int(kv_num_heads), int(head_dim)).permute(1, 0, 2).contiguous()
    groups = None
    if int(_KPR_DYNAMIC_SELECTION) == 0:
        _, _, _, parent_groups = _joint_select_terms(k_state, rows)
        selected_groups = 6 if rows < 512 else 8
        usable = int(_KPR_GROUP_SIZE) * selected_groups
        groups = parent_groups.reshape(int(kv_num_heads), -1)[:, :usable].reshape(int(kv_num_heads), selected_groups, int(_KPR_GROUP_SIZE))
    repaired = _kpr_repair(q_reference, q_quantized, k_reference, step, codes, groups)
    return _pack_signed_codes(params, repaired.permute(1, 0, 2).reshape(k_quant.shape))


# Runtime-recovery configuration.  These globals are consumed by the existing
# parent Q/K and self-contained K-repair functions at call time.
_QSG_Q_COLUMNS = 120
_QSG_K_COLUMNS = 120
_KPR_QUERY_ROWS = 512
_KPR_GROUP_SIZE = 8
_KPR_GROUPS = 4
_KPR_TOKEN_BUDGET = 640
_kpr_pattern_index = torch.arange(1 << int(_KPR_GROUP_SIZE), dtype=torch.long)
_KPR_PATTERNS = (
    _kpr_pattern_index[:, None]
    >> torch.arange(int(_KPR_GROUP_SIZE), dtype=torch.long)[None, :]
    & 1
).to(torch.bool)
if True:
    _KPR_PATTERNS = _KPR_PATTERNS[_KPR_PATTERNS.sum(dim=1) <= 2].contiguous()

_KPR_DYNAMIC_SELECTION = 0


_KPR_SH2_LEFT = torch.tensor([left for left in range(8) for right in range(left + 1, 8)], dtype=torch.long)
_KPR_SH2_RIGHT = torch.tensor([right for left in range(8) for right in range(left + 1, 8)], dtype=torch.long)
_kpr_sh2_canonical = torch.tensor(
    [0]
    + [1 << index for index in range(8)]
    + [1 << left | 1 << right for left in range(8) for right in range(left + 1, 8)],
    dtype=torch.long,
)
_kpr_sh2_codes = (
    _KPR_PATTERNS.to(torch.long)
    * (1 << torch.arange(8, dtype=torch.long))[None, :]
).sum(dim=1)
_KPR_SH2_ORDER = (_kpr_sh2_codes[:, None] == _kpr_sh2_canonical[None, :]).to(torch.long).argmax(dim=1)

def _kpr_sparse_hamming2_costs(proposal_delta, group_gradient, token_diagonal, token_pair):
    coordinate = proposal_delta * group_gradient + 0.5 * proposal_delta.square() * token_diagonal
    left_delta = proposal_delta.index_select(2, _KPR_SH2_LEFT)
    right_delta = proposal_delta.index_select(2, _KPR_SH2_RIGHT)
    cross = left_delta * right_delta * token_pair
    pair = coordinate.index_select(2, _KPR_SH2_LEFT) + coordinate.index_select(2, _KPR_SH2_RIGHT) + cross
    packed = torch.cat(
        (
            torch.zeros((1, int(proposal_delta.shape[0]), int(proposal_delta.shape[1])), dtype=proposal_delta.dtype, device=proposal_delta.device),
            coordinate.permute(2, 0, 1),
            pair.permute(2, 0, 1),
        ),
        dim=0,
    )
    return packed.index_select(0, _KPR_SH2_ORDER.to(device=proposal_delta.device))


# Exact relative-cross-entropy K repair.  For candidate logit delta d and
# current probability p, softmax(l+d)=p*exp(d)/sum(p*exp(d)).  This removes the
# candidate-logit tensor and candidate log_softmax while retaining the same
# prototype cross-entropy acceptance condition and Gauss-Seidel order.
def _kpr_repair(q_reference, q_quantized, k_reference, step, code, groups):
    head_count, rows, head_dim = k_reference.shape
    root_dim = math.sqrt(float(head_dim))
    current_code = code.to(torch.float32)
    current = current_code * step
    reference_probability = torch.softmax(torch.bmm(q_reference, k_reference.transpose(1, 2)) / root_dim, dim=2)
    probability = torch.softmax(torch.bmm(q_quantized, current.transpose(1, 2)) / root_dim, dim=2)
    if groups is None:
        gradient = torch.bmm((probability - reference_probability).transpose(1, 2), q_quantized) / root_dim
        hessian_diagonal = torch.bmm((probability * (1.0 - probability)).transpose(1, 2), q_quantized.square()) / float(head_dim)
        raw_jump = torch.round(-gradient / (hessian_diagonal * step).clamp_min(1e-30)).clamp(-1.0, 1.0)
        fallback = torch.where(gradient > 0.0, -torch.ones_like(raw_jump), torch.ones_like(raw_jump))
        jump = torch.where(raw_jump == 0.0, fallback, raw_jump)
        jump = torch.maximum(torch.minimum(jump, 7.0 - current_code), -7.0 - current_code)
        delta = jump * step
        gain = (-(delta * gradient + 0.5 * delta.square() * hessian_diagonal)).clamp_min(0.0).sum(dim=1)
        usable = int(_KPR_GROUP_SIZE) * int(_KPR_GROUPS)
        groups = gain.topk(usable, dim=1, largest=True, sorted=True).indices.reshape(head_count, int(_KPR_GROUPS), int(_KPR_GROUP_SIZE))
    group_count = int(groups.shape[1])
    flat_columns = groups.reshape(head_count, -1)
    flat_width = int(flat_columns.shape[1])
    q_index = flat_columns[:, None, :].expand(head_count, int(q_quantized.shape[1]), flat_width)
    q_flat = torch.gather(q_quantized, 2, q_index)
    q_groups = q_flat.reshape(head_count, int(q_quantized.shape[1]), group_count, int(_KPR_GROUP_SIZE)).permute(0, 2, 1, 3).contiguous()
    reference_gradient = (torch.bmm(reference_probability.transpose(1, 2), q_flat) / root_dim).reshape(head_count, rows, group_count, int(_KPR_GROUP_SIZE)).permute(0, 2, 1, 3).contiguous()
    for group_index in range(int(groups.shape[1])):
        columns = groups[:, group_index, :]
        token_index = columns[:, None, :].expand(head_count, rows, int(_KPR_GROUP_SIZE))
        q_group = q_groups[:, group_index]
        group_gradient = torch.bmm(probability.transpose(1, 2), q_group)
        group_gradient.div_(root_dim).sub_(reference_gradient[:, group_index])
        weights = torch.addcmul(probability, probability, probability, value=-1.0)
        pair_query = q_group.index_select(2, _KPR_SH2_LEFT) * q_group.index_select(2, _KPR_SH2_RIGHT)
        curvature_query = torch.cat((q_group.square(), pair_query), dim=2)
        token_curvature = torch.bmm(weights.transpose(1, 2), curvature_query)
        token_curvature.div_(float(head_dim))
        token_diagonal = token_curvature[:, :, :int(_KPR_GROUP_SIZE)]
        token_pair = token_curvature[:, :, int(_KPR_GROUP_SIZE):]
        group_step = torch.gather(step, 2, token_index)
        group_code = torch.gather(current_code, 2, token_index)
        raw_jump = torch.round(-group_gradient / (token_diagonal * group_step).clamp_min(1e-30)).clamp(-1.0, 1.0)
        fallback = torch.where(group_gradient > 0.0, -torch.ones_like(raw_jump), torch.ones_like(raw_jump))
        jump = torch.where(raw_jump == 0.0, fallback, raw_jump)
        jump = torch.maximum(torch.minimum(jump, 7.0 - group_code), -7.0 - group_code)
        proposal_delta = jump * group_step
        costs = _kpr_sparse_hamming2_costs(proposal_delta, group_gradient, token_diagonal, token_pair)
        best = costs.argmin(dim=0)
        best_cost = torch.gather(costs, 0, best[None, :, :]).squeeze(0)
        chosen = _KPR_PATTERNS.index_select(0, best.reshape(-1)).reshape(head_count, rows, int(_KPR_GROUP_SIZE)) * proposal_delta
        if int(_KPR_TOKEN_BUDGET) >= rows:
            chosen = torch.where(best_cost[:, :, None] < 0.0, chosen, 0.0)
        else:
            selected_tokens = best_cost.topk(min(int(_KPR_TOKEN_BUDGET), rows), dim=1, largest=False, sorted=True).indices
            token_mask = torch.zeros((head_count, rows), dtype=torch.bool, device=chosen.device)
            token_mask.scatter_(1, selected_tokens, True)
            chosen = torch.where(token_mask[:, :, None] & (best_cost[:, :, None] < 0.0), chosen, 0.0)
        logit_delta = torch.bmm(q_group, chosen.transpose(1, 2))
        logit_delta.div_(root_dim)
        # A repair changes only eight coordinates by one quantization step, so
        # its logit delta is far inside exp's finite FP32 range.  The common
        # max-shift cancels algebraically in both normalization and loss.
        ratio = logit_delta.exp_()
        ratio.mul_(probability)
        normalizer = ratio.sum(dim=2, keepdim=True).clamp_min(1e-30)
        # sum(ref * (q_group @ chosen.T) / root_dim) is exactly the inner
        # product of `chosen` and the already cached ref-gradient.  Evaluate the
        # much smaller rows-by-8 form instead of another dense query-by-token
        # multiply and reduction.
        loss_delta = -(chosen * reference_gradient[:, group_index]).sum(dim=(1, 2))
        loss_delta += torch.log(normalizer.squeeze(2)).sum(dim=1)
        accept = loss_delta < 0.0
        if group_index + 1 < group_count:
            ratio.div_(normalizer)
            if bool(accept.all()):
                probability = ratio
            elif bool(accept.any()):
                probability = torch.where(accept[:, None, None], ratio, probability)
        if not bool(accept.all()):
            if bool(accept.any()):
                chosen = torch.where(accept[:, None, None], chosen, 0.0)
            else:
                chosen.zero_()
        new_code = torch.round(group_code + chosen / group_step.clamp_min(1e-30)).clamp(-7.0, 7.0)
        current_code.scatter_(2, token_index, new_code)
    return current_code.to(torch.int8)


# Exact unique-scale hierarchy evaluation.  The (lv2, lv3) grid has effective
# levels (1, 2, 2, 4); evaluate the duplicated level 2 once, then reconstruct
# the original two-stage first-min decisions.
def quantize_hif4(tensor, *, search_multipliers=DEFAULT_SEARCH_MULTIPLIERS, chunk_blocks=1280, element_weight=None):
    shape = tuple(int(value) for value in tensor.shape)
    if not shape or shape[-1] % HIF4_BLOCK_SIZE != 0:
        raise ValueError('HiF4 requires a non-empty shape and last dim divisible by 64')
    x = tensor.detach().to(dtype=torch.float32, device='cpu').contiguous()
    blocks_per_row = shape[-1] // HIF4_BLOCK_SIZE
    blocks = x.reshape(-1, HIF4_BLOCK_SIZE)
    block_count = int(blocks.shape[0])
    block_weight = None
    if element_weight is not None:
        if tuple(int(value) for value in element_weight.shape) != shape:
            raise ValueError('element_weight must match the quantized tensor shape')
        block_weight = element_weight.detach().to(dtype=torch.float32, device='cpu').contiguous().reshape(-1, 8, 2, 4)
    multipliers = torch.tensor(tuple(search_multipliers), dtype=torch.float32)
    if multipliers.numel() == 0 or not bool((multipliers > 0).all()):
        raise ValueError('search_multipliers must contain positive values')
    out_sf = torch.empty((block_count,), dtype=torch.float32)
    out_lv2 = torch.empty((block_count, 8), dtype=torch.float32)
    out_lv3 = torch.empty((block_count, 8, 2), dtype=torch.float32)
    out_sign = torch.empty((block_count, 8, 2, 4), dtype=torch.float32)
    out_mant = torch.empty((block_count, 8, 2, 4), dtype=torch.float32)
    unique_levels = torch.tensor((1.0, 2.0, 4.0), dtype=torch.float32)
    for start in range(0, block_count, int(chunk_blocks)):
        end = min(start + int(chunk_blocks), block_count)
        xb = blocks[start:end]
        absx = xb.abs().reshape(-1, 8, 2, 4)
        max_abs = absx.amax(dim=(1, 2, 3))
        base = (max_abs / 7.0).clamp_min(HIF4_MIN_SCALE)
        candidates = round_e6m2(base[:, None] * multipliers[None, :])
        local_scale = candidates[:, :, None, None, None, None] * unique_levels[None, None, :, None, None, None]
        expanded_abs = absx[:, None, None, :, :, :]
        mant = (expanded_abs / local_scale).mul_(4.0).round_().clamp_(0.0, 7.0).div_(4.0)
        mant.mul_(local_scale)
        level_error = torch.sub(expanded_abs, mant, out=mant).square_()
        if block_weight is not None:
            level_error.mul_(block_weight[start:end, None, None, :, :, :])
        level_error = level_error.sum(dim=-1)
        error0, error1, error2 = level_error.unbind(dim=2)
        index0 = error1 < error0
        index1 = error2 < error1
        group_error0 = torch.minimum(error0, error1).sum(dim=-1)
        group_error1 = torch.minimum(error1, error2).sum(dim=-1)
        best_lv2_index = (group_error1 < group_error0).to(torch.long)
        best_group_error = torch.minimum(group_error0, group_error1)
        best_candidate = best_group_error.sum(dim=-1).argmin(dim=-1)
        chosen_sf = torch.gather(candidates, 1, best_candidate[:, None]).squeeze(1)
        chosen_lv2 = torch.gather(best_lv2_index, 1, best_candidate[:, None, None].expand(-1, 1, 8)).squeeze(1).to(torch.float32) + 1.0
        lv3_by_candidate = torch.where(best_lv2_index[:, :, :, None].bool(), index1, index0).to(torch.long)
        chosen_lv3 = torch.gather(lv3_by_candidate, 1, best_candidate[:, None, None, None].expand(-1, 1, 8, 2)).squeeze(1).to(torch.float32) + 1.0
        effective_scale = chosen_sf[:, None, None, None] * chosen_lv2[:, :, None, None] * chosen_lv3[:, :, :, None]
        chosen_mant = torch.round(absx / effective_scale * 4.0).clamp_(0.0, 7.0) / 4.0
        out_sf[start:end] = chosen_sf
        out_lv2[start:end] = chosen_lv2
        out_lv3[start:end] = chosen_lv3
        out_sign[start:end] = torch.sign(xb).reshape(-1, 8, 2, 4)
        out_mant[start:end] = chosen_mant
    prefix = shape[:-1] + (blocks_per_row,)
    return {
        'scale_factor': out_sf.reshape(prefix + (1, 1, 1)).to(torch.bfloat16),
        'scale_lv2': out_lv2.reshape(prefix + (8, 1, 1)).to(torch.bfloat16),
        'scale_lv3': out_lv3.reshape(prefix + (8, 2, 1)).to(torch.bfloat16),
        'sign': out_sign.reshape(prefix + (8, 2, 4)).to(torch.bfloat16),
        'mant': out_mant.reshape(prefix + (8, 2, 4)).to(torch.bfloat16),
    }

# Output-equivalent Linear execution baseline on the 20470/277s package.
_V41_FAST_PARENT_REFINER = refine_hif4_activation_exact_block64
def refine_hif4_activation_exact_block64(
    tensor: torch.Tensor,
    params: dict[str, torch.Tensor],
    svd: dict[str, torch.Tensor],
    *,
    sweeps: int = 2,
) -> dict[str, torch.Tensor]:
    if (
        svd.get("activation_global_exact_columns") is not None
        or svd.get("activation_global_exact_hessian") is not None
    ):
        return _V41_FAST_PARENT_REFINER(
            tensor,
            params,
            svd,
            sweeps=sweeps,
        )

    shape = tuple(int(value) for value in tensor.shape)
    channels = int(shape[-1])
    rows = int(tensor.numel()) // channels
    blocks_per_row = channels // 64
    target = tensor.detach().to(torch.float32).reshape(rows, channels)
    factor = svd["vw"].to(torch.float32)
    diagonal = svd["an_full"].to(torch.float32)
    block_hessians = svd["activation_block_hessian"].to(torch.float32)
    if tuple(block_hessians.shape) != (blocks_per_row, 64, 64):
        raise ValueError("invalid exact Activation block Hessian shape")

    code_shape = tuple(int(value) for value in params["mant"].shape)
    step = (
        params["scale_factor"].to(torch.float32)
        * params["scale_lv2"].to(torch.float32)
        * params["scale_lv3"].to(torch.float32)
        * 0.25
    ).expand_as(params["mant"]).reshape(rows, channels).clamp_min(1.0e-30)
    codes = (
        params["sign"].to(torch.float32)
        * params["mant"].to(torch.float32)
        * 4.0
    ).reshape(rows, channels).round().clamp_(-7.0, 7.0)
    error = target - codes * step
    projected = error @ factor.T

    # These matrices are invariant across sweeps.  The parent recomputes them
    # for every block in every sweep.
    block_corrections: list[torch.Tensor] = []
    for block in range(blocks_per_row):
        start = block * 64
        end = start + 64
        local_factor = factor[:, start:end]
        local_diagonal = diagonal[start:end]
        approximate = local_factor.T @ local_factor + torch.diag(local_diagonal)
        block_corrections.append(block_hessians[block] - approximate)

    for _ in range(int(sweeps)):
        for block in range(blocks_per_row):
            start = block * 64
            end = start + 64
            local_diagonal = diagonal[start:end]
            exact = block_hessians[block]
            correction = block_corrections[block]
            local_error = error[:, start:end]
            for local_column in range(64):
                column = start + local_column
                old_error = error[:, column]
                hessian_times_error = (
                    projected @ factor[:, column]
                    + local_diagonal[local_column] * old_error
                    + local_error @ correction[:, local_column]
                )
                hessian_diagonal = exact[
                    local_column,
                    local_column,
                ].clamp_min(1.0e-20)
                cross = hessian_times_error - hessian_diagonal * old_error
                proposal_code = torch.round(
                    (target[:, column] + cross / hessian_diagonal) / step[:, column]
                ).clamp_(-7.0, 7.0)
                proposal_error = target[:, column] - proposal_code * step[:, column]
                delta = proposal_error - old_error
                objective_delta = (
                    2.0 * delta * cross + delta.square() * hessian_diagonal
                )
                accepted = objective_delta < -1.0e-12
                accepted_delta = torch.where(
                    accepted,
                    delta,
                    torch.zeros_like(delta),
                )
                codes[:, column] = torch.where(
                    accepted,
                    proposal_code,
                    codes[:, column],
                )
                error[:, column] = old_error + accepted_delta
                projected = torch.addmm(
                    projected,
                    accepted_delta[:, None],
                    factor[:, column][None, :],
                )

    result = dict(params)
    result["sign"] = torch.sign(codes).reshape(code_shape).to(torch.bfloat16)
    result["mant"] = (
        codes.abs() * 0.25
    ).reshape(code_shape).to(torch.bfloat16)
    return result

# External-38 Linear execution transplant; Attention remains the 20470 parent.
def _v36_update_gradient(gradient, delta, hessian_rows, accepted):
    # Rejected rows are exact zeros. Avoid GEMM on them late in coordinate
    # descent; dense updates remain faster when at least a quarter are active.
    if int(delta.shape[0]) >= 32:
        active = torch.nonzero(accepted, as_tuple=False).flatten()
        if int(active.numel()) == 0:
            return
        if int(active.numel()) * 4 < int(delta.shape[0]):
            gradient[active] -= delta.index_select(0, active) @ hessian_rows
            return
    gradient.sub_(delta @ hessian_rows)

def _v21_dor_dynamic(
    activation_quant,
    activation_scale,
    activation_state,
    *,
    _return_context=False,
):
    raw = dequantize_nvfp4(activation_quant, activation_scale).to(torch.float32)
    raw = transform_linear_tensor(raw, activation_state, inverse_scale=True)
    target = raw @ activation_state["activation_output_preconditioner"].to(
        torch.float32
    )
    params = quantize_hif4_gptq_tensor_fast(
        target, activation_state["activation_hessian"]
    )

    shape = tuple(int(value) for value in target.shape)
    channels = int(shape[-1])
    rows = int(target.numel()) // channels
    blocks = channels // 64
    scale_factor = params["scale_factor"].to(torch.float32).reshape(rows, blocks)
    scale_lv2 = params["scale_lv2"].to(torch.float32).reshape(rows, blocks, 8)
    scale_lv3 = params["scale_lv3"].to(torch.float32).reshape(rows, blocks, 8, 2)
    step = (
        scale_factor[:, :, None, None, None]
        * scale_lv2[:, :, :, None, None]
        * scale_lv3[:, :, :, :, None]
        * 0.25
    ).expand(-1, -1, -1, -1, 4).reshape(rows, channels)
    codes = (
        params["sign"].to(torch.float32)
        * params["mant"].to(torch.float32)
        * 4.0
    ).reshape(rows, channels).round().clamp_(-7.0, 7.0)
    quantized = codes * step

    hessian = activation_state["v21_dor_hessian"].to(torch.float32)
    damping = (
        torch.diagonal(hessian).mean()
        * float(LINEAR_OUTPUT_COMPENSATION_DAMP)
    )
    residual_gradient = (
        (target.reshape(rows, channels) - quantized) @ hessian
        + damping * (target.reshape(rows, channels) - raw.reshape(rows, channels))
    )
    columns_all = activation_state["v21_dor_columns"].to(torch.long)
    diagonal_all = activation_state["v21_dor_diagonal"].to(torch.float32)
    local_hessian_all = activation_state["v21_dor_local_hessian"].to(torch.float32)
    hessian_rows_all = activation_state["v21_dor_hessian_rows"].to(torch.float32)
    colors = int(activation_state["v21_dor_colors"])

    for local_column in range(64):
        for color in range(colors):
            columns = columns_all[local_column, color]
            diagonal = diagonal_all[local_column, color]
            local_hessian = local_hessian_all[local_column, color]
            hessian_rows = hessian_rows_all[local_column, color]
            local_step = step.index_select(1, columns)
            old_codes = codes.index_select(1, columns)
            old_quantized = old_codes * local_step
            local_gradient = residual_gradient.index_select(1, columns)
            proposal_codes = torch.round(
                (old_quantized + local_gradient / diagonal) / local_step
            ).clamp_(-7.0, 7.0)
            delta = proposal_codes * local_step - old_quantized
            objective_delta = -2.0 * (delta * local_gradient).sum(dim=1)
            objective_delta += ((delta @ local_hessian) * delta).sum(dim=1)
            accepted = objective_delta < -1.0e-12
            accepted_delta = torch.where(
                accepted[:, None], delta, torch.zeros_like(delta)
            )
            codes[:, columns] = torch.where(
                accepted[:, None], proposal_codes, old_codes
            )
            _v36_update_gradient(residual_gradient, accepted_delta, hessian_rows, accepted)

    # V26: alternate the two partitions imposed by the actual format.
    # A Block64 pass jointly searches the legal neighbouring E6M2 base scale
    # and all 64 mantissa codes; the existing C1 pass then revisits equal
    # offsets across Block64s.  Exact full-Hessian acceptance makes every
    # update monotone for the online output objective.  Eight short cycles
    # retain the measured quality knee while recovering
    # enough runtime margin for the full evaluator.
    full_diagonal = torch.diagonal(hessian).clamp_min(1.0e-20)
    scale_grid = _E6M2_VALUES
    scale_offsets = torch.tensor((-1, 0, 1), dtype=torch.long)
    block_columns = tuple(
        torch.arange(block * 64, (block + 1) * 64, dtype=torch.long)
        for block in range(blocks)
    )
    # Linhan's adopted outer-weight state reaches the same quality knee with
    # three base/DOR cycles; retain all eight for the untouched fast fallback.
    linear_cycles = 1 if activation_state.get("fusion_weight_adopted", False) else 8
    for _ in range(linear_cycles):
        for block, columns in enumerate(block_columns):
            block_slice = slice(block * 64, (block + 1) * 64)
            current_scale = scale_factor[:, block].contiguous()
            center = torch.searchsorted(scale_grid, current_scale).clamp(
                0, int(scale_grid.numel()) - 1
            )
            candidate_indices = (
                center[:, None] + scale_offsets[None]
            ).clamp(0, int(scale_grid.numel()) - 1)
            candidate_scales = scale_grid.index_select(
                0, candidate_indices.reshape(-1)
            ).reshape(rows, -1).T

            old_codes = codes[:, block_slice]
            old_step = step[:, block_slice]
            old_quantized = old_codes * old_step
            local_gradient = residual_gradient[:, block_slice]
            local_diagonal = full_diagonal[block_slice]
            # Contiguous Block64 views avoid repeatedly copying Hessian rows.
            block_start = block * 64
            hessian_rows = hessian[block_start:block_start + 64]
            local_hessian = hessian_rows[:, block_start:block_start + 64]
            candidate_step = old_step[None] * (
                candidate_scales[:, :, None]
                / current_scale[None, :, None]
            )
            candidate_codes = torch.round(
                (
                    old_quantized[None]
                    + local_gradient[None] / local_diagonal
                )
                / candidate_step
            ).clamp_(-7.0, 7.0)
            candidate_delta = (
                candidate_codes * candidate_step - old_quantized[None]
            )
            objective_delta = -2.0 * (
                candidate_delta * local_gradient[None]
            ).sum(dim=2)
            objective_delta += (
                (candidate_delta @ local_hessian) * candidate_delta
            ).sum(dim=2)
            best = objective_delta.argmin(dim=0)
            best_objective = objective_delta.gather(
                0, best[None]
            ).squeeze(0)
            accepted = best_objective < -1.0e-12
            chosen_delta = candidate_delta.gather(
                0, best[None, :, None].expand(1, -1, 64)
            ).squeeze(0)
            chosen_codes = candidate_codes.gather(
                0, best[None, :, None].expand(1, -1, 64)
            ).squeeze(0)
            chosen_step = candidate_step.gather(
                0, best[None, :, None].expand(1, -1, 64)
            ).squeeze(0)
            chosen_scale = candidate_scales.gather(
                0, best[None]
            ).squeeze(0)
            accepted_delta = torch.where(
                accepted[:, None], chosen_delta, torch.zeros_like(chosen_delta)
            )
            codes[:, block_slice] = torch.where(
                accepted[:, None], chosen_codes, old_codes
            )
            step[:, block_slice] = torch.where(
                accepted[:, None], chosen_step, old_step
            )
            scale_factor[:, block] = torch.where(
                accepted, chosen_scale, current_scale
            )
            _v36_update_gradient(residual_gradient, accepted_delta, hessian_rows, accepted)

        for local_column in range(64):
            for color in range(colors):
                columns = columns_all[local_column, color]
                diagonal = diagonal_all[local_column, color]
                local_hessian = local_hessian_all[local_column, color]
                hessian_rows = hessian_rows_all[local_column, color]
                local_step = step.index_select(1, columns)
                old_codes = codes.index_select(1, columns)
                old_quantized = old_codes * local_step
                local_gradient = residual_gradient.index_select(1, columns)
                proposal_codes = torch.round(
                    (old_quantized + local_gradient / diagonal) / local_step
                ).clamp_(-7.0, 7.0)
                delta = proposal_codes * local_step - old_quantized
                objective_delta = -2.0 * (
                    delta * local_gradient
                ).sum(dim=1)
                objective_delta += ((delta @ local_hessian) * delta).sum(dim=1)
                accepted = objective_delta < -1.0e-12
                accepted_delta = torch.where(
                    accepted[:, None], delta, torch.zeros_like(delta)
                )
                codes[:, columns] = torch.where(
                    accepted[:, None], proposal_codes, old_codes
                )
                _v36_update_gradient(residual_gradient, accepted_delta, hessian_rows, accepted)

    result = dict(params)
    code_shape = tuple(int(value) for value in params["mant"].shape)
    result["scale_factor"] = scale_factor.reshape(
        params["scale_factor"].shape
    ).to(torch.bfloat16)
    result["sign"] = torch.sign(codes).reshape(code_shape).to(torch.bfloat16)
    result["mant"] = (
        codes.abs() * 0.25
    ).reshape(code_shape).to(torch.bfloat16)
    if _return_context:
        return result, raw, target
    return result


def _v31_refine_linear_hierarchy(raw, params, state, *, target=None):
    """Two passes of exact-output-accepted, legal level-2/3 group search."""
    channels = int(raw.shape[-1])
    rows = int(raw.numel()) // channels
    blocks = channels // 64
    raw = raw.reshape(rows, channels).to(torch.float32)
    if target is None:
        target = raw @ state["activation_output_preconditioner"].to(torch.float32)
    else:
        target = target.reshape(rows, channels).to(torch.float32)
    hessian = state["v21_dor_hessian"].to(torch.float32)
    diagonal = torch.diagonal(hessian).clamp_min(1.0e-20)
    damping = diagonal.mean() * float(LINEAR_OUTPUT_COMPENSATION_DAMP)
    sf = params["scale_factor"].float().reshape(rows, blocks).clone()
    lv2 = params["scale_lv2"].float().reshape(rows, blocks, 8).clone()
    lv3 = params["scale_lv3"].float().reshape(rows, blocks, 8, 2).clone()
    codes = (params["sign"].float() * params["mant"].float() * 4).reshape(
        rows, channels).round()
    step = (sf[:, :, None, None, None] * lv2[:, :, :, None, None]
            * lv3[:, :, :, :, None] * 0.25).expand(
                rows, blocks, 8, 2, 4).reshape(rows, channels).clone()
    quantized = codes * step
    gradient = (target - quantized) @ hessian + damping * (target - raw)
    patterns = torch.tensor([[a, b, c] for a in (1., 2.)
                             for b in (1., 2.) for c in (1., 2.)])
    products = (patterns[:, :1] * patterns[:, 1:]).repeat_interleave(4, dim=1)
    batch = torch.arange(rows)
    for _ in range(2):
        for block in range(blocks):
            start, end = block * 64, (block + 1) * 64
            block_hessian = hessian[start:end, start:end]
            block_gradient = gradient[:, start:end].clone()
            block_delta = torch.zeros((rows, 64), dtype=torch.float32)
            for group in range(8):
                local_start, local_end = group * 8, (group + 1) * 8
                sl = slice(start + local_start, start + local_end)
                local_hessian = block_hessian[local_start:local_end,
                                              local_start:local_end]
                local_gradient = block_gradient[:, local_start:local_end]
                old = quantized[:, sl]
                candidate_step = sf[:, block][None, :, None] * products[:, None] * .25
                correction = local_gradient / diagonal[sl]
                candidate_codes = ((old + correction)[None] /
                                   candidate_step).round().clamp(-7., 7.)
                candidate_delta = candidate_codes * candidate_step - old[None]
                objective = (-2. * (candidate_delta * local_gradient[None]).sum(dim=2)
                             + ((candidate_delta @ local_hessian) * candidate_delta).sum(dim=2))
                best = objective.argmin(dim=0)
                accepted = objective[best, batch] < -1.e-12
                change = torch.where(accepted[:, None], candidate_delta[best, batch], 0.)
                codes[:, sl] = torch.where(accepted[:, None], candidate_codes[best, batch], codes[:, sl])
                step[:, sl] = torch.where(accepted[:, None], candidate_step[best, batch], step[:, sl])
                chosen = patterns[best]
                lv2[:, block, group] = torch.where(accepted, chosen[:, 0], lv2[:, block, group])
                lv3[:, block, group] = torch.where(accepted[:, None], chosen[:, 1:], lv3[:, block, group])
                quantized[:, sl] += change
                block_delta[:, local_start:local_end] = change
                block_gradient -= change @ block_hessian[local_start:local_end]
            gradient -= block_delta @ hessian[start:end]
    result = dict(params)
    result["scale_lv2"] = lv2.reshape(params["scale_lv2"].shape).to(torch.bfloat16)
    result["scale_lv3"] = lv3.reshape(params["scale_lv3"].shape).to(torch.bfloat16)
    result["sign"] = torch.sign(codes).reshape(params["sign"].shape).to(torch.bfloat16)
    result["mant"] = (codes.abs() * .25).reshape(params["mant"].shape).to(torch.bfloat16)
    return result

def hif4_dynamic_quantize_activation(activation_quant, activation_scale,
                                    activation_state):
    params, raw, target = _v21_dor_dynamic(
        activation_quant,
        activation_scale,
        activation_state,
        _return_context=True,
    )
    return _v31_refine_linear_hierarchy(
        raw, params, activation_state, target=target
    )

# ---------------------------------------------------------------------------
# Fast-20805 + Linhan-43 fusion
#
# Keep the fast submission's Q/K/V path intact. Linhan-43 contributes its
# complementary outer Linear step: optimize legal weight codes, rebuild every
# weight-dependent activation state, then adopt the result only when held-out
# calibration folds improve. For adopted weights, the online activation pass
# uses the matching block/group/coordinate refinement on the legal HiF4 grid.
# ---------------------------------------------------------------------------


def _fusion_greedy_codes(codes, step, gradient, hessian, iterations=24):
    diagonal = hessian.diagonal().clamp_min(1.0e-20)
    bits = ((torch.arange(16)[:, None] >> torch.arange(4)) & 1).float()
    for first in range(0, codes.shape[0], 256):
        cc = codes[first:first + 256]
        ss = step[first:first + 256]
        gg = gradient[first:first + 256]
        rows = torch.arange(cc.shape[0])
        for _ in range(iterations):
            proposed = (cc + gg / (diagonal * ss)).round().clamp(-7, 7)
            delta = (proposed - cc) * ss
            gain = 2 * delta * gg - delta.square() * diagonal
            priority, columns = gain.topk(4, dim=1)
            if not bool((priority[:, 0] > 1.0e-12).any()):
                break
            local_delta = delta.gather(1, columns)
            local_gradient = gg.gather(1, columns)
            local_hessian = hessian[
                columns[:, :, None], columns[:, None, :]
            ]
            candidates = bits[:, None, :] * local_delta[None]
            costs = -2 * (candidates * local_gradient[None]).sum(-1)
            costs += torch.einsum(
                "pni,nij,pnj->pn", candidates, local_hessian, candidates
            )
            best = costs.argmin(0)
            accepted = costs[best, rows] < -1.0e-12
            selected = bits[best].bool() & accepted[:, None]
            old = cc.gather(1, columns)
            cc.scatter_(
                1, columns,
                torch.where(selected, proposed.gather(1, columns), old),
            )
            change = torch.where(selected, local_delta, 0.0)
            gg -= torch.einsum(
                "ni,nic->nc", change, hessian[columns]
            )
    return codes


def _fusion_cooperative_codes(
    codes, step, gradient, hessian, iterations=12, width=24
):
    """Exact-gated pair moves, including pairs of uphill single moves."""
    diagonal = hessian.diagonal().clamp_min(1.0e-20)
    channels = codes.shape[1]
    width = min(width, 2 * channels)
    for first in range(0, codes.shape[0], 128):
        cc = codes[first:first + 128]
        ss = step[first:first + 128]
        gg = gradient[first:first + 128]
        rows = torch.arange(cc.shape[0])
        for _ in range(iterations):
            plus = 2 * ss * gg - ss.square() * diagonal
            minus = -2 * ss * gg - ss.square() * diagonal
            gains = torch.cat(
                (
                    plus.masked_fill(cc >= 7, -float("inf")),
                    minus.masked_fill(cc <= -7, -float("inf")),
                ),
                dim=1,
            )
            priority, indices = gains.topk(width, dim=1)
            columns = indices % channels
            signs = torch.where(indices < channels, 1.0, -1.0)
            delta = signs * ss.gather(1, columns)
            local_hessian = hessian[
                columns[:, :, None], columns[:, None, :]
            ]
            joint = priority[:, :, None] + priority[:, None, :]
            joint -= (
                2
                * delta[:, :, None]
                * delta[:, None, :]
                * local_hessian
            )
            joint.masked_fill_(
                columns[:, :, None] == columns[:, None, :], -float("inf")
            )
            joint.diagonal(dim1=1, dim2=2).copy_(priority)
            gain, best = joint.flatten(1).max(1)
            accepted = gain > 1.0e-12
            if not bool(accepted.any()):
                break
            first_index = best // width
            second_index = best % width
            first_column = columns[rows, first_index]
            second_column = columns[rows, second_index]
            first_delta = torch.where(
                accepted, delta[rows, first_index], 0.0
            )
            second_delta = torch.where(
                accepted & (first_index != second_index),
                delta[rows, second_index],
                0.0,
            )
            cc[rows, first_column] += torch.where(
                accepted, signs[rows, first_index], 0.0
            )
            cc[rows, second_column] += torch.where(
                accepted & (first_index != second_index),
                signs[rows, second_index],
                0.0,
            )
            gg -= (
                first_delta[:, None] * hessian[first_column]
                + second_delta[:, None] * hessian[second_column]
            )
    return codes


def _fusion_optimize_weight(
    weight,
    params,
    state,
    calibration,
    iterations=2,
    ridge=0.01,
    rho=0.125,
    covariance_shrink=0.2,
    coordinate_steps=6,
    _quantized_weight=None,
    _transformed_calibration=None,
):
    quantized_weight = (
        dequantize_hif4(params)
        if _quantized_weight is None
        else _quantized_weight
    )
    channels = weight.shape[1]
    covariance = torch.zeros(channels, channels)
    if _transformed_calibration is None:
        transformed_calibration = [
            transform_linear_tensor(
                dequantize_nvfp4(quant, scale), state, inverse_scale=True
            )
            for quant, scale in calibration
        ]
    else:
        transformed_calibration = _transformed_calibration
    for activation in transformed_calibration:
        local = activation.T @ activation / activation.shape[0]
        covariance += local / local.diagonal().mean().clamp_min(1.0e-20)
    covariance = covariance / len(calibration)
    covariance = covariance * (1 - covariance_shrink)
    covariance += torch.eye(channels) * covariance_shrink

    preconditioner = state["activation_output_preconditioner"].float()
    target_cross = weight @ covariance @ preconditioner
    curvature = preconditioner.T @ covariance @ preconditioner
    curvature += (
        torch.eye(channels) * curvature.diagonal().mean() * ridge
    )
    normalization = curvature.diagonal().sqrt().clamp_min(1.0e-12)
    normalized_curvature = (
        curvature / normalization[:, None] / normalization[None, :]
    )
    normalized_cross = target_cross / normalization
    eigenvalues, eigenvectors = torch.linalg.eigh(normalized_curvature)
    inverses = [
        (eigenvectors / (eigenvalues + rho * 1.5 ** index))
        @ eigenvectors.T
        for index in range(iterations)
    ]

    steps = _grid_step(params, tuple(weight.shape)).clamp_min(1.0e-30)
    output_codes = torch.empty_like(quantized_weight)
    trajectory = [0] * iterations
    for first in range(0, weight.shape[0], 512):
        last = first + 512
        discrete = quantized_weight[first:last] * normalization
        dual = torch.zeros_like(discrete)
        local_step = steps[first:last] * normalization
        local_cross = normalized_cross[first:last]
        best = discrete.clone()
        best_cost = (
            (discrete @ normalized_curvature) * discrete
            - 2 * discrete * local_cross
        ).sum(1)
        for index in range(iterations):
            penalty = rho * 1.5 ** index
            continuous = (
                local_cross + penalty * discrete - dual
            ) @ inverses[index]
            discrete = (
                (continuous + dual / penalty) / local_step
            ).round().clamp(-7, 7) * local_step
            dual += penalty * (continuous - discrete)
            cost = (
                (discrete @ normalized_curvature) * discrete
                - 2 * discrete * local_cross
            ).sum(1)
            accepted = cost < best_cost
            best = torch.where(accepted[:, None], discrete, best)
            best_cost = torch.minimum(best_cost, cost)
            trajectory[index] += int(accepted.sum())
        output_codes[first:last] = (
            best / local_step
        ).round().clamp(-7, 7)

    # Alternate once: rebuild the continuous activation minimizer around the
    # newly selected legal weight, then make exact-gated coordinate updates.
    selected_weight = output_codes * steps
    weight_hessian = selected_weight.T @ selected_weight
    damping = (
        weight_hessian.diagonal().mean().clamp_min(1.0e-30)
        * LINEAR_OUTPUT_COMPENSATION_DAMP
    )
    cholesky = torch.linalg.cholesky(
        weight_hessian + torch.eye(channels) * damping
    )
    preconditioner = (
        torch.eye(channels)
        + torch.cholesky_solve(
            selected_weight.T @ (weight - selected_weight), cholesky
        ).T
    ).contiguous()
    cross = covariance @ preconditioner
    curvature = preconditioner.T @ cross
    gradient = weight @ cross - selected_weight @ curvature
    curvature += (
        torch.eye(channels) * curvature.diagonal().mean() * 0.1
    )
    _fusion_greedy_codes(
        output_codes,
        steps,
        gradient,
        curvature,
        iterations=coordinate_steps,
    )
    optimized_weight = output_codes * steps
    return (
        _pack_signed_codes(params, output_codes),
        trajectory,
        optimized_weight,
    )


def _fusion_refresh_weight_state(
    raw_weight, params, old_state, *, _quantized_weight=None
):
    """Rebuild every cached Linear object that depends on quantized weight."""
    state = dict(old_state)
    weight = (
        dequantize_hif4(params)
        if _quantized_weight is None
        else _quantized_weight
    ).float()
    channels = weight.shape[1]
    hessian = weight.T @ weight
    damping = (
        hessian.diagonal().mean().clamp_min(1.0e-30)
        * LINEAR_OUTPUT_COMPENSATION_DAMP
    )
    cross = weight.T @ (raw_weight - weight)
    cholesky = torch.linalg.cholesky(
        hessian + torch.eye(channels) * damping
    )
    state["activation_output_preconditioner"] = (
        torch.eye(channels) + torch.cholesky_solve(cross, cholesky).T
    ).contiguous()

    approximation = quantized_weight_hessian_svd(
        weight, ACTIVATION_GPTQ_RANK
    )
    blocks = weight.reshape(weight.shape[0], channels // 64, 64)
    approximation["activation_block_hessian"] = torch.einsum(
        "obc,obd->bcd", blocks, blocks
    ).contiguous()
    state["activation_hessian"] = approximation
    state["activation_hessian_rank"] = int(approximation["vw"].shape[0])
    state["v21_dor_hessian"] = hessian.contiguous()

    columns = state["v21_dor_columns"].long()
    diagonal = torch.empty_like(state["v21_dor_diagonal"])
    local_hessian = torch.empty_like(state["v21_dor_local_hessian"])
    hessian_rows = torch.empty_like(state["v21_dor_hessian_rows"])
    for column in range(columns.shape[0]):
        for color in range(columns.shape[1]):
            selected = columns[column, color]
            diagonal[column, color] = hessian[selected, selected].clamp_min(
                1.0e-20
            )
            local_hessian[column, color] = hessian.index_select(
                0, selected
            ).index_select(1, selected)
            hessian_rows[column, color] = hessian.index_select(0, selected)
    state["v21_dor_diagonal"] = diagonal
    state["v21_dor_local_hessian"] = local_hessian
    state["v21_dor_hessian_rows"] = hessian_rows
    return state


_fusion_parent_weight_calibration = hif4_calibration_and_quantize_weight


def _fusion_calibrate_weight(
    weight_quant, weight_scale, calib_activation_list
):
    result, context = _fusion_parent_weight_calibration(
        weight_quant,
        weight_scale,
        calib_activation_list,
        _return_context=True,
    )
    channels = int(weight_quant.shape[-1])
    if (
        channels > 2048
        or weight_quant.numel() > 16777216
        or not calib_activation_list
        or channels % 64
    ):
        return result
    state = result["activation_state"]
    raw_weight = context["raw_weight"]
    transformed = context["transformed_weight"]
    try:
        params, _, optimized_weight = _fusion_optimize_weight(
            transformed,
            result["weight_params"],
            state,
            calib_activation_list,
            _quantized_weight=context["quantized_weight"],
            _transformed_calibration=context["transformed_calibration"],
        )
        new_state = _fusion_refresh_weight_state(
            transformed,
            params,
            state,
            _quantized_weight=optimized_weight,
        )
        new_state["fusion_weight_adopted"] = True

        # Fold-balanced operator gate. It compares against the original
        # NVFP4 output and never uses public/test inputs.
        quant_parts = []
        scale_parts = []
        counts = []
        for quant, scale in calib_activation_list:
            quant = quant.reshape(-1, channels)
            scale = scale.reshape(-1, channels // 16)
            # This gate is far from its decision boundary on all calibration
            # folds; four deterministic rows retain the same deployed model.
            count = min(4, int(quant.shape[0]))
            if count == 0:
                continue
            indices = torch.linspace(
                0, quant.shape[0] - 1, count
            ).round().long()
            quant_parts.append(quant[indices])
            scale_parts.append(scale[indices])
            counts.append(count)
        if not counts:
            return result
        quant = torch.cat(quant_parts)
        scale = torch.cat(scale_parts)
        reference = dequantize_nvfp4(quant, scale).float() @ raw_weight.T
        before = dequantize_hif4(
            hif4_dynamic_quantize_activation(quant, scale, state)
        )
        after = dequantize_hif4(
            hif4_dynamic_quantize_activation(quant, scale, new_state)
        )
        old_error = (
            before @ context["quantized_weight"].T - reference
        ).square().mean(1)
        new_error = (
            after @ optimized_weight.T - reference
        ).square().mean(1)
        gains = []
        offset = 0
        for count in counts:
            gain = 1.0 - new_error[offset:offset + count].mean() / old_error[
                offset:offset + count
            ].mean().clamp_min(1.0e-30)
            gains.append(float(gain))
            offset += count
        if (
            all(math.isfinite(gain) for gain in gains)
            and min(gains) >= -0.002
            and sum(gains) / len(gains) >= 0.002
        ):
            new_state["fusion_weight_gate_gains"] = gains
            return {"weight_params": params, "activation_state": new_state}
    except (RuntimeError, ValueError, IndexError, KeyError):
        pass
    return result


hif4_calibration_and_quantize_weight = _fusion_calibrate_weight


def _fusion_scale_proposal(target, scale_factor, weights):
    rows = target.shape[0]
    magnitude = target.abs().reshape(rows, 8, 2, 4)
    index = torch.searchsorted(_E6M2_VALUES, scale_factor.contiguous())
    offsets = torch.tensor([-1, 0, 1])
    candidates = _E6M2_VALUES[
        (index[:, None] + offsets[None]).clamp(
            0, _E6M2_VALUES.numel() - 1
        )
    ]
    products = torch.tensor([[1.0, 2.0], [2.0, 4.0]]).reshape(
        1, 1, 2, 2, 1, 1, 1
    )
    candidate_steps = (
        candidates[:, :, None, None, None, None, None]
        * products
        * 0.25
    )
    candidate_codes = (
        magnitude[:, None, None, None] / candidate_steps
    ).round().clamp(0, 7)
    error = (
        (
            magnitude[:, None, None, None]
            - candidate_codes * candidate_steps
        ).square()
        * weights.reshape(1, 1, 1, 1, 8, 2, 4)
    ).sum(-1)
    error_lv3, level3 = error.min(3)
    error_lv2, level2 = error_lv3.sum(-1).min(2)
    winner = error_lv2.sum(-1).argmin(-1)
    batch = torch.arange(rows)
    base = candidates[batch, winner]
    chosen_level2 = level2[batch, winner]
    all_level3 = level3[batch, winner]
    chosen_level3 = all_level3.gather(
        1,
        chosen_level2[None].permute(1, 0, 2).unsqueeze(-1).expand(
            -1, 1, -1, 2
        ),
    ).squeeze(1)
    step = (
        base[:, None, None, None]
        * (chosen_level2 + 1)[:, :, None, None]
        * (chosen_level3 + 1)[:, :, :, None]
        * 0.25
    )
    codes = (target.reshape(rows, 8, 2, 4) / step).round().clamp(-7, 7)
    return (
        base,
        chosen_level2 + 1,
        chosen_level3 + 1,
        codes.reshape(rows, 64),
        step.expand(rows, 8, 2, 4).reshape(rows, 64),
    )


_fusion_parent_linear_hierarchy = _v31_refine_linear_hierarchy


def _fusion_linear_hierarchy(raw, params, state, *, target=None):
    """Linhan-43's legal block/group/coordinate activation refinement."""
    if not state.get("fusion_weight_adopted", False):
        return _fusion_parent_linear_hierarchy(
            raw, params, state, target=target
        )
    channels = int(raw.shape[-1])
    rows = int(raw.numel()) // channels
    blocks = channels // 64
    raw = raw.reshape(rows, channels).to(torch.float32)
    if target is None:
        target = raw @ state["activation_output_preconditioner"].to(torch.float32)
    else:
        target = target.reshape(rows, channels).to(torch.float32)
    hessian = state["v21_dor_hessian"].to(torch.float32)
    diagonal = torch.diagonal(hessian).clamp_min(1.0e-20)
    damping = diagonal.mean() * float(LINEAR_OUTPUT_COMPENSATION_DAMP)

    scale_factor = params["scale_factor"].float().reshape(rows, blocks).clone()
    level2 = params["scale_lv2"].float().reshape(rows, blocks, 8).clone()
    level3 = params["scale_lv3"].float().reshape(rows, blocks, 8, 2).clone()
    codes = (
        params["sign"].float() * params["mant"].float() * 4
    ).reshape(rows, channels).round()
    step = (
        scale_factor[:, :, None, None, None]
        * level2[:, :, :, None, None]
        * level3[:, :, :, :, None]
        * 0.25
    ).expand(rows, blocks, 8, 2, 4).reshape(rows, channels).clone()
    quantized = codes * step
    gradient = (
        (target - quantized) @ hessian + damping * (target - raw)
    )

    patterns = torch.tensor(
        [
            [first, second, third]
            for first in (1.0, 2.0)
            for second in (1.0, 2.0)
            for third in (1.0, 2.0)
        ]
    )
    products = (
        patterns[:, :1] * patterns[:, 1:]
    ).repeat_interleave(4, dim=1)
    local_systems = torch.stack(
        [
            hessian[index:index + 8, index:index + 8]
            for index in range(0, channels, 8)
        ]
    )
    local_inverses, inverse_info = torch.linalg.inv_ex(local_systems)
    valid_inverse = (
        (inverse_info == 0)
        & torch.isfinite(local_inverses).all(dim=(1, 2))
    )
    diagonal_inverse = torch.diag_embed(
        diagonal.reshape(-1, 8).reciprocal()
    )
    local_inverses = torch.where(
        valid_inverse[:, None, None], local_inverses, diagonal_inverse
    )
    products = products.repeat(3, 1)
    patterns = patterns.repeat(3, 1)

    block_systems = torch.stack(
        [
            hessian[index:index + 64, index:index + 64]
            for index in range(0, channels, 64)
        ]
    )
    block_systems += torch.diag_embed(
        diagonal.reshape(-1, 64)
    ) * 0.01
    block_inverses, block_info = torch.linalg.inv_ex(block_systems)
    valid_block = (
        (block_info == 0)
        & torch.isfinite(block_inverses).all(dim=(1, 2))
    )
    block_inverses = torch.where(
        valid_block[:, None, None],
        block_inverses,
        torch.diag_embed(diagonal.reshape(-1, 64).reciprocal()),
    )
    batch = torch.arange(rows)

    for _ in range(0):
        for block in range(blocks):
            start = block * 64
            end = start + 64
            block_hessian = hessian[start:end, start:end]
            old = quantized[:, start:end]
            shift = gradient[:, start:end] @ block_inverses[block]
            bound = step[:, start:end] * 2.0
            center = old + torch.maximum(torch.minimum(shift, bound), -bound)
            base, local_level2, local_level3, local_codes, local_step = (
                _fusion_scale_proposal(
                    center, scale_factor[:, block], diagonal[start:end]
                )
            )
            delta = local_codes * local_step - old
            cost = (
                (delta @ block_hessian) * delta
                - 2 * delta * gradient[:, start:end]
            ).sum(1)
            accepted = cost < -1.0e-12
            delta = torch.where(accepted[:, None], delta, 0.0)
            scale_factor[:, block] = torch.where(
                accepted, base, scale_factor[:, block]
            )
            level2[:, block] = torch.where(
                accepted[:, None], local_level2, level2[:, block]
            )
            level3[:, block] = torch.where(
                accepted[:, None, None], local_level3, level3[:, block]
            )
            codes[:, start:end] = torch.where(
                accepted[:, None], local_codes, codes[:, start:end]
            )
            step[:, start:end] = torch.where(
                accepted[:, None], local_step, step[:, start:end]
            )
            quantized[:, start:end] += delta
            gradient -= delta @ hessian[start:end]

            block_gradient = gradient[:, start:end].clone()
            block_delta = torch.zeros((rows, 64), dtype=torch.float32)
            for group in range(8):
                local_start = group * 8
                local_end = local_start + 8
                selected = slice(start + local_start, start + local_end)
                local_hessian = block_hessian[
                    local_start:local_end, local_start:local_end
                ]
                local_gradient = block_gradient[:, local_start:local_end]
                old = quantized[:, selected]
                candidate_step = (
                    scale_factor[:, block][None, :, None]
                    * products[:, None]
                    * 0.25
                )
                coupled = local_gradient @ local_inverses[block * 8 + group]
                centers = torch.cat(
                    (
                        (old + coupled)[None].expand(8, -1, -1),
                        ((old + coupled) / 0.96)[None].expand(8, -1, -1),
                        ((old + coupled) / 1.04)[None].expand(8, -1, -1),
                    ),
                    dim=0,
                )
                candidate_codes = (
                    centers / candidate_step
                ).round().clamp(-7.0, 7.0)
                candidate_delta = candidate_codes * candidate_step - old[None]
                objective = -2.0 * (
                    candidate_delta * local_gradient[None]
                ).sum(dim=2)
                objective += (
                    (candidate_delta @ local_hessian) * candidate_delta
                ).sum(dim=2)
                best = objective.argmin(dim=0)
                accepted = objective[best, batch] < -1.0e-12
                change = torch.where(
                    accepted[:, None], candidate_delta[best, batch], 0.0
                )
                codes[:, selected] = torch.where(
                    accepted[:, None],
                    candidate_codes[best, batch],
                    codes[:, selected],
                )
                step[:, selected] = torch.where(
                    accepted[:, None],
                    candidate_step[best, batch],
                    step[:, selected],
                )
                chosen = patterns[best]
                level2[:, block, group] = torch.where(
                    accepted, chosen[:, 0], level2[:, block, group]
                )
                level3[:, block, group] = torch.where(
                    accepted[:, None],
                    chosen[:, 1:],
                    level3[:, block, group],
                )
                quantized[:, selected] += change
                block_delta[:, local_start:local_end] = change
                block_gradient -= change @ block_hessian[
                    local_start:local_end
                ]
            gradient -= block_delta @ hessian[start:end]

    codes = _fusion_greedy_codes(
        codes, step, gradient, hessian, iterations=4
    )
    # Omit the low-gain cooperative tail; retain block/group and greedy refinement.
    result = dict(params)
    result["scale_factor"] = scale_factor.reshape(
        params["scale_factor"].shape
    ).to(torch.bfloat16)
    result["scale_lv2"] = level2.reshape(
        params["scale_lv2"].shape
    ).to(torch.bfloat16)
    result["scale_lv3"] = level3.reshape(
        params["scale_lv3"].shape
    ).to(torch.bfloat16)
    result["sign"] = torch.sign(codes).reshape(
        params["sign"].shape
    ).to(torch.bfloat16)
    result["mant"] = (codes.abs() * 0.25).reshape(
        params["mant"].shape
    ).to(torch.bfloat16)
    return result


_v31_refine_linear_hierarchy = _fusion_linear_hierarchy
# Process-independent short-K hierarchy refinement. The ordinary low-rank
# rounding stage changes mantissa/sign codes on a fixed hierarchy. For short
# sequences we can afford to revisit each legal level-2/level-3 group and then
# the complete Block64 base scale. Every proposal must decrease the calibrated
# low-rank quadratic. This depends only on K and k_state, so it is valid when
# Q/K/V callbacks execute in separate workers.
_AGG_KHIER_PARENT_LOW_RANK = _quantize_low_rank
_AGG_KHIER_PARENT_K = hif4_dynamic_quantize_k
_AGG_KHIER_MAX_ROWS = 127
_AGG_KHIER_PASSES = 1
_AGG_KHIER_GROUP_CHUNK = 2048
_AGG_KHIER_MIN_GAIN = 1.0e-12


def _agg_khier_group(value, rows, num_heads, kv_heads, trailing):
    per_kv = int(num_heads) // int(kv_heads)
    axes = (1, 0, 2) + tuple(range(3, 3 + len(trailing)))
    return value.reshape(rows, kv_heads, per_kv, *trailing).permute(axes).reshape(
        kv_heads, rows * per_kv, *trailing
    ).contiguous()


def _agg_khier_ungroup(value, rows, num_heads, kv_heads, trailing):
    per_kv = int(num_heads) // int(kv_heads)
    axes = (1, 0, 2) + tuple(range(3, 3 + len(trailing)))
    return value.reshape(kv_heads, rows, per_kv, *trailing).permute(axes).reshape(
        rows, num_heads, *trailing
    ).contiguous()


def _agg_refine_k_hierarchy(tensor, params, num_heads, head_dim, state):
    if tensor.ndim != 2 or int(head_dim) <= 0 or int(head_dim) % 64 or not state:
        return params
    rows = int(tensor.shape[0])
    num_heads = int(num_heads)
    head_dim = int(head_dim)
    kv_heads = int(state["kv_num_heads"])
    if (rows <= 0 or rows > int(_AGG_KHIER_MAX_ROWS) or kv_heads <= 0
            or num_heads % kv_heads or int(tensor.shape[1]) != num_heads * head_dim):
        return params
    factors, diagonals, _, _ = _joint_select_terms(state, rows)
    if (tuple(factors.shape[::2]) != (kv_heads, head_dim)
            or tuple(diagonals.shape) != (kv_heads, head_dim)
            or not bool(torch.isfinite(factors).all())
            or not bool(torch.isfinite(diagonals).all())):
        return params

    blocks = head_dim // 64

    def group(value, trailing):
        return _agg_khier_group(value, rows, num_heads, kv_heads, trailing)

    target = group(tensor.to(torch.float32), (head_dim,))
    values = group(dequantize_hif4(params).to(torch.float32), (head_dim,))
    codes = group(
        (params["sign"].to(torch.float32) * params["mant"].to(torch.float32) * 4.0).round(),
        (head_dim,),
    )
    sf = group(params["scale_factor"].to(torch.float32), (blocks,)).clone()
    lv2 = group(params["scale_lv2"].to(torch.float32), (blocks, 8)).clone()
    lv3 = group(params["scale_lv3"].to(torch.float32), (blocks, 8, 2)).clone()
    hdiag = (factors.square().sum(1) + diagonals).clamp_min(1.0e-20)
    patterns = tensor.new_tensor(
        [[a, b, c] for a in (1.0, 2.0) for b in (1.0, 2.0) for c in (1.0, 2.0)],
        dtype=torch.float32,
    )
    products = (patterns[:, :1] * patterns[:, 1:]).repeat_interleave(4, dim=1)
    chunk_size = max(1, int(_AGG_KHIER_GROUP_CHUNK))
    hessian_blocks = []
    for block in range(blocks):
        begin, end = block * 64, (block + 1) * 64
        factor_block = factors[:, :, begin:end]
        hessian_blocks.append(
            torch.bmm(factor_block.transpose(1, 2), factor_block)
            + torch.diag_embed(diagonals[:, begin:end])
        )

    for row_start in range(0, int(target.shape[1]), chunk_size):
        row_end = min(int(target.shape[1]), row_start + chunk_size)
        current = values[:, row_start:row_end]
        current_codes = codes[:, row_start:row_end]
        current_sf = sf[:, row_start:row_end]
        error = target[:, row_start:row_end] - current
        projected = torch.bmm(error, factors.transpose(1, 2))
        for _ in range(int(_AGG_KHIER_PASSES)):
            for block in range(blocks):
                begin, end = block * 64, (block + 1) * 64
                factor_block = factors[:, :, begin:end]
                block_hessian = hessian_blocks[block]
                gradient = (
                    torch.bmm(projected, factor_block)
                    + error[:, :, begin:end] * diagonals[:, None, begin:end]
                )
                block_delta = torch.zeros_like(current[:, :, begin:end])
                for local_group in range(8):
                    local_begin, local_end = local_group * 8, (local_group + 1) * 8
                    channels = slice(begin + local_begin, begin + local_end)
                    local_hessian = block_hessian[:, local_begin:local_end, local_begin:local_end]
                    local_gradient = gradient[:, :, local_begin:local_end]
                    old = current[:, :, channels]
                    center = old + local_gradient / hdiag[:, None, channels]
                    candidate_step = (
                        current_sf[:, None, :, block, None] * products[None, :, None, :] * 0.25
                    )
                    candidate_codes = (
                        center[:, None] / candidate_step.clamp_min(1.0e-30)
                    ).round().clamp(-7.0, 7.0)
                    delta = candidate_codes * candidate_step - old[:, None]
                    objectives = (
                        -2.0 * (delta * local_gradient[:, None]).sum(-1)
                        + ((delta @ local_hessian[:, None]) * delta).sum(-1)
                    )
                    best = objectives.argmin(dim=1)
                    best_index = best[:, None, :, None].expand(-1, 1, -1, 8)
                    best_objective = objectives.gather(1, best[:, None]).squeeze(1)
                    accepted = best_objective < -float(_AGG_KHIER_MIN_GAIN)
                    change = torch.where(
                        accepted[:, :, None], delta.gather(1, best_index).squeeze(1), 0.0
                    )
                    new_codes = candidate_codes.gather(1, best_index).squeeze(1)
                    current_codes[:, :, channels] = torch.where(
                        accepted[:, :, None], new_codes, current_codes[:, :, channels]
                    )
                    chosen = patterns[best]
                    lv2[:, row_start:row_end, block, local_group] = torch.where(
                        accepted, chosen[:, :, 0], lv2[:, row_start:row_end, block, local_group]
                    )
                    lv3[:, row_start:row_end, block, local_group] = torch.where(
                        accepted[:, :, None], chosen[:, :, 1:], lv3[:, row_start:row_end, block, local_group]
                    )
                    current[:, :, channels] += change
                    error[:, :, channels] -= change
                    block_delta[:, :, local_begin:local_end] = change
                    gradient -= torch.bmm(change, block_hessian[:, local_begin:local_end])
                projected -= torch.bmm(block_delta, factor_block.transpose(1, 2))

                # Re-encode the whole Block64 around a bounded Newton step and
                # accept it against the exact local low-rank quadratic.
                old = current[:, :, begin:end]
                local_weight = hdiag[:, None, begin:end].expand_as(old)
                local_lv2 = lv2[:, row_start:row_end, block]
                local_lv3 = lv3[:, row_start:row_end, block]
                old_step = (
                    current_sf[:, :, block, None, None, None]
                    * local_lv2[:, :, :, None, None]
                    * local_lv3[:, :, :, :, None]
                    * 0.25
                ).expand(-1, -1, -1, -1, 4).reshape_as(old)
                shift = (gradient / local_weight).clamp(-2.0 * old_step, 2.0 * old_step)
                proposed_sf, e2, e3, mant, sign = _encode_blocks(
                    (old + shift).reshape(-1, 64),
                    chunk_blocks=256,
                    channel_weight=local_weight.reshape(-1, 64),
                )
                proposed_codes = (mant.to(torch.float32) * sign).reshape_as(old)
                proposed_lv2 = torch.pow(2.0, e2.to(torch.float32)).reshape_as(local_lv2)
                proposed_lv3 = torch.pow(2.0, e3.to(torch.float32)).reshape_as(local_lv3)
                proposed_sf = proposed_sf.reshape(old.shape[:2])
                proposed_step = (
                    proposed_sf[:, :, None, None, None]
                    * proposed_lv2[:, :, :, None, None]
                    * proposed_lv3[:, :, :, :, None]
                    * 0.25
                ).expand(-1, -1, -1, -1, 4).reshape_as(old)
                delta = proposed_codes * proposed_step - old
                cost = (
                    -2.0 * (delta * gradient).sum(-1)
                    + (torch.bmm(delta, block_hessian) * delta).sum(-1)
                )
                accepted = cost < -float(_AGG_KHIER_MIN_GAIN)
                change = torch.where(accepted[:, :, None], delta, 0.0)
                current[:, :, begin:end] += change
                error[:, :, begin:end] -= change
                current_codes[:, :, begin:end] = torch.where(
                    accepted[:, :, None], proposed_codes, current_codes[:, :, begin:end]
                )
                current_sf[:, :, block] = torch.where(
                    accepted, proposed_sf, current_sf[:, :, block]
                )
                lv2[:, row_start:row_end, block] = torch.where(
                    accepted[:, :, None], proposed_lv2, local_lv2
                )
                lv3[:, row_start:row_end, block] = torch.where(
                    accepted[:, :, None, None], proposed_lv3, local_lv3
                )
                projected -= torch.bmm(change, factor_block.transpose(1, 2))

    result = dict(params)
    result["scale_factor"] = _agg_khier_ungroup(
        sf, rows, num_heads, kv_heads, (blocks,)
    ).reshape(params["scale_factor"].shape).to(torch.bfloat16)
    result["scale_lv2"] = _agg_khier_ungroup(
        lv2, rows, num_heads, kv_heads, (blocks, 8)
    ).reshape(params["scale_lv2"].shape).to(torch.bfloat16)
    result["scale_lv3"] = _agg_khier_ungroup(
        lv3, rows, num_heads, kv_heads, (blocks, 8, 2)
    ).reshape(params["scale_lv3"].shape).to(torch.bfloat16)
    restored_codes = _agg_khier_ungroup(
        codes, rows, num_heads, kv_heads, (head_dim,)
    ).reshape(tensor.shape)
    return _pack_signed_codes(result, restored_codes)


def _quantize_low_rank(tensor, num_heads, head_dim, state):
    params = _AGG_KHIER_PARENT_LOW_RANK(tensor, num_heads, head_dim, state)
    if not state.get("agg_khier_enabled", False):
        return params
    try:
        return _agg_refine_k_hierarchy(tensor, params, num_heads, head_dim, state)
    except (RuntimeError, ValueError, IndexError, KeyError, TypeError):
        return params


def hif4_dynamic_quantize_k(k_quant, k_scale, kv_num_heads, head_dim, k_state):
    state = dict(k_state)
    state["agg_khier_enabled"] = int(k_quant.shape[0]) <= int(_AGG_KHIER_MAX_ROWS)
    return _AGG_KHIER_PARENT_K(k_quant, k_scale, kv_num_heads, head_dim, state)


# Symmetric cross-interface-free Q repair. Calibration K/K-transform
# prototypes live in q_state. At runtime Q selects an exact-length prototype
# using Q-only statistics and minimizes prototype softmax cross entropy. This
# is the Q-side counterpart of the already scored KPR path.
_QPR_PARENT_CAL = hif4_calibration_attention
_QPR_PARENT_Q = hif4_dynamic_quantize_q
_QPR_KEY_ROWS = 256
_QPR_ENSEMBLE_EXACT_PROTOTYPES = 0
_QPR_GROUP_SIZE = 8
_QPR_GROUPS_SHORT = 1
_QPR_GROUPS_LONG = 1
_QPR_TOKEN_BUDGET = 640
_QPR_ENABLED = 0
_QPR_ENABLE_SHORT_HIERARCHY = 1


def _qpr_indices(rows, device):
    count = int(_QPR_KEY_ROWS)
    if int(rows) == count:
        return torch.arange(int(rows), dtype=torch.long, device=device)
    return torch.linspace(0, int(rows) - 1, count, device=device).round().to(torch.long)


def _qpr_descriptor(q, q_num_heads, kv_num_heads, head_dim):
    rows = int(q.shape[0])
    del kv_num_heads
    heads = q.to(torch.float32).reshape(rows, int(q_num_heads), int(head_dim))
    value = heads.square().mean(dim=0).clamp_min(1.0e-20).log()
    value = value.reshape(int(q_num_heads), int(head_dim) // 8, 8).mean(dim=2)
    return (value - value.mean(dim=1, keepdim=True)).contiguous()


def hif4_calibration_attention(calib_qkv_list, q_num_heads, kv_num_heads, head_dim):
    result = _QPR_PARENT_CAL(calib_qkv_list, q_num_heads, kv_num_heads, head_dim)
    if not bool(_QPR_ENABLED):
        return result
    references = []
    transformed = []
    descriptors = []
    lengths = []
    for sample in calib_qkv_list:
        rows = int(sample["q"][0].shape[0])
        indices = _qpr_indices(rows, sample["k"][0].device)
        k_reference = dequantize_nvfp4(*sample["k"]).to(torch.float32)
        k_transformed = center_attention_k(k_reference, kv_num_heads, head_dim)
        k_transformed = transform_attention_k_structured(
            k_transformed, kv_num_heads, head_dim, result["k_state"]
        )
        k_transformed = apply_attention_extra_transform(
            k_transformed, kv_num_heads, head_dim, result["k_state"]
        )
        references.append(
            k_reference.reshape(rows, int(kv_num_heads), int(head_dim))
            .index_select(0, indices)
            .permute(1, 0, 2)
            .to(torch.bfloat16)
        )
        transformed.append(
            k_transformed.reshape(rows, int(kv_num_heads), int(head_dim))
            .index_select(0, indices)
            .permute(1, 0, 2)
            .to(torch.bfloat16)
        )
        q_reference = dequantize_nvfp4(*sample["q"]).to(torch.float32)
        descriptors.append(_qpr_descriptor(q_reference, q_num_heads, kv_num_heads, head_dim))
        lengths.append(rows)
    state = dict(result["q_state"])
    if references:
        state["qpr_k_reference"] = torch.stack(references, dim=0).contiguous()
        state["qpr_k_transformed"] = torch.stack(transformed, dim=0).contiguous()
        state["qpr_q_descriptor"] = torch.stack(descriptors, dim=0).contiguous()
        state["qpr_lengths"] = torch.tensor(lengths, dtype=torch.long)
        state["qpr_q_num_heads"] = int(q_num_heads)
    result["q_state"] = state
    return result


def _qpr_select_prototype(q_raw, q_num_heads, kv_num_heads, head_dim, q_state):
    rows = int(q_raw.shape[0])
    descriptor = _qpr_descriptor(q_raw, q_num_heads, kv_num_heads, head_dim)
    distance = (
        q_state["qpr_q_descriptor"].to(torch.float32) - descriptor[None, :, :]
    ).square().mean(dim=2)
    lengths = q_state["qpr_lengths"].to(torch.long)
    exact = lengths.eq(rows)
    q_per_kv = int(q_num_heads) // int(kv_num_heads)
    kv_index = (
        torch.arange(int(q_num_heads), dtype=torch.long, device=distance.device)
        // q_per_kv
    )
    if bool(_QPR_ENSEMBLE_EXACT_PROTOTYPES) and int(exact.sum().item()) >= 2:
        exact_indices = torch.nonzero(exact, as_tuple=False).flatten()
        exact_distance = distance.index_select(0, exact_indices)
        order = exact_distance.argsort(dim=0)
        take = min(2, int(exact_indices.numel()))
        references = []
        transformed = []
        for rank in range(take):
            selected = exact_indices.index_select(0, order[rank])
            references.append(
                q_state["qpr_k_reference"][selected, kv_index].to(torch.float32)
            )
            transformed.append(
                q_state["qpr_k_transformed"][selected, kv_index].to(torch.float32)
            )
        k_reference = torch.cat(references, dim=1)
        k_transformed = torch.cat(transformed, dim=1)
        return (k_reference, k_transformed)
    if bool(exact.any()):
        distance = distance + (~exact)[:, None].to(distance.dtype) * 1.0e6
    else:
        # Unknown hidden lengths use the closest calibration scale before the
        # distribution descriptor breaks ties.
        relative = (
            lengths.to(torch.float32).clamp_min(1.0).log() - math.log(max(rows, 1))
        ).abs()
        distance = distance + relative[:, None] * 8.0
    selected = distance.argmin(dim=0)
    k_reference = q_state["qpr_k_reference"][selected, kv_index].to(torch.float32)
    k_transformed = q_state["qpr_k_transformed"][selected, kv_index].to(torch.float32)
    return (k_reference, k_transformed)


def _qpr_repair(q_reference, q_current, k_reference, k_transformed, step, code, groups):
    head_count, rows, head_dim = q_reference.shape
    root_dim = math.sqrt(float(head_dim))
    current_code = code.to(torch.float32).clone()
    reference_probability = torch.softmax(
        torch.bmm(q_reference, k_reference.transpose(1, 2)) / root_dim, dim=2
    )
    probability = torch.softmax(
        torch.bmm(q_current, k_transformed.transpose(1, 2)) / root_dim, dim=2
    )
    left = _KPR_SH2_LEFT.to(device=q_reference.device)
    right = _KPR_SH2_RIGHT.to(device=q_reference.device)
    patterns = _KPR_PATTERNS.to(device=q_reference.device, dtype=torch.float32)

    for group_index in range(int(groups.shape[1])):
        columns = groups[:, group_index, :]
        key_index = columns[:, None, :].expand(head_count, int(k_transformed.shape[1]), int(_QPR_GROUP_SIZE))
        token_index = columns[:, None, :].expand(head_count, rows, int(_QPR_GROUP_SIZE))
        k_group = torch.gather(k_transformed, 2, key_index)
        group_gradient = torch.bmm(probability - reference_probability, k_group) / root_dim

        mean = torch.bmm(probability, k_group)
        pair_keys = k_group.index_select(2, left) * k_group.index_select(2, right)
        curvature_keys = torch.cat((k_group.square(), pair_keys), dim=2)
        moments = torch.bmm(probability, curvature_keys)
        token_diagonal = (
            moments[:, :, :int(_QPR_GROUP_SIZE)] - mean.square()
        ).div(float(head_dim)).clamp_min(1.0e-20)
        token_pair = (
            moments[:, :, int(_QPR_GROUP_SIZE):]
            - mean.index_select(2, left) * mean.index_select(2, right)
        ).div(float(head_dim))

        group_step = torch.gather(step, 2, token_index)
        group_code = torch.gather(current_code, 2, token_index)
        raw_jump = torch.round(
            -group_gradient / (token_diagonal * group_step).clamp_min(1.0e-30)
        ).clamp(-1.0, 1.0)
        fallback = torch.where(
            group_gradient > 0.0,
            -torch.ones_like(raw_jump),
            torch.ones_like(raw_jump),
        )
        jump = torch.where(raw_jump == 0.0, fallback, raw_jump)
        jump = torch.maximum(
            torch.minimum(jump, 7.0 - group_code), -7.0 - group_code
        )
        proposal_delta = jump * group_step
        costs = _kpr_sparse_hamming2_costs(
            proposal_delta, group_gradient, token_diagonal, token_pair
        )
        best = costs.argmin(dim=0)
        best_cost = torch.gather(costs, 0, best[None, :, :]).squeeze(0)
        chosen = (
            patterns.index_select(0, best.reshape(-1))
            .reshape(head_count, rows, int(_QPR_GROUP_SIZE))
            * proposal_delta
        )
        if int(_QPR_TOKEN_BUDGET) < rows:
            selected_tokens = best_cost.topk(
                int(_QPR_TOKEN_BUDGET), dim=1, largest=False, sorted=True
            ).indices
            token_mask = torch.zeros(
                (head_count, rows), dtype=torch.bool, device=chosen.device
            )
            token_mask.scatter_(1, selected_tokens, True)
            chosen = torch.where(token_mask[:, :, None], chosen, 0.0)
        chosen = torch.where(best_cost[:, :, None] < 0.0, chosen, 0.0)

        logit_delta = torch.bmm(chosen, k_group.transpose(1, 2)) / root_dim
        ratio = probability * torch.exp(logit_delta)
        normalizer = ratio.sum(dim=2, keepdim=True).clamp_min(1.0e-30)
        loss_delta = -(reference_probability * logit_delta).sum(dim=2)
        loss_delta += torch.log(normalizer.squeeze(2))
        accept = loss_delta < -1.0e-12
        candidate_probability = ratio / normalizer
        probability = torch.where(
            accept[:, :, None], candidate_probability, probability
        )
        chosen = torch.where(accept[:, :, None], chosen, 0.0)
        new_code = torch.round(
            group_code + chosen / group_step.clamp_min(1.0e-30)
        ).clamp(-7.0, 7.0)
        current_code.scatter_(2, token_index, new_code)
        q_current = q_current.clone()
        q_current.scatter_(
            2,
            token_index,
            torch.gather(q_current, 2, token_index) + chosen,
        )
    return current_code.to(torch.int8)


def hif4_dynamic_quantize_q(q_quant, q_scale, q_num_heads, head_dim, q_state):
    state = dict(q_state)
    rows = int(q_quant.shape[0])
    state["agg_khier_enabled"] = (
        bool(_QPR_ENABLE_SHORT_HIERARCHY) and rows < 128
    )
    params = _QPR_PARENT_Q(q_quant, q_scale, q_num_heads, head_dim, state)
    if not bool(_QPR_ENABLED) or "qpr_k_reference" not in state or rows == 512:
        return params
    kv_num_heads = int(state["kv_num_heads"])
    q_raw = dequantize_nvfp4(q_quant, q_scale).to(torch.float32)
    k_reference, k_transformed = _qpr_select_prototype(
        q_raw, q_num_heads, kv_num_heads, head_dim, state
    )
    q_reference = q_raw.reshape(rows, int(q_num_heads), int(head_dim)).permute(1, 0, 2).contiguous()
    q_current = dequantize_hif4(params).to(torch.float32).reshape(
        rows, int(q_num_heads), int(head_dim)
    ).permute(1, 0, 2).contiguous()
    step = _grid_step(params, tuple(int(value) for value in q_quant.shape)).reshape(
        rows, int(q_num_heads), int(head_dim)
    ).permute(1, 0, 2).contiguous()
    codes = torch.round(
        params["sign"].to(torch.float32) * params["mant"].to(torch.float32) * 4.0
    ).to(torch.int8).reshape(
        rows, int(q_num_heads), int(head_dim)
    ).permute(1, 0, 2).contiguous()
    _, _, _, parent_groups = _joint_select_terms(state, rows)
    selected_groups = (
        int(_QPR_GROUPS_SHORT) if rows < 512 else int(_QPR_GROUPS_LONG)
    )
    usable = int(_QPR_GROUP_SIZE) * selected_groups
    groups = parent_groups.reshape(kv_num_heads, -1)[:, :usable].reshape(
        kv_num_heads, selected_groups, int(_QPR_GROUP_SIZE)
    )
    q_per_kv = int(q_num_heads) // kv_num_heads
    groups = groups.repeat_interleave(q_per_kv, dim=0)
    repaired = _qpr_repair(
        q_reference, q_current, k_reference, k_transformed, step, codes, groups
    )
    return _pack_signed_codes(
        params, repaired.permute(1, 0, 2).reshape(q_quant.shape)
    )
# ---- agent-vcross bounded-cost calibration-only real-output fit for V ----
# The online evaluator may invoke Q/K/V with independent copies of state, so
# this version stores only a compact operator in v_state. During calibration
# it chooses the largest sample with at most 512 rows, reconstructs the real
# attention probability P and a cheap deployment-matched P_hat, then fits
# T = I + B C B.T such that P_hat T ~= P. Dynamic V applies T to the current
# real V before the unchanged v29 V quantizer. There is no global cache and
# no dependency on Q/K/V call order.
_agent_vcross_parent_calibration_attention = hif4_calibration_attention
_agent_vcross_parent_dynamic_quantize_v = hif4_dynamic_quantize_v
_AGENT_VCROSS_MAX_FIT_ROWS = 512
_AGENT_VCROSS_RANK = 64
_AGENT_VCROSS_RIDGE_RATIO = 1.0
_AGENT_VCROSS_SHRINK = 1.0
_AGENT_VCROSS_MAX_RELATIVE_CORRECTION = 0.10


def _agent_vcross_dct_basis(rows, rank):
    rank = min(int(rank), int(rows))
    position = torch.arange(rows, dtype=torch.float32)[:, None]
    frequency = torch.arange(rank, dtype=torch.float32)[None, :]
    basis = torch.cos(
        math.pi * (position + 0.5) * frequency / float(rows)
    )
    basis[:, 0] *= math.sqrt(1.0 / float(rows))
    if rank > 1:
        basis[:, 1:] *= math.sqrt(2.0 / float(rows))
    return basis.contiguous()


def _agent_vcross_fast_deployed_qk(
    sample, q_state, k_state, q_num_heads, kv_num_heads, head_dim
):
    q = dequantize_nvfp4(*sample["q"]).to(torch.float32)
    k = dequantize_nvfp4(*sample["k"]).to(torch.float32)
    q = transform_attention_q_structured(q, q_num_heads, head_dim, q_state)
    q = apply_attention_extra_transform(q, q_num_heads, head_dim, q_state)
    k = center_attention_k(k, kv_num_heads, head_dim)
    k = transform_attention_k_structured(k, kv_num_heads, head_dim, k_state)
    k = apply_attention_extra_transform(k, kv_num_heads, head_dim, k_state)
    q_hat = dequantize_hif4(
        _quantize_attention_hierarchy_grid(
            q, q_num_heads, head_dim, q_state
        )
    ).reshape_as(q)
    k_hat = dequantize_hif4(
        _quantize_attention_hierarchy_grid(
            k, kv_num_heads, head_dim, k_state
        )
    ).reshape_as(k)
    return q_hat, k_hat


def _agent_vcross_fit_v_operator(
    calib_qkv_list,
    q_num_heads,
    kv_num_heads,
    head_dim,
    q_state,
    k_state,
):
    candidates = [
        sample
        for sample in calib_qkv_list
        if int(sample["q"][0].shape[0]) <= int(_AGENT_VCROSS_MAX_FIT_ROWS)
    ]
    if not candidates:
        return {
            "agent_vcross_enabled": False,
            "agent_vcross_policy": "v29-fallback-no-bounded-calibration-sample",
        }
    # A single longest bounded sample gave the best gain/cost ratio locally.
    sample = max(candidates, key=lambda item: int(item["q"][0].shape[0]))
    rows = int(sample["q"][0].shape[0])
    rank = min(int(_AGENT_VCROSS_RANK), rows)
    group_size = int(q_num_heads) // int(kv_num_heads)
    if group_size <= 0 or group_size * int(kv_num_heads) != int(q_num_heads):
        return {
            "agent_vcross_enabled": False,
            "agent_vcross_policy": "v29-fallback-invalid-head-grouping",
        }

    with torch.no_grad():
        basis = _agent_vcross_dct_basis(rows, rank)
        real_q = dequantize_nvfp4(*sample["q"]).to(torch.float32)
        real_k = dequantize_nvfp4(*sample["k"]).to(torch.float32)
        q_hat, k_hat = _agent_vcross_fast_deployed_qk(
            sample,
            q_state,
            k_state,
            q_num_heads,
            kv_num_heads,
            head_dim,
        )
        real_q = real_q.reshape(
            rows, int(q_num_heads), int(head_dim)
        ).transpose(0, 1)
        real_k = real_k.reshape(
            rows, int(kv_num_heads), int(head_dim)
        ).transpose(0, 1)
        q_hat = q_hat.reshape(
            rows, int(q_num_heads), int(head_dim)
        ).transpose(0, 1)
        k_hat = k_hat.reshape(
            rows, int(kv_num_heads), int(head_dim)
        ).transpose(0, 1)
        gram = torch.zeros(
            int(kv_num_heads), rank, rank, dtype=torch.float32
        )
        cross = torch.zeros_like(gram)
        residual_energy = torch.zeros(
            int(kv_num_heads), dtype=torch.float32
        )
        row_weight = 1.0 / float(max(rows, 1))
        scale = math.sqrt(float(head_dim))
        for kv_head in range(int(kv_num_heads)):
            head_start = kv_head * group_size
            head_end = head_start + group_size
            real_logits = torch.matmul(
                real_q[head_start:head_end], real_k[kv_head].T
            ) / scale
            deployed_logits = torch.matmul(
                q_hat[head_start:head_end], k_hat[kv_head].T
            ) / scale
            real_probability = torch.softmax(real_logits, dim=-1)
            deployed_probability = torch.softmax(deployed_logits, dim=-1)
            design = torch.matmul(deployed_probability, basis)
            residual = torch.matmul(
                real_probability - deployed_probability, basis
            )
            # Fold grouped Q heads into one least-squares system per KV head.
            design = design.reshape(-1, rank)
            residual = residual.reshape(-1, rank)
            gram[kv_head] = (design.T @ design) * row_weight
            cross[kv_head] = (design.T @ residual) * row_weight
            residual_energy[kv_head] = (
                residual.square().sum() * row_weight
            )

        coefficients = torch.zeros_like(gram)
        projected_gain = torch.zeros(
            int(kv_num_heads), dtype=torch.float32
        )
        eye = torch.eye(rank, dtype=torch.float32)
        for kv_head in range(int(kv_num_heads)):
            mean_diagonal = torch.diagonal(
                gram[kv_head]
            ).mean().clamp_min(1.0e-8)
            ridge = mean_diagonal * float(_AGENT_VCROSS_RIDGE_RATIO)
            try:
                coefficient = torch.linalg.solve(
                    gram[kv_head] + ridge * eye, cross[kv_head]
                )
            except RuntimeError:
                coefficient = torch.zeros_like(cross[kv_head])
            coefficient *= float(_AGENT_VCROSS_SHRINK)
            if not bool(torch.isfinite(coefficient).all()):
                coefficient.zero_()
            gain = 2.0 * (coefficient * cross[kv_head]).sum()
            gain -= torch.einsum(
                "ij,ik,kj->", coefficient, gram[kv_head], coefficient
            )
            if float(gain) <= 0.0:
                coefficient.zero_()
                gain.zero_()
            coefficients[kv_head] = coefficient
            projected_gain[kv_head] = gain

    enabled = bool(coefficients.abs().sum() > 0.0)
    return {
        "agent_vcross_enabled": enabled,
        "agent_vcross_coefficients": coefficients.contiguous(),
        "agent_vcross_rank": int(rank),
        "agent_vcross_fit_rows": int(rows),
        "agent_vcross_projected_relative_gain": (
            projected_gain / residual_energy.clamp_min(1.0e-30)
        ).contiguous(),
        "agent_vcross_max_relative_correction": float(
            _AGENT_VCROSS_MAX_RELATIVE_CORRECTION
        ),
        "agent_vcross_policy": "single-largest-calibration-sample-at-most-512-dct64-aggressive",
        "agent_vcross_target": (
            "P_hat@(I+B@C@B.T)~=P; isolated-call-safe real-output fit"
        ),
    }


def hif4_calibration_attention(
    calib_qkv_list, q_num_heads, kv_num_heads, head_dim
):
    result = _agent_vcross_parent_calibration_attention(
        calib_qkv_list, q_num_heads, kv_num_heads, head_dim
    )
    try:
        fit = _agent_vcross_fit_v_operator(
            calib_qkv_list,
            q_num_heads,
            kv_num_heads,
            head_dim,
            result["q_state"],
            result["k_state"],
        )
    except Exception:
        fit = {
            "agent_vcross_enabled": False,
            "agent_vcross_policy": "v29-fallback-calibration-fit-failed",
        }
    result["v_state"].update(fit)
    return result


def _agent_vcross_transform_v(
    v, coefficients, kv_num_heads, head_dim, maximum_relative
):
    coefficients = coefficients.to(torch.float32)
    rows = int(v.shape[0])
    if (
        coefficients.ndim != 3
        or int(coefficients.shape[0]) != int(kv_num_heads)
        or int(v.shape[1]) != int(kv_num_heads) * int(head_dim)
    ):
        return v
    rank = min(int(coefficients.shape[-1]), rows)
    coefficients = coefficients[:, :rank, :rank]
    basis = _agent_vcross_dct_basis(rows, rank)
    heads = v.reshape(rows, int(kv_num_heads), int(head_dim))
    projected = torch.einsum("lr,lhd->rhd", basis, heads)
    correction_modes = torch.einsum(
        "hij,jhd->ihd", coefficients, projected
    )
    correction = torch.einsum("lr,rhd->lhd", basis, correction_modes)
    base_norm = heads.square().sum().sqrt().clamp_min(1.0e-20)
    correction_norm = correction.square().sum().sqrt()
    relative = correction_norm / base_norm
    if not bool(torch.isfinite(relative)):
        return v
    if float(relative) > float(maximum_relative):
        correction *= float(maximum_relative) / float(relative)
    transformed = heads + correction
    if not bool(torch.isfinite(transformed).all()):
        return v
    return transformed.reshape_as(v)


def _agent_vcross_quantize_raw_v(v, v_state):
    window = int(v_state.get("v_local_window", V_LOCAL_WINDOW))
    mean_penalty = float(
        v_state.get("v_local_mean_penalty", V_LOCAL_MEAN_PENALTY)
    )
    mode_penalty = float(
        v_state.get("v_local_mode_penalty", V_LOCAL_MODE_PENALTY)
    )
    mode_count = int(v_state.get("v_local_mode_count", V_LOCAL_MODE_COUNT))
    long_minimum = int(
        v_state.get("v_long_sequence_min_rows", V_LONG_SEQUENCE_MIN_ROWS)
    )
    long_window = int(v_state.get("v_long_window", V_LONG_WINDOW))
    long_modes = int(v_state.get("v_long_mode_count", V_LONG_MODE_COUNT))
    output_minimum = int(v_state.get("v_output_shape_min_rows", 512))
    search_multipliers = DEFAULT_SEARCH_MULTIPLIERS
    max_steps = None
    position_weight_strength = 0.0
    if int(v.shape[0]) >= long_minimum:
        window = long_window
        mode_count = long_modes
    if int(v.shape[0]) >= output_minimum:
        search_multipliers = tuple(
            float(value)
            for value in v_state.get(
                "v_output_shape_search_multipliers",
                DEFAULT_SEARCH_MULTIPLIERS,
            )
        )
        window = int(v_state.get("v_output_shape_window", 40))
        mode_count = int(v_state.get("v_output_shape_mode_count", 6))
        max_steps = int(v_state.get("v_output_shape_max_steps", 4))
        position_weight_strength = float(
            v_state.get("v_output_shape_position_weight_strength", 1.0)
        )
    return quantize_hif4_v_local_modes(
        v,
        window=window,
        mean_penalty=mean_penalty,
        mode_penalty=mode_penalty,
        mode_count=mode_count,
        search_multipliers=search_multipliers,
        max_steps=max_steps,
        position_weight_strength=position_weight_strength,
    )


def hif4_dynamic_quantize_v(
    v_quant, v_scale, kv_num_heads, head_dim, v_state
):
    if (
        not isinstance(v_state, dict)
        or not bool(v_state.get("agent_vcross_enabled", False))
        or "agent_vcross_coefficients" not in v_state
    ):
        return _agent_vcross_parent_dynamic_quantize_v(
            v_quant, v_scale, kv_num_heads, head_dim, v_state
        )
    v = dequantize_nvfp4(v_quant, v_scale).to(torch.float32)
    target = _agent_vcross_transform_v(
        v,
        v_state["agent_vcross_coefficients"],
        kv_num_heads,
        head_dim,
        float(
            v_state.get(
                "agent_vcross_max_relative_correction",
                _AGENT_VCROSS_MAX_RELATIVE_CORRECTION,
            )
        ),
    )
    if bool(torch.equal(target, v)):
        return _agent_vcross_parent_dynamic_quantize_v(
            v_quant, v_scale, kv_num_heads, head_dim, v_state
        )
    return _agent_vcross_quantize_raw_v(target, v_state)
# Process-independent, sample-adaptive K repair.  Q and K are projections of
# the same hidden token, so calibration can learn the conditional linear mean
# E[Q | K].  At runtime current K predicts a surrogate current-sample Q.  The
# existing exact cross-entropy repair then uses that surrogate instead of a
# whole-sample calibration prototype.  No mutable global/cross-call state and
# no current test Q are used.
_K2Q_PARENT_CALIBRATION = hif4_calibration_attention
_K2Q_FALLBACK_DYNAMIC_K = hif4_dynamic_quantize_k
_K2Q_BASE_DYNAMIC_K = _KPR_PARENT_K
_K2Q_RIDGE = 0.003
_K2Q_MIN_ROWS = 128
_K2Q_MAX_COEFFICIENTS = 2_097_152


def _k2q_q_transform_state(q_state):
    names = (
        "mode",
        "kv_num_heads",
        "smooth_scale",
        "permutation",
        "rotation_group_steps",
        "rotation_pairs",
        "rotation_pair_signs",
        "attention_extra_transform",
        "attention_extra_transform_min_rows",
        "attention_extra_transform_block",
    )
    return {name: q_state[name] for name in names if name in q_state}


def hif4_calibration_attention(calib_qkv_list, q_num_heads, kv_num_heads, head_dim):
    result = _K2Q_PARENT_CALIBRATION(
        calib_qkv_list, q_num_heads, kv_num_heads, head_dim
    )
    input_width = int(kv_num_heads) * int(head_dim)
    output_width = int(q_num_heads) * int(head_dim)
    if input_width * output_width > int(_K2Q_MAX_COEFFICIENTS):
        return result
    x_parts = []
    y_parts = []
    for sample in calib_qkv_list:
        x = dequantize_nvfp4(*sample["k"]).to(torch.float32).reshape(-1, input_width)
        y = dequantize_nvfp4(*sample["q"]).to(torch.float32).reshape(-1, output_width)
        if int(x.shape[0]) != int(y.shape[0]):
            return result
        x_parts.append(x)
        y_parts.append(y)
    if not x_parts:
        return result
    x = torch.cat(x_parts, dim=0)
    y = torch.cat(y_parts, dim=0)
    if int(x.shape[0]) < 2:
        return result
    x_mean = x.mean(dim=0)
    x_scale = x.std(dim=0, correction=0).clamp_min(1.0e-4)
    y_mean = y.mean(dim=0)
    normalized = (x - x_mean) / x_scale
    count = float(x.shape[0])
    gram = normalized.T @ normalized / count
    gram.diagonal().add_(float(_K2Q_RIDGE))
    rhs = normalized.T @ (y - y_mean) / count
    try:
        coefficient = torch.linalg.solve(gram, rhs)
    except RuntimeError:
        return result
    if not bool(torch.isfinite(coefficient).all()):
        return result
    k_state = dict(result["k_state"])
    k_state.update(
        {
            "k2q_enabled": True,
            "k2q_input_width": input_width,
            "k2q_output_width": output_width,
            "k2q_q_num_heads": int(q_num_heads),
            "k2q_x_mean": x_mean.contiguous(),
            "k2q_x_inverse_scale": x_scale.reciprocal().contiguous(),
            "k2q_q_mean": y_mean.contiguous(),
            "k2q_coefficient": coefficient.to(torch.float16).contiguous(),
            "k2q_q_transform": _k2q_q_transform_state(result["q_state"]),
            "k2q_method": "current-k-global-ridge-q-surrogate",
            "k2q_ridge": float(_K2Q_RIDGE),
        }
    )
    result["k_state"] = k_state
    return result


def _k2q_group_queries(predicted_q, q_num_heads, kv_num_heads, head_dim, q_state):
    query_rows = int(predicted_q.shape[0])
    q_per_kv = int(q_num_heads) // int(kv_num_heads)
    transformed = transform_attention_q_structured(
        predicted_q, q_num_heads, head_dim, q_state
    )
    transformed = apply_attention_extra_transform(
        transformed, q_num_heads, head_dim, q_state
    )
    reference = (
        predicted_q.reshape(query_rows, int(kv_num_heads), q_per_kv, int(head_dim))
        .permute(1, 2, 0, 3)
        .reshape(int(kv_num_heads), -1, int(head_dim))
        .contiguous()
    )
    quantized = (
        transformed.reshape(query_rows, int(kv_num_heads), q_per_kv, int(head_dim))
        .permute(1, 2, 0, 3)
        .reshape(int(kv_num_heads), -1, int(head_dim))
        .contiguous()
    )
    return reference, quantized


def hif4_dynamic_quantize_k(k_quant, k_scale, kv_num_heads, head_dim, k_state):
    rows = int(k_quant.shape[0])
    required = (
        "k2q_x_mean",
        "k2q_x_inverse_scale",
        "k2q_q_mean",
        "k2q_coefficient",
        "k2q_q_transform",
    )
    if (
        rows < int(_K2Q_MIN_ROWS)
        or not isinstance(k_state, dict)
        or not bool(k_state.get("k2q_enabled", False))
        or any(name not in k_state for name in required)
    ):
        return _K2Q_FALLBACK_DYNAMIC_K(
            k_quant, k_scale, kv_num_heads, head_dim, k_state
        )
    input_width = int(kv_num_heads) * int(head_dim)
    q_num_heads = int(k_state.get("k2q_q_num_heads", 0))
    if (
        input_width != int(k_state.get("k2q_input_width", -1))
        or q_num_heads <= 0
        or q_num_heads % int(kv_num_heads)
    ):
        return _K2Q_FALLBACK_DYNAMIC_K(
            k_quant, k_scale, kv_num_heads, head_dim, k_state
        )
    k_raw = dequantize_nvfp4(k_quant, k_scale).to(torch.float32)
    query_rows = min(rows, 512)
    if query_rows == rows:
        query_index = torch.arange(rows, dtype=torch.long)
    else:
        query_index = torch.linspace(0, rows - 1, query_rows).round().to(torch.long)
    current_k = k_raw.index_select(0, query_index).reshape(query_rows, input_width)
    normalized = current_k - k_state["k2q_x_mean"].to(torch.float32)
    normalized.mul_(k_state["k2q_x_inverse_scale"].to(torch.float32))
    predicted_q = normalized @ k_state["k2q_coefficient"].to(torch.float32)
    predicted_q.add_(k_state["k2q_q_mean"].to(torch.float32))
    q_reference, q_quantized = _k2q_group_queries(
        predicted_q,
        q_num_heads,
        kv_num_heads,
        head_dim,
        k_state["k2q_q_transform"],
    )
    base_state = dict(k_state)
    base_state["agg_khier_enabled"] = True
    params = _K2Q_BASE_DYNAMIC_K(
        k_quant, k_scale, kv_num_heads, head_dim, base_state
    )
    k_reference = (
        k_raw.reshape(rows, int(kv_num_heads), int(head_dim))
        .permute(1, 0, 2)
        .contiguous()
    )
    step = _grid_step(params, tuple(int(value) for value in k_quant.shape))
    step = (
        step.reshape(rows, int(kv_num_heads), int(head_dim))
        .permute(1, 0, 2)
        .contiguous()
    )
    codes = (
        torch.round(
            params["sign"].to(torch.float32)
            * params["mant"].to(torch.float32)
            * 4.0
        )
        .to(torch.int8)
        .reshape(rows, int(kv_num_heads), int(head_dim))
        .permute(1, 0, 2)
        .contiguous()
    )
    _, _, _, parent_groups = _joint_select_terms(k_state, rows)
    selected_groups = 6 if rows < 512 else 8
    usable = int(_KPR_GROUP_SIZE) * selected_groups
    groups = parent_groups.reshape(int(kv_num_heads), -1)[:, :usable]
    groups = groups.reshape(
        int(kv_num_heads), selected_groups, int(_KPR_GROUP_SIZE)
    )
    repaired = _kpr_repair(
        q_reference, q_quantized, k_reference, step, codes, groups
    )
    return _pack_signed_codes(
        params, repaired.permute(1, 0, 2).reshape(k_quant.shape)
    )

# Apply the two extra long-Q scale candidates only to row-stationary,
# channel-anisotropic inputs that remain close to a calibration prototype.
_QSGATE_PARENT_CAL = hif4_calibration_attention
_QSGATE_PARENT_Q = hif4_dynamic_quantize_q
_QSGATE_WIDE = (0.5, 0.625, 0.75, 1.0, 1.125, 1.25, 1.375)
_QSGATE_MIN_ROWS = 1024
_QSGATE_MIN_ANISOTROPY = 4.0
_QSGATE_MAX_LOG_DISTANCE = 0.50
_QSGATE_STRENGTH = None


def _qsgate_descriptor(q, q_num_heads, head_dim):
    heads = q.to(torch.float32).reshape(-1, int(q_num_heads), int(head_dim))
    squared = heads.square()
    rms = squared.mean().clamp_min(1e-30).sqrt()
    row_rms = squared.mean(dim=(1, 2)).clamp_min(1e-30).sqrt()
    channel_rms = squared.mean(dim=(0, 1)).clamp_min(1e-30).sqrt()
    row_cv = row_rms.std(unbiased=False) / row_rms.mean().clamp_min(1e-30)
    channel_cv = channel_rms.std(unbiased=False) / channel_rms.mean().clamp_min(1e-30)
    return torch.stack((rms, row_cv, channel_cv)).to(torch.float32)


def hif4_calibration_attention(calib_qkv_list, q_num_heads, kv_num_heads, head_dim):
    result = _QSGATE_PARENT_CAL(
        calib_qkv_list, q_num_heads, kv_num_heads, head_dim
    )
    descriptors = []
    for sample in calib_qkv_list:
        if int(sample['q'][0].shape[0]) < int(_QSGATE_MIN_ROWS):
            continue
        q = dequantize_nvfp4(*sample['q']).to(torch.float32)
        descriptors.append(_qsgate_descriptor(q, q_num_heads, head_dim))
    if descriptors:
        q_state = dict(result['q_state'])
        q_state['qscale_gate_descriptors'] = torch.stack(descriptors).contiguous()
        result['q_state'] = q_state
    return result


def _x20916_q2k_repair_one_group_exact(
    q_reference, q_current, k_reference, k_transformed, step, code, groups
):
    """Exact one-group specialization of _qpr_repair for the Q2K wrapper.

    The Q2K caller freezes _X20916_Q2K_GROUPS=1.  Consequently the generic
    kernel's probability update and q_current clone/scatter occur after the
    only group and are never observed.  Omitting those dead writes preserves
    the returned signed codes bit-for-bit while avoiding three long-sequence
    buffers.  The scoring arithmetic and acceptance predicate are unchanged.
    """
    head_count, rows, head_dim = q_reference.shape
    root_dim = math.sqrt(float(head_dim))
    # int8 -> FP32 already creates a new owned tensor; no second clone needed.
    current_code = code.to(torch.float32)
    reference_probability = torch.softmax(
        torch.bmm(q_reference, k_reference.transpose(1, 2)) / root_dim, dim=2
    )
    probability = torch.softmax(
        torch.bmm(q_current, k_transformed.transpose(1, 2)) / root_dim, dim=2
    )
    left = _KPR_SH2_LEFT.to(device=q_reference.device)
    right = _KPR_SH2_RIGHT.to(device=q_reference.device)
    patterns = _KPR_PATTERNS.to(device=q_reference.device, dtype=torch.float32)

    columns = groups[:, 0, :]
    key_index = columns[:, None, :].expand(
        head_count, int(k_transformed.shape[1]), int(_QPR_GROUP_SIZE)
    )
    token_index = columns[:, None, :].expand(
        head_count, rows, int(_QPR_GROUP_SIZE)
    )
    k_group = torch.gather(k_transformed, 2, key_index)
    group_gradient = torch.bmm(
        probability - reference_probability, k_group
    ) / root_dim

    mean = torch.bmm(probability, k_group)
    pair_keys = (
        k_group.index_select(2, left) * k_group.index_select(2, right)
    )
    curvature_keys = torch.cat((k_group.square(), pair_keys), dim=2)
    moments = torch.bmm(probability, curvature_keys)
    token_diagonal = (
        moments[:, :, :int(_QPR_GROUP_SIZE)] - mean.square()
    ).div(float(head_dim)).clamp_min(1.0e-20)
    token_pair = (
        moments[:, :, int(_QPR_GROUP_SIZE):]
        - mean.index_select(2, left) * mean.index_select(2, right)
    ).div(float(head_dim))

    group_step = torch.gather(step, 2, token_index)
    group_code = torch.gather(current_code, 2, token_index)
    raw_jump = torch.round(
        -group_gradient / (token_diagonal * group_step).clamp_min(1.0e-30)
    ).clamp(-1.0, 1.0)
    fallback = torch.where(
        group_gradient > 0.0,
        -torch.ones_like(raw_jump),
        torch.ones_like(raw_jump),
    )
    jump = torch.where(raw_jump == 0.0, fallback, raw_jump)
    jump = torch.maximum(
        torch.minimum(jump, 7.0 - group_code), -7.0 - group_code
    )
    proposal_delta = jump * group_step
    costs = _kpr_sparse_hamming2_costs(
        proposal_delta, group_gradient, token_diagonal, token_pair
    )
    best = costs.argmin(dim=0)
    best_cost = torch.gather(costs, 0, best[None, :, :]).squeeze(0)
    chosen = (
        patterns.index_select(0, best.reshape(-1))
        .reshape(head_count, rows, int(_QPR_GROUP_SIZE))
        * proposal_delta
    )
    if int(_QPR_TOKEN_BUDGET) < rows:
        selected_tokens = best_cost.topk(
            int(_QPR_TOKEN_BUDGET), dim=1, largest=False, sorted=True
        ).indices
        token_mask = torch.zeros(
            (head_count, rows), dtype=torch.bool, device=chosen.device
        )
        token_mask.scatter_(1, selected_tokens, True)
        chosen = torch.where(token_mask[:, :, None], chosen, 0.0)
    chosen = torch.where(best_cost[:, :, None] < 0.0, chosen, 0.0)

    logit_delta = torch.bmm(chosen, k_group.transpose(1, 2)) / root_dim
    # This is the terminal group, so reference_probability and logit_delta
    # are dead after their contribution to acceptance. Reuse both buffers;
    # the elementwise FP32 operations and reduction order are unchanged.
    reference_probability.mul_(logit_delta)
    loss_delta = -reference_probability.sum(dim=2)
    logit_delta.exp_().mul_(probability)
    normalizer = logit_delta.sum(dim=2, keepdim=True).clamp_min(1.0e-30)
    loss_delta += torch.log(normalizer.squeeze(2))
    accept = loss_delta < -1.0e-12
    chosen = torch.where(accept[:, :, None], chosen, 0.0)
    new_code = torch.round(
        group_code + chosen / group_step.clamp_min(1.0e-30)
    ).clamp(-7.0, 7.0)
    current_code.scatter_(2, token_index, new_code)
    return current_code.to(torch.int8)


def hif4_dynamic_quantize_q(q_quant, q_scale, q_num_heads, head_dim, q_state):
    rows = int(q_quant.shape[0])
    descriptors = q_state.get('qscale_gate_descriptors')
    if rows >= int(_QSGATE_MIN_ROWS) and descriptors is not None:
        q = dequantize_nvfp4(q_quant, q_scale).to(torch.float32)
        current = _qsgate_descriptor(q, q_num_heads, head_dim)
        reference = descriptors.to(torch.float32)
        distance = (
            (current.clamp_min(1e-20).log()[None, :]
             - reference.clamp_min(1e-20).log()).abs()
            * torch.tensor((0.5, 1.0, 1.0), dtype=torch.float32)
        ).sum(dim=1)
        anisotropy = current[2] / current[1].clamp_min(1e-20)
        if bool((anisotropy >= float(_QSGATE_MIN_ANISOTROPY)).item()) and bool(
            (distance.min() <= float(_QSGATE_MAX_LOG_DISTANCE)).item()
        ):
            q_state = dict(q_state)
            q_state['attention_search_long_multipliers'] = _QSGATE_WIDE
            q_state['qscale_gate_active'] = 1
            if _QSGATE_STRENGTH is not None:
                q_state['attention_hierarchy_grid_strength'] = float(
                    _QSGATE_STRENGTH
                )
    return _QSGATE_PARENT_Q(q_quant, q_scale, q_num_heads, head_dim, q_state)

_QSGATE_WIDE = (0.75, 1.0, 1.125, 1.25, 1.5)
_QSGATE_STRENGTH = None
# Exact eager fusion of the Q-scale descriptor with the parent's first Q
# decode.  QPR is disabled in the external parent, so this reproduces its
# state setup and calls the same transform/Hessian quantizer directly.
def hif4_dynamic_quantize_q(q_quant, q_scale, q_num_heads, head_dim, q_state, _decoded_q=None):
    rows = int(q_quant.shape[0])
    state = _joint_set_length_budget(q_state, rows, 32)
    # Spend less on the proxy quadratic only when the current-Q CE repair is enabled.
    if (
        128 <= rows <= int(_X20916_Q2K_MAX_ROWS)
        and bool(state.get("q2k_enabled", False))
        and float(state.get("q2k_train_r2", torch.zeros(1)).min()) >= float(_X20916_Q2K_MIN_TRAIN_R2)
    ):
        for group_key in ("joint_rotated_groups", "joint_unrotated_groups"):
            if group_key in state:
                width = int(state[group_key].shape[-1])
                state[group_key] = state[group_key][:, :96 // width]

    state["agg_khier_enabled"] = (
        bool(_QPR_ENABLE_SHORT_HIERARCHY) and rows < 128
    )
    q = dequantize_nvfp4(q_quant, q_scale).to(torch.float32) if _decoded_q is None else _decoded_q
    descriptors = state.get("qscale_gate_descriptors")
    if rows >= int(_QSGATE_MIN_ROWS) and descriptors is not None:
        current = _qsgate_descriptor(q, q_num_heads, head_dim)
        reference = descriptors.to(torch.float32)
        distance = (
            (current.clamp_min(1.0e-20).log()[None, :]
             - reference.clamp_min(1.0e-20).log()).abs()
            * torch.tensor((0.5, 1.0, 1.0), dtype=torch.float32)
        ).sum(dim=1)
        anisotropy = current[2] / current[1].clamp_min(1.0e-20)
        if bool((anisotropy >= float(_QSGATE_MIN_ANISOTROPY)).item()) and bool(
            (distance.min() <= float(_QSGATE_MAX_LOG_DISTANCE)).item()
        ):
            state["attention_search_long_multipliers"] = _QSGATE_WIDE
            state["qscale_gate_active"] = 1
            if _QSGATE_STRENGTH is not None:
                state["attention_hierarchy_grid_strength"] = float(
                    _QSGATE_STRENGTH
                )
    q = transform_attention_q_structured(q, q_num_heads, head_dim, state)
    q = apply_attention_extra_transform(q, q_num_heads, head_dim, state)
    return quantize_attention_hessian(q, q_num_heads, head_dim, state)
# Symmetric lesson from K2Q: predict the current matching K from the mean of
# its assigned current Q heads, then run one exact Q-side CE repair group.  It
# is role-local and does not use the disabled calibration-prototype QPR path.
_x20916_q2k_parent_calibration = hif4_calibration_attention
_x20916_q2k_parent_q = hif4_dynamic_quantize_q
_X20916_Q2K_MIN_ROWS = 128
_X20916_Q2K_MAX_ROWS = 1024
_X20916_Q2K_GROUPS = 3
_X20916_Q2K_KEY_ROWS = 512
_X20916_Q2K_MIN_TRAIN_R2 = 0.85
_X20916_Q2K_HEAD_MODES = 6
_X20916_Q2K_BLOCK_SEQUENTIAL = 0


def _x20916_q2k_k_transform_state(k_state):
    names = (
        "mode", "kv_num_heads", "smooth_scale", "permutation",
        "rotation_group_steps", "rotation_pairs", "rotation_pair_signs",
        "attention_extra_transform", "attention_extra_transform_min_rows",
        "attention_extra_transform_block", "attention_k_centering",
    )
    return {name: k_state[name] for name in names if name in k_state}


def hif4_calibration_attention(calib_qkv_list, q_num_heads, kv_num_heads, head_dim):
    result = _x20916_q2k_parent_calibration(
        calib_qkv_list, q_num_heads, kv_num_heads, head_dim
    )
    if int(q_num_heads) % int(kv_num_heads):
        return result
    q_per_kv = int(q_num_heads) // int(kv_num_heads)
    mode_count = min(int(_X20916_Q2K_HEAD_MODES), q_per_kv)
    if int(head_dim) > 256:
        mode_count = min(mode_count, 4)
    head_position = torch.arange(q_per_kv, dtype=torch.float32)[:, None]
    head_frequency = torch.arange(mode_count, dtype=torch.float32)[None, :]
    head_basis = torch.cos(
        math.pi * (head_position + 0.5) * head_frequency / float(q_per_kv)
    )
    head_basis[:, 0] *= math.sqrt(1.0 / float(q_per_kv))
    if mode_count > 1:
        head_basis[:, 1:] *= math.sqrt(2.0 / float(q_per_kv))
    x_parts = []
    y_parts = []
    for sample in calib_qkv_list:
        q = dequantize_nvfp4(*sample["q"]).to(torch.float32)
        k = dequantize_nvfp4(*sample["k"]).to(torch.float32)
        rows = int(q.shape[0])
        if int(k.shape[0]) != rows:
            return result
        grouped_q = q.reshape(
            rows, int(kv_num_heads), q_per_kv, int(head_dim)
        )
        features = torch.einsum(
            "rkhd,hm->rkmd", grouped_q, head_basis
        ).reshape(rows, int(kv_num_heads), mode_count * int(head_dim))
        x_parts.append(features)
        y_parts.append(k.reshape(rows, int(kv_num_heads), int(head_dim)))
    if not x_parts:
        return result
    x = torch.cat(x_parts, dim=0).transpose(0, 1).contiguous()
    y = torch.cat(y_parts, dim=0).transpose(0, 1).contiguous()
    x_mean = x.mean(dim=1)
    x_scale = x.std(dim=1, correction=0).clamp_min(1.0e-4)
    y_mean = y.mean(dim=1)
    normalized = (x - x_mean[:, None, :]) / x_scale[:, None, :]
    centered_y = y - y_mean[:, None, :]
    count = float(x.shape[1])
    coefficient = torch.zeros(
        int(kv_num_heads), mode_count * int(head_dim), int(head_dim),
        dtype=torch.float32,
    )
    try:
        if (bool(_X20916_Q2K_BLOCK_SEQUENTIAL) or mode_count * int(head_dim) > 1536) and mode_count > 1:
            residual = centered_y.clone()
            for mode in range(mode_count):
                start = mode * int(head_dim)
                stop = start + int(head_dim)
                feature = normalized[:, :, start:stop]
                gram = torch.bmm(feature.transpose(1, 2), feature) / count
                gram.diagonal(dim1=-2, dim2=-1).add_(0.003)
                rhs = torch.bmm(feature.transpose(1, 2), residual) / count
                for kv_head in range(int(kv_num_heads)):
                    coefficient[kv_head, start:stop] = torch.linalg.solve(
                        gram[kv_head], rhs[kv_head]
                    )
                residual.sub_(
                    torch.bmm(feature, coefficient[:, start:stop])
                )
        else:
            gram = torch.bmm(normalized.transpose(1, 2), normalized) / count
            gram.diagonal(dim1=-2, dim2=-1).add_(0.03)
            rhs = torch.bmm(normalized.transpose(1, 2), centered_y) / count
            cholesky, info = torch.linalg.cholesky_ex(gram)
            if bool((info == 0).all()):
                coefficient = torch.cholesky_solve(rhs, cholesky)
            else:
                coefficient = torch.linalg.solve(gram, rhs)
    except RuntimeError:
        return result
    if not bool(torch.isfinite(coefficient).all()):
        return result
    prediction = torch.bmm(normalized, coefficient)
    residual_energy = (centered_y - prediction).square().mean(dim=(1, 2))
    target_energy = centered_y.square().mean(dim=(1, 2)).clamp_min(1.0e-12)
    train_r2 = (1.0 - residual_energy / target_energy).contiguous()
    state = result["q_state"]
    state.update({
        "q2k_enabled": True,
        "q2k_q_per_kv": q_per_kv,
        "q2k_x_mean": x_mean.contiguous(),
        "q2k_x_inverse_scale": x_scale.reciprocal().contiguous(),
        "q2k_head_basis": head_basis.contiguous(),
        "q2k_k_mean": y_mean.contiguous(),
        "q2k_coefficient": coefficient.to(torch.float16).contiguous(),
        "q2k_train_r2": train_r2,
        "q2k_k_transform": _x20916_q2k_k_transform_state(result["k_state"]),
        "q2k_method": "current-q-groupmean-ridge-k-surrogate-ce-repair",
    })
    return result


def hif4_dynamic_quantize_q(q_quant, q_scale, q_num_heads, head_dim, q_state):
    q_raw = dequantize_nvfp4(q_quant, q_scale).to(torch.float32)
    params = _x20916_q2k_parent_q(
        q_quant, q_scale, q_num_heads, head_dim, q_state, q_raw
    )
    rows = int(q_quant.shape[0])
    required = (
        "q2k_x_mean", "q2k_x_inverse_scale", "q2k_head_basis", "q2k_k_mean",
        "q2k_coefficient", "q2k_k_transform",
    )
    if (
        rows < int(_X20916_Q2K_MIN_ROWS)
        or rows > int(_X20916_Q2K_MAX_ROWS)
        or not isinstance(q_state, dict)
        or not bool(q_state.get("q2k_enabled", False))
        or float(q_state.get("q2k_train_r2", torch.zeros(1)).min())
            < float(_X20916_Q2K_MIN_TRAIN_R2)
        or any(name not in q_state for name in required)
    ):
        return params
    kv_num_heads = int(q_state["kv_num_heads"])
    q_per_kv = int(q_state["q2k_q_per_kv"])
    if int(q_num_heads) != kv_num_heads * q_per_kv:
        return params
    grouped_q = q_raw.reshape(
        rows, kv_num_heads, q_per_kv, int(head_dim)
    )
    head_basis = q_state["q2k_head_basis"].to(torch.float32)
    mode_count = int(head_basis.shape[1])
    grouped = torch.einsum(
        "rkhd,hm->rkmd", grouped_q, head_basis
    ).reshape(
        rows, kv_num_heads, mode_count * int(head_dim)
    ).permute(1, 0, 2).contiguous()
    normalized = grouped - q_state["q2k_x_mean"].to(torch.float32)[:, None, :]
    normalized.mul_(
        q_state["q2k_x_inverse_scale"].to(torch.float32)[:, None, :]
    )
    predicted_k = torch.bmm(
        normalized, q_state["q2k_coefficient"].to(torch.float32)
    )
    predicted_k.add_(q_state["q2k_k_mean"].to(torch.float32)[:, None, :])
    k_reference = predicted_k
    k_flat = predicted_k.permute(1, 0, 2).reshape(
        rows, kv_num_heads * int(head_dim)
    )
    k_state = q_state["q2k_k_transform"]
    k_transformed = center_attention_k(k_flat, kv_num_heads, head_dim)
    k_transformed = transform_attention_k_structured(
        k_transformed, kv_num_heads, head_dim, k_state
    )
    k_transformed = apply_attention_extra_transform(
        k_transformed, kv_num_heads, head_dim, k_state
    ).reshape(rows, kv_num_heads, int(head_dim)).permute(1, 0, 2).contiguous()
    if int(_X20916_Q2K_KEY_ROWS) > 0 and rows > int(_X20916_Q2K_KEY_ROWS):
        key_index = torch.linspace(
            0, rows - 1, int(_X20916_Q2K_KEY_ROWS)
        ).round().to(torch.long)
        k_reference = k_reference.index_select(1, key_index)
        k_transformed = k_transformed.index_select(1, key_index)
    k_reference = k_reference.repeat_interleave(q_per_kv, dim=0)
    k_transformed = k_transformed.repeat_interleave(q_per_kv, dim=0)
    q_reference = q_raw.reshape(
        rows, int(q_num_heads), int(head_dim)
    ).permute(1, 0, 2).contiguous()
    q_current = dequantize_hif4(params).to(torch.float32).reshape(
        rows, int(q_num_heads), int(head_dim)
    ).permute(1, 0, 2).contiguous()
    step = _grid_step(
        params, tuple(int(value) for value in q_quant.shape)
    ).reshape(rows, int(q_num_heads), int(head_dim)).permute(1, 0, 2).contiguous()
    codes = torch.round(
        params["sign"].to(torch.float32) * params["mant"].to(torch.float32) * 4.0
    ).to(torch.int8).reshape(
        rows, int(q_num_heads), int(head_dim)
    ).permute(1, 0, 2).contiguous()
    _, _, _, parent_groups = _joint_select_terms(q_state, rows)
    selected_groups = min(int(_X20916_Q2K_GROUPS), int(parent_groups.shape[1]))
    usable = int(_QPR_GROUP_SIZE) * selected_groups
    groups = parent_groups.reshape(kv_num_heads, -1)[:, :usable].reshape(
        kv_num_heads, selected_groups, int(_QPR_GROUP_SIZE)
    ).repeat_interleave(q_per_kv, dim=0)
    repaired = _q2k_repair_cached(
        q_reference, q_current, k_reference, k_transformed,
        step, codes, groups,
    )
    return _pack_signed_codes(
        params, repaired.permute(1, 0, 2).reshape(q_quant.shape)
    )


# One-pass adaptive DCT96/128 V crossfit. This overrides the fit function used
# by the already-bound calibration wrapper; all operators share one P/P_hat
# construction and one DCT128 projection.
_VCROSS_ONEPASS_PARENT_DYNAMIC_V = hif4_dynamic_quantize_v
_VCROSS_ONEPASS_CONFIGS = {
    # LOO-safe: retain the original rank64 operator for tiny sequences.
    "tiny": (64, 1.0, 1.0),
    "short": (96, 0.5, 0.5),
    "medium": (128, 2.0, 0.75),
    "long": (128, 1.0, 0.75),
}


def _vcross_onepass_solve(gram, cross, rank, ridge_ratio, shrink):
    rank = min(int(rank), int(gram.shape[-1]))
    local_gram = gram[:, :rank, :rank]
    local_cross = cross[:, :rank, :rank]
    coefficients = torch.zeros_like(local_gram)
    eye = torch.eye(rank, dtype=torch.float32)
    for kv_head in range(int(local_gram.shape[0])):
        mean_diagonal = torch.diagonal(local_gram[kv_head]).mean().clamp_min(1.0e-8)
        ridge = mean_diagonal * float(ridge_ratio)
        try:
            coefficient = torch.linalg.solve(
                local_gram[kv_head] + ridge * eye, local_cross[kv_head]
            )
        except RuntimeError:
            coefficient = torch.zeros_like(local_cross[kv_head])
        coefficient *= float(shrink)
        if not bool(torch.isfinite(coefficient).all()):
            coefficient.zero_()
        gain = 2.0 * (coefficient * local_cross[kv_head]).sum()
        gain -= torch.einsum(
            "ij,ik,kj->", coefficient, local_gram[kv_head], coefficient
        )
        if float(gain) <= 0.0:
            coefficient.zero_()
        coefficients[kv_head] = coefficient
    return coefficients.contiguous()


def _agent_vcross_fit_v_operator(
    calib_qkv_list,
    q_num_heads,
    kv_num_heads,
    head_dim,
    q_state,
    k_state,
):
    candidates = [
        sample
        for sample in calib_qkv_list
        if int(sample["q"][0].shape[0]) <= int(_AGENT_VCROSS_MAX_FIT_ROWS)
    ]
    if not candidates:
        return {
            "agent_vcross_enabled": False,
            "agent_vcross_policy": "fallback-no-bounded-calibration-sample",
        }
    sample = max(candidates, key=lambda item: int(item["q"][0].shape[0]))
    rows = int(sample["q"][0].shape[0])
    rank = min(128, rows)
    group_size = int(q_num_heads) // int(kv_num_heads)
    if group_size <= 0 or group_size * int(kv_num_heads) != int(q_num_heads):
        return {
            "agent_vcross_enabled": False,
            "agent_vcross_policy": "fallback-invalid-head-grouping",
        }
    with torch.no_grad():
        basis = _agent_vcross_dct_basis(rows, rank)
        real_q = dequantize_nvfp4(*sample["q"]).to(torch.float32)
        real_k = dequantize_nvfp4(*sample["k"]).to(torch.float32)
        q_hat, k_hat = _agent_vcross_fast_deployed_qk(
            sample,
            q_state,
            k_state,
            q_num_heads,
            kv_num_heads,
            head_dim,
        )
        real_q = real_q.reshape(rows, int(q_num_heads), int(head_dim)).transpose(0, 1)
        real_k = real_k.reshape(rows, int(kv_num_heads), int(head_dim)).transpose(0, 1)
        q_hat = q_hat.reshape(rows, int(q_num_heads), int(head_dim)).transpose(0, 1)
        k_hat = k_hat.reshape(rows, int(kv_num_heads), int(head_dim)).transpose(0, 1)
        gram = torch.zeros(int(kv_num_heads), rank, rank, dtype=torch.float32)
        cross = torch.zeros_like(gram)
        scale = math.sqrt(float(head_dim))
        row_weight = 1.0 / float(max(rows, 1))
        for kv_head in range(int(kv_num_heads)):
            head_start = kv_head * group_size
            head_end = head_start + group_size
            real_probability = torch.softmax(
                torch.matmul(real_q[head_start:head_end], real_k[kv_head].T) / scale,
                dim=-1,
            )
            deployed_probability = torch.softmax(
                torch.matmul(q_hat[head_start:head_end], k_hat[kv_head].T) / scale,
                dim=-1,
            )
            design = torch.matmul(deployed_probability, basis).reshape(-1, rank)
            residual = torch.matmul(
                real_probability - deployed_probability, basis
            ).reshape(-1, rank)
            gram[kv_head] = (design.T @ design) * row_weight
            cross[kv_head] = (design.T @ residual) * row_weight
        operators = {}
        for name, (local_rank, ridge, shrink) in _VCROSS_ONEPASS_CONFIGS.items():
            local_rank = min(int(local_rank), rank)
            operators[name] = {
                "coefficients": _vcross_onepass_solve(
                    gram, cross, local_rank, ridge, shrink
                ),
                "rank": local_rank,
                "ridge": float(ridge),
                "shrink": float(shrink),
            }
    enabled = all(
        bool(entry["coefficients"].abs().sum() > 0.0)
        for entry in operators.values()
    )
    default = operators["long"]
    return {
        "agent_vcross_enabled": enabled,
        "agent_vcross_coefficients": default["coefficients"],
        "agent_vcross_rank": int(default["rank"]),
        "agent_vcross_fit_rows": int(rows),
        "agent_vcross_max_relative_correction": float(
            _AGENT_VCROSS_MAX_RELATIVE_CORRECTION
        ),
        "agent_vcross_policy": "one-pass-adaptive-dct96-128",
        "vcross_adaptive_enabled": enabled,
        "vcross_adaptive_operators": operators,
        "vcross_adaptive_policy": "tiny<64,short<512,medium<768,long",
    }


def hif4_dynamic_quantize_v(v_quant, v_scale, kv_num_heads, head_dim, v_state):
    if not isinstance(v_state, dict) or not bool(
        v_state.get("vcross_adaptive_enabled", False)
    ):
        return _VCROSS_ONEPASS_PARENT_DYNAMIC_V(
            v_quant, v_scale, kv_num_heads, head_dim, v_state
        )
    rows = int(v_quant.shape[0])
    if rows < 64:
        name = "tiny"
    elif rows < 512:
        name = "short"
    elif rows < 768:
        name = "medium"
    else:
        name = "long"
    entry = v_state.get("vcross_adaptive_operators", {}).get(name)
    if not isinstance(entry, dict) or "coefficients" not in entry:
        return _VCROSS_ONEPASS_PARENT_DYNAMIC_V(
            v_quant, v_scale, kv_num_heads, head_dim, v_state
        )
    selected_state = dict(v_state)
    selected_state["agent_vcross_coefficients"] = entry["coefficients"]
    selected_state["agent_vcross_rank"] = int(entry["rank"])
    selected_state["agent_vcross_policy"] = "adaptive-onepass-" + name
    return _VCROSS_ONEPASS_PARENT_DYNAMIC_V(
        v_quant, v_scale, kv_num_heads, head_dim, selected_state
    )




def _q2k_repair_cached(q_reference, q_current, k_reference, k_transformed, step, code, groups):
    head_count, rows, head_dim = q_reference.shape
    root_dim = math.sqrt(float(head_dim))
    current_code = code.to(torch.float32)
    reference_probability = torch.softmax(
        torch.bmm(q_reference, k_reference.transpose(1, 2)) / root_dim, dim=2
    )
    probability = torch.softmax(
        torch.bmm(q_current, k_transformed.transpose(1, 2)) / root_dim, dim=2
    )
    left = _KPR_SH2_LEFT.to(device=q_reference.device)
    right = _KPR_SH2_RIGHT.to(device=q_reference.device)
    patterns = _KPR_PATTERNS.to(device=q_reference.device, dtype=torch.float32)

    # Cache reference moments for all repaired coordinates once.
    flat_columns = groups.reshape(head_count, -1)
    flat_index = flat_columns[:, None, :].expand(head_count, int(k_transformed.shape[1]), -1)
    flat_keys = torch.gather(k_transformed, 2, flat_index)
    reference_mean = torch.bmm(reference_probability, flat_keys)
    reference_mean = reference_mean.reshape(head_count, rows, int(groups.shape[1]), int(_QPR_GROUP_SIZE))

    for group_index in range(int(groups.shape[1])):
        columns = groups[:, group_index, :]
        key_index = columns[:, None, :].expand(head_count, int(k_transformed.shape[1]), int(_QPR_GROUP_SIZE))
        token_index = columns[:, None, :].expand(head_count, rows, int(_QPR_GROUP_SIZE))
        k_group = torch.gather(k_transformed, 2, key_index)
        mean = torch.bmm(probability, k_group)
        group_gradient = (mean - reference_mean[:, :, group_index, :]) / root_dim
        pair_keys = k_group.index_select(2, left) * k_group.index_select(2, right)
        curvature_keys = torch.cat((k_group.square(), pair_keys), dim=2)
        moments = torch.bmm(probability, curvature_keys)
        token_diagonal = (
            moments[:, :, :int(_QPR_GROUP_SIZE)] - mean.square()
        ).div(float(head_dim)).clamp_min(1.0e-20)
        token_pair = (
            moments[:, :, int(_QPR_GROUP_SIZE):]
            - mean.index_select(2, left) * mean.index_select(2, right)
        ).div(float(head_dim))

        group_step = torch.gather(step, 2, token_index)
        group_code = torch.gather(current_code, 2, token_index)
        raw_jump = torch.round(
            -group_gradient / (token_diagonal * group_step).clamp_min(1.0e-30)
        ).clamp(-1.0, 1.0)
        fallback = torch.where(
            group_gradient > 0.0,
            -torch.ones_like(raw_jump),
            torch.ones_like(raw_jump),
        )
        jump = torch.where(raw_jump == 0.0, fallback, raw_jump)
        jump = torch.maximum(
            torch.minimum(jump, 7.0 - group_code), -7.0 - group_code
        )
        proposal_delta = jump * group_step
        costs = _kpr_sparse_hamming2_costs(
            proposal_delta, group_gradient, token_diagonal, token_pair
        )
        best = costs.argmin(dim=0)
        best_cost = torch.gather(costs, 0, best[None, :, :]).squeeze(0)
        chosen = (
            patterns.index_select(0, best.reshape(-1))
            .reshape(head_count, rows, int(_QPR_GROUP_SIZE))
            * proposal_delta
        )
        if int(_QPR_TOKEN_BUDGET) < rows:
            selected_tokens = best_cost.topk(
                int(_QPR_TOKEN_BUDGET), dim=1, largest=False, sorted=True
            ).indices
            token_mask = torch.zeros(
                (head_count, rows), dtype=torch.bool, device=chosen.device
            )
            token_mask.scatter_(1, selected_tokens, True)
            chosen = torch.where(token_mask[:, :, None], chosen, 0.0)
        chosen = torch.where(best_cost[:, :, None] < 0.0, chosen, 0.0)

        logit_delta = torch.bmm(chosen, k_group.transpose(1, 2)) / root_dim
        loss_delta = -(reference_probability * logit_delta).sum(dim=2)
        ratio = logit_delta.exp_().mul_(probability)
        normalizer = ratio.sum(dim=2, keepdim=True).clamp_min(1.0e-30)
        loss_delta += torch.log(normalizer.squeeze(2))
        accept = loss_delta < -1.0e-12
        if group_index + 1 < int(groups.shape[1]):
            ratio.div_(normalizer)
            torch.where(accept[:, :, None], ratio, probability, out=probability)
        chosen = torch.where(accept[:, :, None], chosen, 0.0)
        new_code = torch.round(
            group_code + chosen / group_step.clamp_min(1.0e-30)
        ).clamp(-7.0, 7.0)
        current_code.scatter_(2, token_index, new_code)
    return current_code.to(torch.int8)
